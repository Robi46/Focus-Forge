import type { ActiveSession } from "./focusforge-core";

export type ScheduledFocusCue = {
  atMs: number;
  title: string;
  body: string;
  checkpoint: boolean;
  kind: "round" | "checkpoint" | "restart";
};

/**
 * Produces every future OS-level cue for an active session. Android delivers these
 * local notifications while the display is locked in an installed build; foreground
 * playback remains a separate direct-audio fallback.
 */
export function getScheduledFocusCues(session: ActiveSession, nowMs: number, horizonHours = 24): ScheduledFocusCue[] {
  const plan = session.plan;
  const roundSeconds = plan.roundMinutes * 60;
  const focusSeconds = roundSeconds * plan.roundsPerCycle;
  const restSeconds = plan.restSeconds;
  const cycleSeconds = focusSeconds + restSeconds;
  const cycleCount = Math.ceil((horizonHours * 60 * 60) / cycleSeconds);
  const cues: ScheduledFocusCue[] = [];

  for (let cycle = 0; cycle < cycleCount; cycle += 1) {
    const focusStart = session.startedAtMs + cycle * cycleSeconds * 1000 + session.accumulatedPausedMs;
    for (let round = 1; round < plan.roundsPerCycle; round += 1) {
      const atMs = focusStart + round * roundSeconds * 1000;
      if (atMs > nowMs + 1000) cues.push({
        atMs,
        title: `Round ${round} complete`,
        body: `One chime. Begin round ${round + 1} of ${plan.roundsPerCycle}.`,
        checkpoint: false,
        kind: "round",
      });
    }

    const checkpointAt = focusStart + focusSeconds * 1000;
    if (checkpointAt > nowMs + 1000) {
      const restLabel = plan.restSeconds % 60 === 0 ? `${plan.restSeconds / 60}-minute` : `${plan.restSeconds}-second`;
      cues.push(
        { atMs: checkpointAt, title: `${plan.roundsPerCycle} rounds complete`, body: `Three chimes. Begin your ${restLabel} rest.`, checkpoint: true, kind: "checkpoint" },
        { atMs: checkpointAt + 1050, title: `${plan.roundsPerCycle} rounds complete`, body: "Rest is in progress.", checkpoint: true, kind: "checkpoint" },
        { atMs: checkpointAt + 2100, title: `${plan.roundsPerCycle} rounds complete`, body: "Your next first round follows automatically.", checkpoint: true, kind: "checkpoint" },
      );
    }

    const restartAt = checkpointAt + restSeconds * 1000;
    if (restartAt > nowMs + 1000) cues.push({
      atMs: restartAt,
      title: "Rest complete",
      body: `One chime. Begin round 1 of ${plan.roundsPerCycle}.`,
      checkpoint: false,
      kind: "restart",
    });
  }
  return cues;
}
