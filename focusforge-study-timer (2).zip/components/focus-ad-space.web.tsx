import { Pressable, StyleSheet, Text, View } from "react-native";

import { formatAdFreeExpiry, isAdFree } from "@/lib/focusforge-monetization";

export function FocusAdSpace({ adFreeUntilMs, nowMs }: { adFreeUntilMs: number; nowMs: number; onRewardEarned: () => void }) {
  const adFree = isAdFree(adFreeUntilMs, nowMs);
  if (adFree) {
    return <View style={[styles.container, styles.adFreeContainer]}><View style={styles.adFreeDot} /><View><Text style={styles.adFreeEyebrow}>AD-FREE FOCUS</Text><Text style={styles.adFreeTitle}>Protected until {formatAdFreeExpiry(adFreeUntilMs)}</Text></View></View>;
  }
  return <View style={styles.container}><View style={styles.bannerFrame}><Text style={styles.adLabel}>ADVERTISEMENT</Text><Text style={styles.adPlaceholder}>Test banner loads in a custom Android build</Text></View><Pressable disabled style={styles.rewardAction}><Text style={styles.rewardText}>Rewarded ads require a custom Android build</Text></Pressable><Text style={styles.testNotice}>TEST ADS — no earnings until your AdMob IDs are added.</Text></View>;
}

const styles = StyleSheet.create({
  container: { marginTop: 18, borderRadius: 16, overflow: "hidden", borderWidth: 1, borderColor: "#D6E7D9", backgroundColor: "#FCFFFC" },
  bannerFrame: { minHeight: 56, alignItems: "center", justifyContent: "center", backgroundColor: "#F3F8F4" },
  adLabel: { color: "#718878", fontSize: 8, fontWeight: "900", letterSpacing: 1.3 },
  adPlaceholder: { color: "#45634F", fontSize: 11, fontWeight: "800", marginTop: 4 },
  rewardAction: { minHeight: 34, alignItems: "center", justifyContent: "center", borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#D6E7D9", opacity: 0.5 },
  rewardText: { color: "#087A50", fontSize: 11, fontWeight: "900" },
  testNotice: { paddingHorizontal: 12, paddingBottom: 8, color: "#788F80", fontSize: 9, fontWeight: "800", textAlign: "center" },
  adFreeContainer: { minHeight: 54, flexDirection: "row", alignItems: "center", paddingHorizontal: 15, gap: 9, backgroundColor: "#EEF9F0" },
  adFreeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#0BA66A" },
  adFreeEyebrow: { color: "#087A50", fontSize: 8, fontWeight: "900", letterSpacing: 1.2 },
  adFreeTitle: { color: "#23452E", fontSize: 12, fontWeight: "900", marginTop: 2 },
});
