import type { ActiveSession } from "@/lib/focusforge-core";

export type SessionBubblePayload = {
  startedAtMs: number;
  accumulatedPausedMs: number;
  roundMinutes: number;
  roundsPerCycle: number;
  restSeconds: number;
};

export function createSessionBubblePayload(session: ActiveSession): SessionBubblePayload {
  return {
    startedAtMs: session.startedAtMs,
    accumulatedPausedMs: session.accumulatedPausedMs,
    roundMinutes: session.plan.roundMinutes,
    roundsPerCycle: session.plan.roundsPerCycle,
    restSeconds: session.plan.restSeconds,
  };
}
