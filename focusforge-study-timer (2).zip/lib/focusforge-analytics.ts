import { localDayKey, type SessionRecord, type StudyEventType } from "./focusforge-core";

export type DayAnalytics = {
  key: string;
  label: string;
  focusedSeconds: number;
  sessions: number;
  cycles: number;
  pauses: number;
  interruptions: number;
  pausedSeconds: number;
  uninterruptedSessions: number;
  completedGoals: number;
};

export type FocusQuality = {
  score: number | null;
  level: "Needs a start" | "Building" | "Steady" | "Strong" | "Excellent";
  color: string;
  adviceTitle: string;
  advice: string;
  scoreDetail: string;
};

export type SubjectAnalytics = {
  subjectTag: string;
  focusedSeconds: number;
  sessions: number;
  pauses: number;
  interruptions: number;
};

export type TimelineEntry = SessionRecord & {
  leftPercent: number;
  widthPercent: number;
};

export type EventTimelinePoint = {
  id: string;
  type: StudyEventType;
  atMs: number;
  cumulativeCount: number;
};

function startOfDay(timestampMs: number) {
  const date = new Date(timestampMs);
  date.setHours(0, 0, 0, 0);
  return date.getTime();
}

function dayLabel(timestampMs: number) {
  return new Date(timestampMs).toLocaleDateString(undefined, { weekday: "narrow" });
}

export function getDayAnalytics(records: SessionRecord[], timestampMs: number): DayAnalytics {
  const key = localDayKey(timestampMs);
  const recordsForDay = records.filter((record) => localDayKey(record.endedAtMs) === key);
  return {
    key,
    label: dayLabel(timestampMs),
    focusedSeconds: recordsForDay.reduce((sum, record) => sum + record.focusedSeconds, 0),
    sessions: recordsForDay.length,
    cycles: recordsForDay.reduce((sum, record) => sum + record.completedBlocks, 0),
    pauses: recordsForDay.reduce((sum, record) => sum + (record.pauseCount ?? 0), 0),
    interruptions: recordsForDay.reduce((sum, record) => sum + (record.interruptionCount ?? 0), 0),
    pausedSeconds: recordsForDay.reduce((sum, record) => sum + (record.totalPausedSeconds ?? 0), 0),
    uninterruptedSessions: recordsForDay.filter((record) => (record.pauseCount ?? 0) === 0 && (record.interruptionCount ?? 0) === 0).length,
    completedGoals: recordsForDay.filter((record) => record.goalOutcome === "completed").length,
  };
}

export function getFocusQuality(day: DayAnalytics): FocusQuality {
  if (day.sessions === 0) return {
    score: null,
    level: "Needs a start",
    color: "#63816C",
    adviceTitle: "Start your first protected session",
    advice: "Complete one focused session to unlock a score based on your own pauses and app leaves.",
    scoreDetail: "No completed sessions today",
  };

  const pausedSharePenalty = day.focusedSeconds > 0 ? Math.min(12, Math.round((day.pausedSeconds / day.focusedSeconds) * 20)) : 0;
  const score = Math.max(0, Math.min(100, 100 - day.interruptions * 15 - day.pauses * 6 - pausedSharePenalty));
  const scoreDetail = `${day.interruptions} app leave${day.interruptions === 1 ? "" : "s"} · ${day.pauses} pause${day.pauses === 1 ? "" : "s"}`;

  if (day.interruptions > 0) return {
    score,
    level: score >= 70 ? "Steady" : "Building",
    color: "#D63B25",
    adviceTitle: "Protect the next session from app exits",
    advice: "Your app leaves had the largest effect on today’s score. Configure Android Priority DND, then use Screen Pinning when you do not need emergency-message access.",
    scoreDetail,
  };
  if (day.pauses >= 3 || pausedSharePenalty >= 8) return {
    score,
    level: score >= 70 ? "Steady" : "Building",
    color: "#E08A00",
    adviceTitle: "Make the next round easier to finish",
    advice: "Your sessions stayed in FocusForge, but pauses were frequent. Try one smaller custom round or prepare water, notes, and materials before starting.",
    scoreDetail,
  };
  if (day.focusedSeconds < 20 * 60) return {
    score,
    level: "Strong",
    color: "#1268A6",
    adviceTitle: "Your focus protection is working",
    advice: "Add one more round today to build study volume while keeping the same low-distraction setup.",
    scoreDetail,
  };
  return {
    score,
    level: score >= 90 ? "Excellent" : "Strong",
    color: "#087A50",
    adviceTitle: "Keep this setup for your next round",
    advice: "You kept distractions low and built meaningful focused time. Repeat the same environment, rhythm, and DND setup for your next session.",
    scoreDetail,
  };
}

export function getSevenDayAnalytics(records: SessionRecord[], nowMs: number) {
  const todayStart = startOfDay(nowMs);
  return Array.from({ length: 7 }, (_, index) => getDayAnalytics(records, todayStart - (6 - index) * 86_400_000));
}

export function getTodayTimeline(records: SessionRecord[], nowMs: number): TimelineEntry[] {
  const dayStart = startOfDay(nowMs);
  const dayEnd = dayStart + 86_400_000;
  return records
    .filter((record) => record.endedAtMs > dayStart && record.startedAtMs < dayEnd)
    .sort((a, b) => a.startedAtMs - b.startedAtMs)
    .map((record) => {
      const visibleStart = Math.max(record.startedAtMs, dayStart);
      const visibleEnd = Math.min(record.endedAtMs, dayEnd);
      const leftPercent = ((visibleStart - dayStart) / 86_400_000) * 100;
      const widthPercent = Math.max(2.5, ((visibleEnd - visibleStart) / 86_400_000) * 100);
      return { ...record, leftPercent, widthPercent };
    });
}

export function getTodayEventTimeline(records: SessionRecord[], nowMs: number): EventTimelinePoint[] {
  const dayStart = startOfDay(nowMs);
  const dayEnd = dayStart + 86_400_000;
  const rawEvents = records
    .flatMap((record) => (record.eventTimeline ?? []).map((event, index) => ({ id: `${record.id}-${event.atMs}-${index}`, ...event })))
    .filter((event) => event.atMs >= dayStart && event.atMs < dayEnd)
    .sort((a, b) => a.atMs - b.atMs || a.id.localeCompare(b.id));
  const counts: Record<StudyEventType, number> = { pause: 0, appLeave: 0, interruption: 0 };
  return rawEvents.map((event) => {
    counts[event.type] += 1;
    return { ...event, cumulativeCount: counts[event.type] };
  });
}

export function getSevenDayStart(nowMs: number) {
  return startOfDay(nowMs) - 6 * 86_400_000;
}

export function getSubjectAnalytics(records: SessionRecord[], sinceMs: number): SubjectAnalytics[] {
  const grouped = new Map<string, SubjectAnalytics>();
  for (const record of records) {
    if (record.endedAtMs < sinceMs) continue;
    const subjectTag = record.subjectTag?.trim() || "General study";
    const current = grouped.get(subjectTag) ?? { subjectTag, focusedSeconds: 0, sessions: 0, pauses: 0, interruptions: 0 };
    current.focusedSeconds += record.focusedSeconds;
    current.sessions += 1;
    current.pauses += record.pauseCount ?? 0;
    current.interruptions += record.interruptionCount ?? 0;
    grouped.set(subjectTag, current);
  }
  return [...grouped.values()].sort((a, b) => b.focusedSeconds - a.focusedSeconds || a.subjectTag.localeCompare(b.subjectTag));
}

export function getTodaySubjectAnalytics(records: SessionRecord[], nowMs: number): SubjectAnalytics[] {
  const todayKey = localDayKey(nowMs);
  return getSubjectAnalytics(records.filter((record) => localDayKey(record.endedAtMs) === todayKey), Number.NEGATIVE_INFINITY);
}
