import AsyncStorage from "@react-native-async-storage/async-storage";
import { activateKeepAwake, deactivateKeepAwake } from "expo-keep-awake";
import { AppState, Platform } from "react-native";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

import {
  DEFAULT_SETTINGS,
  STORAGE_KEYS,
  formatStudyTime,
  getFocusedSeconds,
  getSessionSnapshot,
  isValidSessionRecord,
  normalizeSessionGoal,
  normalizeSettings,
  normalizeStudyEvents,
  restoreActiveSession,
  type ActiveSession,
  type GoalOutcome,
  type LockedScreenCueSound,
  type SessionRecord,
  type StudySettings,
} from "@/lib/focusforge-core";
import {
  configureCueChannels,
  getCuePermission,
  requestCuePermission,
  cancelFocusCueSchedule,
  scheduleFocusCues,
} from "@/lib/focusforge-notifications";
import { useEmergenceCompletionAudio, useStudyCueAudio } from "@/hooks/use-study-cue-audio";
import type { CuePlaybackResult } from "@/hooks/use-study-cue-audio";
import { getCycleCueEvents } from "@/lib/cue-events";
import { normalizeNoteFolder, normalizePersonalNote, normalizeRoutineEntry, sortFolders, sortNotes, sortRoutine, type NoteFolder, type NoteFolderInput, type PersonalNote, type PersonalNoteInput, type RoutineEntry, type RoutineEntryInput } from "@/lib/focusforge-notes";
import { hideSessionBubble, showBubbleForSession } from "@/lib/session-bubble";
import { grantTwelveHourAdFreeTime } from "@/lib/focusforge-monetization";
import { EMPTY_FOCUS_GROWTH, addGardenCompletion, addHiveCluster, createHiveCluster, didCompleteGrowthJourney, drawBalancedGrowthTheme, normalizeFocusGrowth, normalizeGrowthThemeDeck, shouldResetGrowthJourney, type FocusGrowthState, type GrowthTheme } from "@/lib/focusforge-growth";

type PermissionState = "granted" | "denied" | "undetermined";

type FocusForgeContextValue = {
  ready: boolean;
  now: number;
  settings: StudySettings;
  session: ActiveSession | null;
  history: SessionRecord[];
  growth: FocusGrowthState;
  notes: PersonalNote[];
  noteFolders: NoteFolder[];
  routine: RoutineEntry[];
  permission: PermissionState;
  snapshot: ReturnType<typeof getSessionSnapshot> | null;
  updateSettings: (updates: Partial<StudySettings>) => Promise<void>;
  grantAdFreeTime: () => Promise<void>;
  startSession: (goal?: string) => Promise<void>;
  pauseSession: () => Promise<void>;
  resumeSession: () => Promise<void>;
  endSession: () => Promise<SessionRecord | null>;
  updateSessionGoalOutcome: (sessionId: string, outcome: GoalOutcome) => Promise<void>;
  saveNote: (input: PersonalNoteInput) => Promise<void>;
  deleteNote: (noteId: string) => Promise<void>;
  saveNoteFolder: (input: NoteFolderInput) => Promise<void>;
  deleteNoteFolder: (folderId: string) => Promise<void>;
  saveRoutineEntry: (input: RoutineEntryInput) => Promise<void>;
  deleteRoutineEntry: (entryId: string) => Promise<void>;
  requestCueAccess: () => Promise<void>;
  refreshCueSchedule: () => Promise<void>;
  testCue: () => Promise<CuePlaybackResult>;
  previewCueSound: (sound: LockedScreenCueSound) => Promise<CuePlaybackResult>;
  lastCueResult: CuePlaybackResult | null;
  studySummary: { today: string; blocks: number; sessions: number };
};

type FocusForgeStaticContextValue = Omit<FocusForgeContextValue, "now" | "snapshot" | "studySummary">;
type FocusForgeLiveContextValue = Pick<FocusForgeContextValue, "now" | "snapshot" | "studySummary">;

const FocusForgeStaticContext = createContext<FocusForgeStaticContextValue | null>(null);
const FocusForgeLiveContext = createContext<FocusForgeLiveContextValue | null>(null);

async function readJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const value = await AsyncStorage.getItem(key);
    if (!value) return fallback;
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function FocusForgeProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(true);
  const [now, setNow] = useState(Date.now());
  const [settings, setSettings] = useState<StudySettings>(DEFAULT_SETTINGS);
  const [session, setSession] = useState<ActiveSession | null>(null);
  const [history, setHistory] = useState<SessionRecord[]>([]);
  const [growth, setGrowth] = useState<FocusGrowthState>(EMPTY_FOCUS_GROWTH);
  const [notes, setNotes] = useState<PersonalNote[]>([]);
  const [noteFolders, setNoteFolders] = useState<NoteFolder[]>([]);
  const [routine, setRoutine] = useState<RoutineEntry[]>([]);
  const [permission, setPermission] = useState<PermissionState>("undetermined");
  const [lastCueResult, setLastCueResult] = useState<CuePlaybackResult | null>(null);
  const observedSessionIdRef = useRef<string | null>(null);
  const observedRoundsCompletedRef = useRef(0);
  const observedPhaseRef = useRef<"focus" | "reset" | "paused">("focus");
  const cueQueueRef = useRef<Promise<void>>(Promise.resolve());
  const cueScheduleQueueRef = useRef<Promise<void>>(Promise.resolve());
  const sessionRef = useRef<ActiveSession | null>(null);
  const growthRef = useRef<FocusGrowthState>(EMPTY_FOCUS_GROWTH);
  const growthThemeDeckRef = useRef<GrowthTheme[]>([]);
  const playCue = useStudyCueAudio(settings.soundEnabled);
  const playEmergenceCompletion = useEmergenceCompletionAudio(settings.soundEnabled);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const [savedSettings, savedSession, savedHistory, savedGrowth, savedGrowthThemeDeck, savedNotes, savedFolders, savedRoutine, cueStatus] = await Promise.all([
          readJson(STORAGE_KEYS.settings, DEFAULT_SETTINGS),
          readJson<ActiveSession | null>(STORAGE_KEYS.activeSession, null),
          readJson<SessionRecord[]>(STORAGE_KEYS.history, []),
          readJson<FocusGrowthState>(STORAGE_KEYS.growth, EMPTY_FOCUS_GROWTH),
          readJson<unknown>(STORAGE_KEYS.growthThemeDeck, []),
          readJson<PersonalNote[]>(STORAGE_KEYS.notes, []),
          readJson<NoteFolder[]>(STORAGE_KEYS.noteFolders, []),
          readJson<RoutineEntry[]>(STORAGE_KEYS.routine, []),
          getCuePermission(),
        ]);
        const normalizedSettings = normalizeSettings(savedSettings);
        await configureCueChannels(normalizedSettings.lockedScreenCueSound);
        if (!alive) return;
        setSettings(normalizedSettings);
        const restoredSession = restoreActiveSession(savedSession);
        sessionRef.current = restoredSession;
        setSession(restoredSession);
        setHistory(Array.isArray(savedHistory) ? savedHistory.filter(isValidSessionRecord).slice(0, 100) : []);
        const restoredGrowth = normalizeFocusGrowth(savedGrowth);
        growthRef.current = restoredGrowth;
        setGrowth(restoredGrowth);
        growthThemeDeckRef.current = normalizeGrowthThemeDeck(savedGrowthThemeDeck);
        setNotes(Array.isArray(savedNotes) ? sortNotes(savedNotes.map(normalizePersonalNote).filter((note): note is PersonalNote => Boolean(note)).slice(0, 250)) : []);
        setNoteFolders(Array.isArray(savedFolders) ? sortFolders(savedFolders.map(normalizeNoteFolder).filter((folder): folder is NoteFolder => Boolean(folder)).slice(0, 50)) : []);
        setRoutine(Array.isArray(savedRoutine) ? sortRoutine(savedRoutine.map(normalizeRoutineEntry).filter((entry): entry is RoutineEntry => Boolean(entry)).slice(0, 300)) : []);
        setPermission(cueStatus as PermissionState);
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (Platform.OS === "web") return;
    const shouldKeepAwake = Boolean(session && !session.pausedAtMs && settings.keepScreenAwake);
    if (!shouldKeepAwake) {
      void deactivateKeepAwake("focusforge-study-session");
      return;
    }
    void activateKeepAwake("focusforge-study-session");
    return () => {
      void deactivateKeepAwake("focusforge-study-session");
    };
  }, [session, settings.keepScreenAwake]);

  const persistSession = useCallback((next: ActiveSession | null) => {
    sessionRef.current = next;
    setSession(next);
    void AsyncStorage.setItem(STORAGE_KEYS.activeSession, JSON.stringify(next)).catch(() => {
      // The in-memory study session should continue even if local persistence is temporarily unavailable.
    });
  }, []);

  const persistGrowth = useCallback((next: FocusGrowthState) => {
    growthRef.current = next;
    setGrowth(next);
    void AsyncStorage.setItem(STORAGE_KEYS.growth, JSON.stringify(next)).catch(() => {
      // Rich visual progress must never block the current in-memory focus session.
    });
  }, []);

  const archiveCompletedGrowthCycle = useCallback((candidate: ActiveSession, completedAtMs: number, cycleIndex: number) => {
    if (candidate.growthTheme === "hive") {
      persistGrowth(addHiveCluster(growthRef.current, createHiveCluster({
        sessionId: candidate.id,
        cycleIndex,
        completedAtMs,
        subjectTag: candidate.subjectTag,
        roundsCompleted: candidate.plan.roundsPerCycle,
        roundsPlanned: candidate.plan.roundsPerCycle,
        status: "complete",
      })));
      return;
    }
    if (candidate.growthTheme === "butterfly") {
      persistGrowth(addGardenCompletion(growthRef.current, {
        sessionId: candidate.id,
        cycleIndex,
        subjectTag: candidate.subjectTag,
        completedAtMs,
      }));
    }
  }, [persistGrowth]);

  const archiveIncompleteHive = useCallback((candidate: ActiveSession, completedAtMs: number, roundsCompleted: number) => {
    if (candidate.growthTheme !== "hive") return;
    persistGrowth(addHiveCluster(growthRef.current, createHiveCluster({
      sessionId: candidate.id,
      completedAtMs,
      subjectTag: candidate.subjectTag,
      roundsCompleted,
      roundsPlanned: candidate.plan.roundsPerCycle,
      status: "incomplete",
    })));
  }, [persistGrowth]);

  const enqueueCueCancellation = useCallback((notificationIds: string[] = []) => {
    cueScheduleQueueRef.current = cueScheduleQueueRef.current
      .catch(() => undefined)
      .then(() => cancelFocusCueSchedule(notificationIds));
  }, []);

  const enqueueCueSchedule = useCallback((candidate: ActiveSession, sound: LockedScreenCueSound) => {
    cueScheduleQueueRef.current = cueScheduleQueueRef.current
      .catch(() => undefined)
      .then(async () => {
        const notificationIds = await scheduleFocusCues(candidate, undefined, sound);
        const latest = sessionRef.current;
        if (!notificationIds.length || !latest || latest.id !== candidate.id || latest.pausedAtMs) return;
        persistSession({ ...latest, notificationIds });
      });
    return cueScheduleQueueRef.current;
  }, [persistSession]);

  useEffect(() => {
    let previousState = AppState.currentState;
    const subscription = AppState.addEventListener("change", (nextState) => {
      const wasAway = previousState === "inactive" || previousState === "background";
      const leftFocusForge = previousState === "active" && (nextState === "inactive" || nextState === "background");
      previousState = nextState;
      if (nextState === "active") void hideSessionBubble();
      if (!session || session.pausedAtMs) return;
      const atMs = Date.now();
      if (leftFocusForge) {
        if (settings.floatingSessionBubbleEnabled) void showBubbleForSession(session);
        void persistSession({ ...session, interruptionCount: (session.interruptionCount ?? 0) + 1, eventTimeline: [...normalizeStudyEvents(session.eventTimeline), { type: "appLeave", atMs }] });
        return;
      }
      if (nextState === "active" && wasAway) void persistSession({ ...session, eventTimeline: [...normalizeStudyEvents(session.eventTimeline), { type: "interruption", atMs }] });
    });
    return () => subscription.remove();
  }, [persistSession, session, settings.floatingSessionBubbleEnabled]);

  const updateSettings = useCallback(async (updates: Partial<StudySettings>) => {
    const next = normalizeSettings({ ...settings, ...updates });
    setSettings(next);
    if (updates.floatingSessionBubbleEnabled === false) void hideSessionBubble();
    if (updates.lockedScreenCueSound && updates.lockedScreenCueSound !== settings.lockedScreenCueSound) {
      await configureCueChannels(next.lockedScreenCueSound);
      if (session && !session.pausedAtMs && permission === "granted" && next.soundEnabled) {
        enqueueCueCancellation(session.notificationIds);
        enqueueCueSchedule({ ...session, notificationIds: [] }, next.lockedScreenCueSound);
      }
    }
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(next));
    } catch {
      // Settings remain usable in-memory if local storage is not available.
    }
  }, [enqueueCueCancellation, enqueueCueSchedule, permission, session, settings]);

  const grantAdFreeTime = useCallback(async () => {
    await updateSettings({ adFreeUntilMs: grantTwelveHourAdFreeTime() });
  }, [updateSettings]);

  const requestCueAccess = useCallback(async () => {
    const status = await requestCuePermission(settings.lockedScreenCueSound);
    setPermission(status as PermissionState);
  }, [settings.lockedScreenCueSound]);

  const refreshCueSchedule = useCallback(async () => {
    if (!session || permission !== "granted") return;
    enqueueCueCancellation(session.notificationIds);
    enqueueCueSchedule({ ...session, notificationIds: [] }, settings.lockedScreenCueSound);
  }, [enqueueCueCancellation, enqueueCueSchedule, permission, session, settings.lockedScreenCueSound]);

  const startSession = useCallback(async (goal?: string) => {
    const startedAtMs = Date.now();
    const themeDraw = drawBalancedGrowthTheme(growthThemeDeckRef.current);
    growthThemeDeckRef.current = themeDraw.remainingDeck;
    void AsyncStorage.setItem(STORAGE_KEYS.growthThemeDeck, JSON.stringify(themeDraw.remainingDeck)).catch(() => {
      // The in-memory deck still prevents a repeat until the app is restarted.
    });
    const next: ActiveSession = {
      id: `focus-${startedAtMs}`,
      startedAtMs,
      accumulatedPausedMs: 0,
      plan: {
        roundMinutes: settings.roundMinutes,
        roundsPerCycle: settings.roundsPerCycle,
        restSeconds: settings.restSeconds,
      },
      subjectTag: settings.subjectTag,
      growthTheme: themeDraw.theme,
      growthJourneyStartedAtRounds: 0,
      growthJourneyIndex: 0,
      goal: normalizeSessionGoal(goal),
      eventTimeline: [],
      notificationIds: [],
    };
    persistSession(next);
    if (permission === "granted" && settings.soundEnabled) {
      enqueueCueCancellation();
      await enqueueCueSchedule(next, settings.lockedScreenCueSound);
    }
  }, [enqueueCueCancellation, enqueueCueSchedule, permission, persistSession, settings]);

  const pauseSession = useCallback(async () => {
    if (!session || session.pausedAtMs) return;
    const pausedAtMs = Date.now();
    persistSession({
      ...session,
      pausedAtMs,
      pauseCount: (session.pauseCount ?? 0) + 1,
      eventTimeline: [...normalizeStudyEvents(session.eventTimeline), { type: "pause", atMs: pausedAtMs }],
      notificationIds: [],
    });
    void hideSessionBubble();
    enqueueCueCancellation(session.notificationIds);
  }, [enqueueCueCancellation, persistSession, session]);

  const resumeSession = useCallback(async () => {
    if (!session?.pausedAtMs) return;
    const resumedAt = Date.now();
    const next: ActiveSession = {
      ...session,
      accumulatedPausedMs: session.accumulatedPausedMs + resumedAt - session.pausedAtMs,
      pausedAtMs: undefined,
      notificationIds: [],
    };
    persistSession(next);
    if (permission === "granted" && settings.soundEnabled) {
      enqueueCueSchedule(next, settings.lockedScreenCueSound);
    }
  }, [enqueueCueSchedule, permission, persistSession, session, settings.lockedScreenCueSound, settings.soundEnabled]);

  const endSession = useCallback(async () => {
    if (!session) return null;
    const endedAtMs = Date.now();
    enqueueCueCancellation(session.notificationIds);
    void hideSessionBubble();
    const snapshot = getSessionSnapshot(session, endedAtMs);
    const record: SessionRecord = {
      id: session.id,
      startedAtMs: session.startedAtMs,
      endedAtMs,
      focusedSeconds: getFocusedSeconds(session, endedAtMs),
      completedBlocks: snapshot.completedBlocks,
      pauseCount: session.pauseCount ?? 0,
      interruptionCount: session.interruptionCount ?? 0,
      totalPausedSeconds: Math.round((session.accumulatedPausedMs + (session.pausedAtMs ? endedAtMs - session.pausedAtMs : 0)) / 1000),
      eventTimeline: normalizeStudyEvents(session.eventTimeline),
      subjectTag: session.subjectTag,
      growthTheme: session.growthTheme,
      goal: session.goal,
      plan: session.plan,
    };
    for (let completedBlock = 1; completedBlock <= snapshot.completedBlocks; completedBlock += 1) archiveCompletedGrowthCycle(session, endedAtMs, completedBlock - 1);
    if (record.focusedSeconds > 0 && snapshot.phase === "focus") {
      archiveIncompleteHive(session, endedAtMs, snapshot.roundsCompleted % snapshot.roundsPerCycle);
    }
    const nextHistory = record.focusedSeconds > 0 ? [record, ...history].slice(0, 100) : history;
    setHistory(nextHistory);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.history, JSON.stringify(nextHistory));
    } catch {
      // The end action must still complete if history persistence cannot run.
    }
    persistSession(null);
    return record;
  }, [archiveCompletedGrowthCycle, archiveIncompleteHive, enqueueCueCancellation, history, persistSession, session]);

  const updateSessionGoalOutcome = useCallback(async (sessionId: string, outcome: GoalOutcome) => {
    const nextHistory = history.map((record) => record.id === sessionId && record.goal ? { ...record, goalOutcome: outcome } : record);
    setHistory(nextHistory);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.history, JSON.stringify(nextHistory));
    } catch {
      // The selected goal outcome remains visible for this app session if storage is temporarily unavailable.
    }
  }, [history]);

  const saveNote = useCallback(async (input: PersonalNoteInput) => {
    const existing = input.id ? notes.find((note) => note.id === input.id) : undefined;
    const nowMs = Date.now();
    const note = normalizePersonalNote({ ...input, id: input.id ?? `note-${nowMs}`, createdAtMs: existing?.createdAtMs ?? nowMs, updatedAtMs: nowMs });
    if (!note) return;
    const nextNotes = sortNotes([note, ...notes.filter((entry) => entry.id !== note.id)]).slice(0, 250);
    setNotes(nextNotes);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.notes, JSON.stringify(nextNotes));
    } catch {
      // Notes remain available in-memory if local persistence is temporarily unavailable.
    }
  }, [notes]);

  const deleteNote = useCallback(async (noteId: string) => {
    const nextNotes = notes.filter((note) => note.id !== noteId);
    setNotes(nextNotes);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.notes, JSON.stringify(nextNotes));
    } catch {
      // A persistence failure must not block the current in-memory deletion.
    }
  }, [notes]);

  const saveNoteFolder = useCallback(async (input: NoteFolderInput) => {
    const nowMs = Date.now();
    const folder = normalizeNoteFolder({ ...input, id: input.id ?? `folder-${nowMs}`, createdAtMs: nowMs });
    if (!folder) return;
    const nextFolders = sortFolders([folder, ...noteFolders.filter((entry) => entry.id !== folder.id)]).slice(0, 50);
    setNoteFolders(nextFolders);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.noteFolders, JSON.stringify(nextFolders));
    } catch {
      // Folders remain usable in-memory if local persistence is temporarily unavailable.
    }
  }, [noteFolders]);

  const deleteNoteFolder = useCallback(async (folderId: string) => {
    const nextFolders = noteFolders.filter((folder) => folder.id !== folderId);
    const nextNotes = notes.map((note) => note.folderId === folderId ? { ...note, folderId: undefined } : note);
    setNoteFolders(nextFolders);
    setNotes(nextNotes);
    try {
      await Promise.all([
        AsyncStorage.setItem(STORAGE_KEYS.noteFolders, JSON.stringify(nextFolders)),
        AsyncStorage.setItem(STORAGE_KEYS.notes, JSON.stringify(nextNotes)),
      ]);
    } catch {
      // Removing a folder must not hide its notes; they stay visible as unfiled in memory.
    }
  }, [noteFolders, notes]);

  const saveRoutineEntry = useCallback(async (input: RoutineEntryInput) => {
    const nowMs = Date.now();
    const entry = normalizeRoutineEntry({ ...input, id: input.id ?? `routine-${nowMs}`, updatedAtMs: nowMs });
    if (!entry) return;
    const nextRoutine = sortRoutine([entry, ...routine.filter((item) => item.id !== entry.id)]).slice(0, 300);
    setRoutine(nextRoutine);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.routine, JSON.stringify(nextRoutine));
    } catch {
      // Routine edits remain visible in-memory if local persistence is temporarily unavailable.
    }
  }, [routine]);

  const deleteRoutineEntry = useCallback(async (entryId: string) => {
    const nextRoutine = routine.filter((entry) => entry.id !== entryId);
    setRoutine(nextRoutine);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.routine, JSON.stringify(nextRoutine));
    } catch {
      // A persistence failure must not block the current in-memory deletion.
    }
  }, [routine]);

  const snapshot = useMemo(() => (session ? getSessionSnapshot(session, now) : null), [now, session]);

  useEffect(() => {
    if (!session || !snapshot || snapshot.phase === "paused") {
      observedSessionIdRef.current = null;
      observedRoundsCompletedRef.current = 0;
      observedPhaseRef.current = "focus";
      return;
    }

    if (observedSessionIdRef.current !== session.id) {
      observedSessionIdRef.current = session.id;
      observedRoundsCompletedRef.current = snapshot.roundsCompleted;
      observedPhaseRef.current = snapshot.phase;
      return;
    }

    const previousRoundsCompleted = observedRoundsCompletedRef.current;
    const events = getCycleCueEvents(
      previousRoundsCompleted,
      snapshot.roundsCompleted,
      snapshot.roundsPerCycle,
      observedPhaseRef.current,
      snapshot.phase,
      snapshot.roundNumber,
    );
    observedRoundsCompletedRef.current = snapshot.roundsCompleted;
    observedPhaseRef.current = snapshot.phase;
    const journeyStartedAtRounds = session.growthJourneyStartedAtRounds ?? 0;
    const previousJourneyRounds = Math.max(0, previousRoundsCompleted - journeyStartedAtRounds);
    const journeyRounds = Math.max(0, snapshot.roundsCompleted - journeyStartedAtRounds);
    const shouldResetVisualJourney = shouldResetGrowthJourney(snapshot.phase, snapshot.roundNumber, journeyRounds);
    if (shouldResetVisualJourney) {
      persistSession({
        ...session,
        growthJourneyStartedAtRounds: snapshot.roundsCompleted,
        growthJourneyIndex: (session.growthJourneyIndex ?? 0) + 1,
      });
    }
    const previousCompletedBlocks = Math.floor(previousRoundsCompleted / snapshot.roundsPerCycle);
    for (let completedBlock = previousCompletedBlocks + 1; completedBlock <= snapshot.completedBlocks; completedBlock += 1) archiveCompletedGrowthCycle(session, Date.now(), completedBlock - 1);
    const emergenceCompleted = didCompleteGrowthJourney(previousJourneyRounds, journeyRounds);
    if (!settings.soundEnabled) return;

    for (const event of events) {
      cueQueueRef.current = cueQueueRef.current
        .catch(() => undefined)
        .then(async () => {
          const result = await playCue(event);
          setLastCueResult(result);
        });
    }
    if (emergenceCompleted) {
      cueQueueRef.current = cueQueueRef.current
        .catch(() => undefined)
        .then(async () => {
          const result = await playEmergenceCompletion();
          if (result !== "preview-only") setLastCueResult(result);
        });
    }
  }, [archiveCompletedGrowthCycle, persistSession, playCue, playEmergenceCompletion, session, settings.soundEnabled, snapshot]);

  const testCue = useCallback(async () => {
    const result = await playCue(1);
    setLastCueResult(result);
    return result;
  }, [playCue]);
  const previewCueSound = useCallback(async (sound: LockedScreenCueSound) => {
    const result = await playCue(1, sound, true);
    setLastCueResult(result);
    return result;
  }, [playCue]);
  const studySummary = useMemo(() => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const records = history.filter((record) => record.endedAtMs >= todayStart.getTime());
    const activeFocused = session ? getFocusedSeconds(session, now) : 0;
    const focused = records.reduce((sum, record) => sum + record.focusedSeconds, activeFocused);
    const blocks = records.reduce((sum, record) => sum + record.completedBlocks, snapshot?.completedBlocks ?? 0);
    return { today: formatStudyTime(focused), blocks, sessions: records.length + (session ? 1 : 0) };
  }, [history, now, session, snapshot?.completedBlocks]);

  const staticValue = useMemo<FocusForgeStaticContextValue>(() => ({
    ready,
    settings,
    session,
    history,
    growth,
    notes,
    noteFolders,
    routine,
    permission,
    updateSettings,
    grantAdFreeTime,
    startSession,
    pauseSession,
    resumeSession,
    endSession,
    updateSessionGoalOutcome,
    saveNote,
    deleteNote,
    saveNoteFolder,
    deleteNoteFolder,
    saveRoutineEntry,
    deleteRoutineEntry,
    requestCueAccess,
    refreshCueSchedule,
    testCue,
    previewCueSound,
    lastCueResult,
  }), [deleteNote, deleteNoteFolder, deleteRoutineEntry, endSession, grantAdFreeTime, growth, history, lastCueResult, noteFolders, notes, pauseSession, permission, previewCueSound, ready, refreshCueSchedule, requestCueAccess, resumeSession, routine, saveNote, saveNoteFolder, saveRoutineEntry, session, settings, startSession, testCue, updateSessionGoalOutcome, updateSettings]);

  const liveValue = useMemo<FocusForgeLiveContextValue>(() => ({ now, snapshot, studySummary }), [now, snapshot, studySummary]);

  return <FocusForgeStaticContext.Provider value={staticValue}><FocusForgeLiveContext.Provider value={liveValue}>{children}</FocusForgeLiveContext.Provider></FocusForgeStaticContext.Provider>;
}

export function useFocusForge() {
  const staticContext = useContext(FocusForgeStaticContext);
  const liveContext = useContext(FocusForgeLiveContext);
  if (!staticContext || !liveContext) throw new Error("useFocusForge must be used inside FocusForgeProvider");
  return { ...staticContext, ...liveContext };
}

export function useFocusForgeStatic() {
  const context = useContext(FocusForgeStaticContext);
  if (!context) throw new Error("useFocusForgeStatic must be used inside FocusForgeProvider");
  return context;
}
