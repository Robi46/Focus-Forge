import { Platform } from "react-native";
import * as Notifications from "expo-notifications";
import Constants from "expo-constants";

import { DEFAULT_SETTINGS } from "@/lib/focusforge-core";
import type { ActiveSession, LockedScreenCueSound } from "@/lib/focusforge-core";
import { CUE_CHANNEL_VERSION, getCueChannelIds, getCueSoundConfig } from "@/lib/focusforge-cue-sound-config";
import { getScheduledFocusCues } from "@/lib/focusforge-cue-schedule";
import type { ScheduledFocusCue } from "@/lib/focusforge-cue-schedule";

export { getScheduledFocusCues } from "@/lib/focusforge-cue-schedule";
export type { ScheduledFocusCue } from "@/lib/focusforge-cue-schedule";

// Channels are versioned because Android preserves a channel's original sound settings.
// Version 3 requests DND bypass for FocusForge's own study cues. Android keeps
// channel settings after an update, so a new channel ID is required for the
// newly built APK to expose this setting to the user.
export const FOCUS_CHANNEL_ID = `focusforge-focus-cues-${CUE_CHANNEL_VERSION}-classic`;
export const CHECKPOINT_CHANNEL_ID = `focusforge-checkpoint-cues-${CUE_CHANNEL_VERSION}-classic`;
export const DEFAULT_CUE_HORIZON_HOURS = 24;
// Android OEMs impose different alarm limits. A bounded schedule protects the
// app from attempting thousands of alarms with very short custom rhythms.
export const MAX_SCHEDULED_CUES = 480;
// Queue a few alarms together so a long custom rhythm does not serially delay
// the first scheduled background cue on slower Android devices.
export const CUE_SCHEDULE_BATCH_SIZE = 12;

let notificationHandlerReady = false;
const isExpoGo = Constants.appOwnership === "expo";
const nativeFeaturesVersion = Number(Constants.expoConfig?.extra?.focusforgeNativeFeaturesVersion ?? 0);

/** Screen-off cue channels and bundled sounds are only reliable in the current custom Android build. */
export function hasCurrentAndroidCueBuild() {
  return Platform.OS === "android" && !isExpoGo && nativeFeaturesVersion >= 2;
}

export { getCueChannelIds, getCueSoundConfig } from "@/lib/focusforge-cue-sound-config";

function initializeNotificationHandler() {
  if (Platform.OS === "web" || notificationHandlerReady) return;
  try {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
      shouldShowBanner: false,
      shouldShowList: false,
      // Active sessions use expo-audio for the audible cue; this prevents a foreground double-beep.
      shouldPlaySound: false,
        shouldSetBadge: false,
      }),
    });
    notificationHandlerReady = true;
  } catch {
    notificationHandlerReady = false;
  }
}

export async function configureCueChannels(sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  if (!hasCurrentAndroidCueBuild()) return false;

  try {
    initializeNotificationHandler();
    const cueSound = getCueSoundConfig(sound);
    const channelIds = getCueChannelIds(sound);
    await Notifications.setNotificationChannelAsync(channelIds.focus, {
      name: `FocusForge ${cueSound.label} round beeps`,
      description: `One ${cueSound.label.toLowerCase()} audible beep after each study round.`,
      importance: Notifications.AndroidImportance.MAX,
      sound: cueSound.fileName,
      bypassDnd: true,
      vibrationPattern: [0, 120],
      enableVibrate: true,
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    });
    await Notifications.setNotificationChannelAsync(channelIds.checkpoint, {
      name: `FocusForge ${cueSound.label} rest beeps`,
      description: `Three ${cueSound.label.toLowerCase()} audible beeps before each scheduled rest.`,
      importance: Notifications.AndroidImportance.MAX,
      sound: cueSound.fileName,
      bypassDnd: true,
      vibrationPattern: [0, 120, 90, 120, 90, 120],
      enableVibrate: true,
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    });
    return true;
  } catch {
    return false;
  }
}

export async function getCuePermission() {
  if (Platform.OS === "web") return "granted" as const;
  if (isExpoGo) return "granted" as const;
  try {
    initializeNotificationHandler();
    const result = await Notifications.getPermissionsAsync();
    return result.status;
  } catch {
    return "denied" as const;
  }
}

export async function requestCuePermission(sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  if (Platform.OS === "web") return "granted" as const;
  if (isExpoGo) return "granted" as const;
  try {
    await configureCueChannels(sound);
    const current = await Notifications.getPermissionsAsync();
    if (current.status === "granted") return current.status;
    const request = await Notifications.requestPermissionsAsync();
    return request.status;
  } catch {
    return "denied" as const;
  }
}

export type CueChannelDiagnostic = {
  supported: boolean;
  channelsPresent: boolean;
  soundReady: boolean;
  bypassDndReady: boolean;
};

export async function getCueChannelDiagnostic(sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound): Promise<CueChannelDiagnostic> {
  if (Platform.OS !== "android" || isExpoGo) return { supported: false, channelsPresent: false, soundReady: false, bypassDndReady: false };
  try {
    const channelIds = getCueChannelIds(sound);
    const [roundChannel, restChannel] = await Promise.all([
      Notifications.getNotificationChannelAsync(channelIds.focus),
      Notifications.getNotificationChannelAsync(channelIds.checkpoint),
    ]);
    const channels = [roundChannel, restChannel].filter((channel): channel is Notifications.NotificationChannel => Boolean(channel));
    return {
      supported: true,
      channelsPresent: channels.length === 2,
      soundReady: channels.length === 2 && channels.every((channel) => channel.sound === "custom" || channel.sound === "default"),
      bypassDndReady: channels.length === 2 && channels.every((channel) => channel.bypassDnd),
    };
  } catch {
    return { supported: true, channelsPresent: false, soundReady: false, bypassDndReady: false };
  }
}

export async function cancelFocusCueSchedule(notificationIds: string[] = []) {
  if (Platform.OS === "web" || isExpoGo) return;
  try {
    if (notificationIds.length > 0) {
      await Promise.all(notificationIds.map((identifier) => Notifications.cancelScheduledNotificationAsync(identifier)));
      return;
    }
    // A full cancellation is a safe fallback when an earlier interrupted
    // scheduling operation did not finish persisting its identifiers.
    await Notifications.cancelAllScheduledNotificationsAsync();
  } catch {
    // The timer itself remains valid when the Android notification service is unavailable.
  }
}

async function scheduleCue(cue: ScheduledFocusCue, sessionId: string, sound: LockedScreenCueSound) {
  const cueSound = getCueSoundConfig(sound);
  const channelIds = getCueChannelIds(sound);
  return Notifications.scheduleNotificationAsync({
    content: {
      title: cue.title,
      body: cue.body,
      sound: cueSound.fileName,
      data: { focusforgeSessionId: sessionId, type: cue.kind },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: new Date(cue.atMs),
      channelId: cue.checkpoint ? channelIds.checkpoint : channelIds.focus,
    },
  });
}

export async function scheduleFocusCues(session: ActiveSession, horizonHours = DEFAULT_CUE_HORIZON_HOURS, sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  if (Platform.OS === "web" || !hasCurrentAndroidCueBuild()) return [];
  if (session.pausedAtMs) return [];
  try {
    initializeNotificationHandler();
    const channelsReady = await configureCueChannels(sound);
    if (!channelsReady) return [];

    const cues = getScheduledFocusCues(session, Date.now(), horizonHours).slice(0, MAX_SCHEDULED_CUES);
    const identifiers: string[] = [];
    for (let start = 0; start < cues.length; start += CUE_SCHEDULE_BATCH_SIZE) {
      const batch = cues.slice(start, start + CUE_SCHEDULE_BATCH_SIZE);
      const results = await Promise.allSettled(batch.map((cue) => scheduleCue(cue, session.id, sound)));
      for (const result of results) {
        if (result.status === "fulfilled") identifiers.push(result.value);
      }
    }
    return identifiers;
  } catch {
    return [];
  }
}

export async function scheduleLockedScreenCueTest(delaySeconds = 15, sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  if (!hasCurrentAndroidCueBuild()) return false;
  try {
    const channelsReady = await configureCueChannels(sound);
    if (!channelsReady) return false;
    const cueSound = getCueSoundConfig(sound);
    const channelIds = getCueChannelIds(sound);
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "FocusForge locked-screen test",
        body: "If you hear this beep while the display is locked, your cue channel can deliver sound.",
        sound: cueSound.fileName,
        data: { type: "locked-screen-test" },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: new Date(Date.now() + Math.max(8, delaySeconds) * 1000),
        channelId: channelIds.focus,
      },
    });
    return true;
  } catch {
    return false;
  }
}
