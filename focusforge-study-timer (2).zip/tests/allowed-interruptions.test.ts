import { describe, expect, it } from "vitest";
import { createManualInterruptibleApp, mergeInterruptibleApps, toggleAllowedApp } from "../lib/allowed-interruptions";

describe("allowed interruptions", () => {
  it("merges detected apps with emergency suggestions without duplicate package names", () => {
    const apps = mergeInterruptibleApps([{ id: "w", label: "WhatsApp", packageName: "com.whatsapp", detected: true }]);
    expect(apps.filter((app) => app.packageName === "com.whatsapp")).toHaveLength(1);
    expect(apps.find((app) => app.packageName === "com.whatsapp")?.detected).toBe(true);
  });

  it("adds and removes apps from the local allowlist", () => {
    expect(toggleAllowedApp([], "com.whatsapp")).toEqual(["com.whatsapp"]);
    expect(toggleAllowedApp(["com.whatsapp"], "com.whatsapp")).toEqual([]);
  });

  it("creates a normalized manual emergency app without duplicating an existing entry", () => {
    const app = createManualInterruptibleApp("  Signal   Private ", []);
    expect(app).toMatchObject({ label: "Signal Private", packageName: "manual:signal-private", manual: true });
    expect(createManualInterruptibleApp("WhatsApp", mergeInterruptibleApps([]))?.packageName).toBe("com.whatsapp");
  });
});
