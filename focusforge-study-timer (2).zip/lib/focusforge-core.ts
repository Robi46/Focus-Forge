export type FocusPhase = "focus" | "reset" | "paused";
import { normalizeGrowthTheme, type GrowthTheme } from "./focusforge-growth";

export const LOCKED_SCREEN_CUE_SOUNDS = [
  { id: "classic", label: "Classic", detail: "The familiar FocusForge cue" },
  { id: "bright", label: "Bright", detail: "A crisp, higher-pitch cue" },
  { id: "calm", label: "Calm", detail: "A softer, lower-pitch cue" },
] as const;

export type LockedScreenCueSound = (typeof LOCKED_SCREEN_CUE_SOUNDS)[number]["id"];

export type StudySettings = {
  roundMinutes: number;
  roundsPerCycle: number;
  restSeconds: number;
  weeklyGoalMinutes: number;
  subjectTag: string;
  customSubjects: string[];
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  keepScreenAwake: boolean;
  lockedScreenCueSound: LockedScreenCueSound;
  floatingSessionBubbleEnabled: boolean;
  adFreeUntilMs: number;
};

export type SessionPlan = Pick<StudySettings, "roundMinutes" | "roundsPerCycle" | "restSeconds">;

export type StudyEventType = "pause" | "appLeave" | "interruption";
export type GoalOutcome = "completed" | "partial";

export type StudyEvent = {
  type: StudyEventType;
  atMs: number;
};

export type ActiveSession = {
  id: string;
  startedAtMs: number;
  pausedAtMs?: number;
  accumulatedPausedMs: number;
  pauseCount?: number;
  interruptionCount?: number;
  eventTimeline?: StudyEvent[];
  subjectTag?: string;
  /** Drawn once at session start; optional only to keep older saved sessions readable. */
  growthTheme?: GrowthTheme;
  /** Offset of the current 28-round visual story inside the unchanged study session. */
  growthJourneyStartedAtRounds?: number;
  growthJourneyIndex?: number;
  goal?: string;
  plan: SessionPlan;
  notificationIds: string[];
};

export type SessionRecord = {
  id: string;
  startedAtMs: number;
  endedAtMs: number;
  focusedSeconds: number;
  completedBlocks: number;
  pauseCount?: number;
  interruptionCount?: number;
  totalPausedSeconds?: number;
  eventTimeline?: StudyEvent[];
  subjectTag?: string;
  growthTheme?: GrowthTheme;
  goal?: string;
  goalOutcome?: GoalOutcome;
  plan?: SessionPlan;
};

export type SessionSnapshot = {
  phase: FocusPhase;
  remainingSeconds: number;
  elapsedFocusSeconds: number;
  completedBlocks: number;
  roundsCompleted: number;
  roundNumber: number;
  roundsPerCycle: number;
  progress: number;
  nextCueSeconds: number | null;
};

export const DEFAULT_SETTINGS: StudySettings = {
  roundMinutes: 5,
  roundsPerCycle: 4,
  restSeconds: 120,
  weeklyGoalMinutes: 300,
  subjectTag: "General study",
  customSubjects: [],
  soundEnabled: true,
  hapticsEnabled: true,
  keepScreenAwake: false,
  lockedScreenCueSound: "classic",
  floatingSessionBubbleEnabled: true,
  adFreeUntilMs: 0,
};

export const DEFAULT_SESSION_PLAN: SessionPlan = {
  roundMinutes: DEFAULT_SETTINGS.roundMinutes,
  roundsPerCycle: DEFAULT_SETTINGS.roundsPerCycle,
  restSeconds: DEFAULT_SETTINGS.restSeconds,
};

export const STORAGE_KEYS = {
  settings: "focusforge.settings.v2",
  activeSession: "focusforge.active-session.v2",
  history: "focusforge.history.v1",
  growth: "focusforge.growth.v1",
  growthThemeDeck: "focusforge.growth-theme-deck.v1",
  notes: "focusforge.notes.v1",
  noteFolders: "focusforge.note-folders.v1",
  routine: "focusforge.routine.v1",
};

export function normalizeSettings(value: Partial<StudySettings> | null | undefined): StudySettings {
  return {
    roundMinutes: normalizeWholeNumber(value?.roundMinutes, DEFAULT_SETTINGS.roundMinutes, 1, 180),
    roundsPerCycle: normalizeWholeNumber(value?.roundsPerCycle, DEFAULT_SETTINGS.roundsPerCycle, 1, 12),
    restSeconds: normalizeWholeNumber(value?.restSeconds, DEFAULT_SETTINGS.restSeconds, 30, 3600),
    weeklyGoalMinutes: normalizeWholeNumber(value?.weeklyGoalMinutes, DEFAULT_SETTINGS.weeklyGoalMinutes, 30, 10_080),
    subjectTag: normalizeSubjectTag(value?.subjectTag),
    customSubjects: normalizeSubjectTags(value?.customSubjects),
    soundEnabled: value?.soundEnabled ?? DEFAULT_SETTINGS.soundEnabled,
    hapticsEnabled: value?.hapticsEnabled ?? DEFAULT_SETTINGS.hapticsEnabled,
    keepScreenAwake: value?.keepScreenAwake ?? DEFAULT_SETTINGS.keepScreenAwake,
    lockedScreenCueSound: normalizeLockedScreenCueSound(value?.lockedScreenCueSound),
    floatingSessionBubbleEnabled: value?.floatingSessionBubbleEnabled ?? DEFAULT_SETTINGS.floatingSessionBubbleEnabled,
    adFreeUntilMs: normalizeTimestamp(value?.adFreeUntilMs),
  };
}

export function normalizeLockedScreenCueSound(value: unknown): LockedScreenCueSound {
  if (typeof value === "string" && LOCKED_SCREEN_CUE_SOUNDS.some((sound) => sound.id === value)) return value as LockedScreenCueSound;
  return DEFAULT_SETTINGS.lockedScreenCueSound;
}

function normalizeTimestamp(value: unknown) {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return 0;
  return Math.round(value);
}

function normalizeWholeNumber(value: unknown, fallback: number, min: number, max: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export const SUBJECT_TAG_SUGGESTIONS = ["General study", "Mathematics", "Science", "Languages", "Reading", "Writing", "Coding", "Exam prep"] as const;

export function normalizeSubjectTag(value: unknown) {
  if (typeof value !== "string") return DEFAULT_SETTINGS.subjectTag;
  const cleaned = value.trim().replace(/\s+/g, " ").slice(0, 32);
  return cleaned || DEFAULT_SETTINGS.subjectTag;
}

export function normalizeSubjectTags(value: unknown) {
  if (!Array.isArray(value)) return [];
  const unique = new Map<string, string>();
  for (const entry of value) {
    const normalized = normalizeSubjectTag(entry);
    if (normalized === DEFAULT_SETTINGS.subjectTag) continue;
    const key = normalized.toLocaleLowerCase();
    if (!unique.has(key)) unique.set(key, normalized);
    if (unique.size === 18) break;
  }
  return [...unique.values()];
}

export function normalizeSessionGoal(value: unknown) {
  if (typeof value !== "string") return undefined;
  const cleaned = value.trim().replace(/\s+/g, " ").slice(0, 140);
  return cleaned || undefined;
}

export function normalizeStudyEvents(value: unknown): StudyEvent[] {
  if (!Array.isArray(value)) return [];
  const allowed = new Set<StudyEventType>(["pause", "appLeave", "interruption"]);
  return value
    .filter((entry): entry is StudyEvent => Boolean(entry && typeof entry === "object" && allowed.has((entry as StudyEvent).type) && Number.isFinite((entry as StudyEvent).atMs)))
    .map((entry) => ({ type: entry.type, atMs: Math.round(entry.atMs) }))
    .sort((a, b) => a.atMs - b.atMs)
    .slice(-500);
}

export function formatSessionPlan(plan: SessionPlan) {
  const restMinutes = plan.restSeconds / 60;
  const restLabel = Number.isInteger(restMinutes) ? `${restMinutes} min` : `${plan.restSeconds} sec`;
  return `${plan.roundsPerCycle} × ${plan.roundMinutes} min • ${restLabel} rest`;
}

export function isValidActiveSession(value: unknown): value is ActiveSession {
  if (!value || typeof value !== "object") return false;
  const session = value as Partial<ActiveSession>;
  return Boolean(
    typeof session.id === "string" &&
    Number.isFinite(session.startedAtMs) &&
    Number.isFinite(session.accumulatedPausedMs) &&
    session.plan &&
    Number.isFinite(session.plan.roundMinutes) &&
    Number.isFinite(session.plan.roundsPerCycle) &&
    Number.isFinite(session.plan.restSeconds),
  );
}

export function restoreActiveSession(value: unknown): ActiveSession | null {
  if (!value || typeof value !== "object") return null;
  const session = value as Partial<ActiveSession>;
  const startedAtMs = session.startedAtMs;
  const accumulatedPausedMs = session.accumulatedPausedMs;
  if (
    typeof session.id !== "string" ||
    typeof startedAtMs !== "number" ||
    !Number.isFinite(startedAtMs) ||
    typeof accumulatedPausedMs !== "number" ||
    !Number.isFinite(accumulatedPausedMs)
  ) return null;
  return {
    id: session.id,
    startedAtMs,
    pausedAtMs: Number.isFinite(session.pausedAtMs) ? session.pausedAtMs : undefined,
    accumulatedPausedMs,
    pauseCount: normalizeWholeNumber(session.pauseCount, 0, 0, Number.MAX_SAFE_INTEGER),
    interruptionCount: normalizeWholeNumber(session.interruptionCount, 0, 0, Number.MAX_SAFE_INTEGER),
    eventTimeline: normalizeStudyEvents(session.eventTimeline),
    subjectTag: normalizeSubjectTag(session.subjectTag),
    growthTheme: normalizeGrowthTheme(session.growthTheme),
    growthJourneyStartedAtRounds: normalizeWholeNumber(session.growthJourneyStartedAtRounds, 0, 0, Number.MAX_SAFE_INTEGER),
    growthJourneyIndex: normalizeWholeNumber(session.growthJourneyIndex, 0, 0, Number.MAX_SAFE_INTEGER),
    goal: normalizeSessionGoal(session.goal),
    plan: {
      roundMinutes: normalizeWholeNumber(session.plan?.roundMinutes, DEFAULT_SETTINGS.roundMinutes, 1, 180),
      roundsPerCycle: normalizeWholeNumber(session.plan?.roundsPerCycle, DEFAULT_SETTINGS.roundsPerCycle, 1, 12),
      restSeconds: normalizeWholeNumber(session.plan?.restSeconds, DEFAULT_SETTINGS.restSeconds, 30, 3600),
    },
    notificationIds: Array.isArray(session.notificationIds) ? session.notificationIds.filter((id): id is string => typeof id === "string") : [],
  };
}

export function isValidSessionRecord(value: unknown): value is SessionRecord {
  if (!value || typeof value !== "object") return false;
  const record = value as Partial<SessionRecord>;
  return Boolean(
    typeof record.id === "string" &&
    Number.isFinite(record.startedAtMs) &&
    Number.isFinite(record.endedAtMs) &&
    Number.isFinite(record.focusedSeconds) &&
    Number.isFinite(record.completedBlocks),
  );
}

export function formatClock(totalSeconds: number) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  return `${String(minutes).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

export function formatStudyTime(totalSeconds: number) {
  const minutes = Math.max(0, Math.round(totalSeconds / 60));
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours} h ${remainder} min` : `${hours} h`;
}

export function elapsedSessionMs(session: ActiveSession, nowMs: number) {
  const endpoint = session.pausedAtMs ?? nowMs;
  return Math.max(0, endpoint - session.startedAtMs - session.accumulatedPausedMs);
}

export function getSessionSnapshot(session: ActiveSession, nowMs: number): SessionSnapshot {
  if (session.pausedAtMs) {
    const pausedSnapshot = getSessionSnapshot({ ...session, pausedAtMs: undefined }, session.pausedAtMs);
    return { ...pausedSnapshot, phase: "paused" };
  }

  const roundSeconds = session.plan.roundMinutes * 60;
  const roundsPerCycle = session.plan.roundsPerCycle;
  const focusSeconds = roundSeconds * roundsPerCycle;
  const restSeconds = session.plan.restSeconds;
  const cycleSeconds = focusSeconds + restSeconds;
  const elapsedSeconds = Math.floor(elapsedSessionMs(session, nowMs) / 1000);
  const cycleIndex = Math.floor(elapsedSeconds / cycleSeconds);
  const cycleOffset = elapsedSeconds % cycleSeconds;
  const inStudyRound = cycleOffset < focusSeconds;

  if (!inStudyRound) {
    const completedBlocks = cycleIndex + 1;
    return {
      phase: "reset",
      remainingSeconds: restSeconds - (cycleOffset - focusSeconds),
      elapsedFocusSeconds: completedBlocks * focusSeconds,
      completedBlocks,
      roundsCompleted: completedBlocks * roundsPerCycle,
      roundNumber: roundsPerCycle,
      roundsPerCycle,
      progress: (cycleOffset - focusSeconds) / restSeconds,
      nextCueSeconds: null,
    };
  }

  const completedRoundsInCycle = Math.floor(cycleOffset / roundSeconds);
  const roundOffset = cycleOffset % roundSeconds;
  const roundNumber = completedRoundsInCycle + 1;
  return {
    phase: "focus",
    remainingSeconds: roundSeconds - roundOffset,
    elapsedFocusSeconds: cycleIndex * focusSeconds + cycleOffset,
    completedBlocks: cycleIndex,
    roundsCompleted: cycleIndex * roundsPerCycle + completedRoundsInCycle,
    roundNumber,
    roundsPerCycle,
    progress: roundOffset / roundSeconds,
    nextCueSeconds: roundSeconds - roundOffset,
  };
}

export function getFocusedSeconds(session: ActiveSession, nowMs: number) {
  const roundSeconds = session.plan.roundMinutes * 60;
  const focusSeconds = roundSeconds * session.plan.roundsPerCycle;
  const restSeconds = session.plan.restSeconds;
  const elapsedSeconds = Math.floor(elapsedSessionMs(session, nowMs) / 1000);
  const cycleSeconds = focusSeconds + restSeconds;
  const wholeCycles = Math.floor(elapsedSeconds / cycleSeconds);
  return wholeCycles * focusSeconds + Math.min(focusSeconds, elapsedSeconds % cycleSeconds);
}

export function localDayKey(timestampMs: number) {
  const date = new Date(timestampMs);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
