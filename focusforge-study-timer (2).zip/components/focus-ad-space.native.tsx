import { createElement, useEffect, useRef, useState } from "react";
import Constants from "expo-constants";
import { ActivityIndicator, NativeModules, Platform, Pressable, StyleSheet, Text, View } from "react-native";

import { ADMOB_BANNER_UNIT_ID, ADMOB_REWARDED_UNIT_ID, IS_ADMOB_TEST_MODE } from "@/lib/focusforge-ad-config";
import { canLoadGoogleMobileAds, hasGoogleMobileAdsNativeModule } from "@/lib/focusforge-ad-runtime";
import { formatAdFreeExpiry, isAdFree } from "@/lib/focusforge-monetization";

type AdsSdk = {
  BannerAd: unknown;
  BannerAdSize: { LARGE_ANCHORED_ADAPTIVE_BANNER: string };
  RewardedAd: { createForAdRequest: (adUnitId: string) => RewardedInstance };
  RewardedAdEventType: { LOADED: string; EARNED_REWARD: string; CLOSED: string };
  AdsConsent: { gatherConsent: () => Promise<void>; getConsentInfo: () => Promise<{ canRequestAds: boolean }> };
  default: () => { initialize: () => Promise<void> };
};

type RewardedInstance = {
  load: () => void;
  show: () => Promise<void>;
  addAdEventListener: (event: string, listener: () => void) => () => void;
};

function getAdsSdk(nativeModuleIncluded: boolean): AdsSdk | null {
  if (Platform.OS === "web" || !nativeModuleIncluded) return null;
  try {
    return require("react-native-google-mobile-ads") as AdsSdk;
  } catch {
    return null;
  }
}

export function FocusAdSpace({ adFreeUntilMs, nowMs, onRewardEarned }: { adFreeUntilMs: number; nowMs: number; onRewardEarned: () => void }) {
  const adFree = isAdFree(adFreeUntilMs, nowMs);
  const [adsReady, setAdsReady] = useState(false);
  const [bannerLoadState, setBannerLoadState] = useState<"checking" | "loading" | "loaded" | "unavailable">("checking");
  const [rewardReady, setRewardReady] = useState(false);
  const [rewardOpening, setRewardOpening] = useState(false);
  const rewardedRef = useRef<RewardedInstance | null>(null);
  const nativeModuleIncluded = hasGoogleMobileAdsNativeModule(NativeModules);
  const adsNativeBuildEnabled = Constants.expoConfig?.extra?.focusforgeAdsNativeBuild === true;
  const canLoadAdsSdk = canLoadGoogleMobileAds({ appOwnership: Constants.appOwnership, adsNativeBuildEnabled, nativeModuleIncluded });
  const sdk = getAdsSdk(canLoadAdsSdk);

  useEffect(() => {
    if (!sdk) {
      setBannerLoadState("unavailable");
      return;
    }
    let alive = true;
    const start = async () => {
      try {
        await sdk.AdsConsent.gatherConsent();
        const info = await sdk.AdsConsent.getConsentInfo();
        if (!info.canRequestAds || !alive) {
          if (alive) setBannerLoadState("unavailable");
          return;
        }
        await sdk.default().initialize();
        if (alive) {
          setAdsReady(true);
          setBannerLoadState("loading");
        }
      } catch {
        // Google UMP may use the prior session's consent state. Do not interrupt studying when it cannot load.
        if (alive) setBannerLoadState("unavailable");
      }
    };
    void start();
    return () => { alive = false; };
  }, [sdk]);

  useEffect(() => {
    if (!sdk || !adsReady || adFree) return;
    const rewarded = sdk.RewardedAd.createForAdRequest(ADMOB_REWARDED_UNIT_ID);
    rewardedRef.current = rewarded;
    const removeLoaded = rewarded.addAdEventListener(sdk.RewardedAdEventType.LOADED, () => setRewardReady(true));
    const removeReward = rewarded.addAdEventListener(sdk.RewardedAdEventType.EARNED_REWARD, () => {
      onRewardEarned();
      setRewardReady(false);
    });
    const removeClosed = rewarded.addAdEventListener(sdk.RewardedAdEventType.CLOSED, () => {
      setRewardOpening(false);
      setRewardReady(false);
      rewarded.load();
    });
    rewarded.load();
    return () => {
      removeLoaded();
      removeReward();
      removeClosed();
      rewardedRef.current = null;
    };
  }, [adFree, adsReady, onRewardEarned, sdk]);

  const showRewardedAd = async () => {
    if (!rewardReady || !rewardedRef.current) return;
    setRewardOpening(true);
    try {
      await rewardedRef.current.show();
    } catch {
      setRewardOpening(false);
      setRewardReady(false);
      rewardedRef.current.load();
    }
  };

  if (adFree) {
    return <View style={[styles.container, styles.adFreeContainer]}><View style={styles.adFreeDot} /><View style={styles.copy}><Text style={styles.adFreeEyebrow}>AD-FREE FOCUS</Text><Text style={styles.adFreeTitle}>Protected until {formatAdFreeExpiry(adFreeUntilMs)}</Text></View></View>;
  }

  return <View style={styles.container}>
    <View style={styles.bannerFrame}>
      {sdk && adsReady ? <>{createElement(sdk.BannerAd as never, { unitId: ADMOB_BANNER_UNIT_ID, size: sdk.BannerAdSize.LARGE_ANCHORED_ADAPTIVE_BANNER, requestOptions: { requestNonPersonalizedAdsOnly: false }, onAdLoaded: () => setBannerLoadState("loaded"), onAdFailedToLoad: () => setBannerLoadState("unavailable") })}{bannerLoadState === "loading" ? <View style={styles.loadingOverlay}><ActivityIndicator size="small" color="#087A50" /><Text style={styles.loadingText}>Loading a small study break…</Text></View> : null}</> : <View style={styles.placeholderCopy}>{bannerLoadState === "checking" ? <ActivityIndicator size="small" color="#087A50" /> : null}<Text style={styles.adLabel}>ADVERTISEMENT</Text><Text style={styles.adPlaceholder}>{!canLoadAdsSdk ? "Ads activate after installing the newest Android build" : bannerLoadState === "unavailable" ? "Ad space is unavailable right now" : "Preparing your ad choices…"}</Text></View>}
    </View>
    <Pressable disabled={!rewardReady || rewardOpening} onPress={() => void showRewardedAd()} style={({ pressed }) => [styles.rewardAction, (!rewardReady || rewardOpening) && styles.rewardActionDisabled, pressed && rewardReady && { opacity: 0.7 }]}>
      <Text style={styles.rewardText}>{rewardOpening ? "Opening reward…" : rewardReady ? "Watch an ad for 12 h ad-free" : bannerLoadState === "unavailable" ? "Reward ads unavailable in this build" : "Preparing 12 h ad-free reward"}</Text>
    </Pressable>
    {IS_ADMOB_TEST_MODE ? <Text style={styles.testNotice}>TEST ADS — no earnings until your AdMob IDs are added.</Text> : null}
  </View>;
}

const styles = StyleSheet.create({
  container: { marginTop: 18, borderRadius: 16, overflow: "hidden", borderWidth: 1, borderColor: "#D6E7D9", backgroundColor: "#FCFFFC" },
  bannerFrame: { minHeight: 56, alignItems: "center", justifyContent: "center", backgroundColor: "#F3F8F4", position: "relative" },
  placeholderCopy: { alignItems: "center", justifyContent: "center", gap: 4, paddingHorizontal: 12 },
  loadingOverlay: { ...StyleSheet.absoluteFillObject, alignItems: "center", justifyContent: "center", gap: 5, backgroundColor: "#F3F8F4" },
  loadingText: { color: "#45634F", fontSize: 11, fontWeight: "800" },
  adLabel: { color: "#718878", fontSize: 8, fontWeight: "900", letterSpacing: 1.3 },
  adPlaceholder: { color: "#45634F", fontSize: 11, fontWeight: "800", marginTop: 4 },
  rewardAction: { minHeight: 34, alignItems: "center", justifyContent: "center", borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#D6E7D9" },
  rewardActionDisabled: { opacity: 0.48 },
  rewardText: { color: "#087A50", fontSize: 11, fontWeight: "900" },
  testNotice: { paddingHorizontal: 12, paddingBottom: 8, color: "#788F80", fontSize: 9, fontWeight: "800", textAlign: "center" },
  adFreeContainer: { minHeight: 54, flexDirection: "row", alignItems: "center", paddingHorizontal: 15, gap: 9, backgroundColor: "#EEF9F0" },
  adFreeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#0BA66A" },
  copy: { flex: 1 },
  adFreeEyebrow: { color: "#087A50", fontSize: 8, fontWeight: "900", letterSpacing: 1.2 },
  adFreeTitle: { color: "#23452E", fontSize: 12, fontWeight: "900", marginTop: 2 },
});
