import { DEFAULT_SETTINGS } from "./focusforge-core";
import type { LockedScreenCueSound } from "./focusforge-core";

export const CUE_CHANNEL_VERSION = "v4";

const CUE_SOUND_CONFIG: Record<LockedScreenCueSound, { fileName: string; suffix: string; label: string }> = {
  classic: { fileName: "focusforge_beep.wav", suffix: "classic", label: "Classic" },
  bright: { fileName: "focusforge_bright.wav", suffix: "bright", label: "Bright" },
  calm: { fileName: "focusforge_calm.wav", suffix: "calm", label: "Calm" },
};

export function getCueSoundConfig(sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  return CUE_SOUND_CONFIG[sound];
}

export function getCueChannelIds(sound: LockedScreenCueSound = DEFAULT_SETTINGS.lockedScreenCueSound) {
  const { suffix } = getCueSoundConfig(sound);
  return {
    focus: `focusforge-focus-cues-${CUE_CHANNEL_VERSION}-${suffix}`,
    checkpoint: `focusforge-checkpoint-cues-${CUE_CHANNEL_VERSION}-${suffix}`,
  };
}
