import { describe, expect, it } from "vitest";

import { AD_FREE_REWARD_MS, grantTwelveHourAdFreeTime, isAdFree } from "../lib/focusforge-monetization";
import { canLoadGoogleMobileAds, hasGoogleMobileAdsNativeModule } from "../lib/focusforge-ad-runtime";

describe("FocusForge monetization state", () => {
  it("grants exactly twelve hours of ad-free time after a verified rewarded-ad completion", () => {
    const now = 1_700_000_000_000;
    expect(grantTwelveHourAdFreeTime(now)).toBe(now + AD_FREE_REWARD_MS);
  });

  it("only treats a future expiry as ad-free", () => {
    expect(isAdFree(110, 100)).toBe(true);
    expect(isAdFree(100, 100)).toBe(false);
    expect(isAdFree(0, 100)).toBe(false);
  });

  it("only allows the Google Ads package in a marked custom build with the native module", () => {
    expect(hasGoogleMobileAdsNativeModule({})).toBe(false);
    expect(hasGoogleMobileAdsNativeModule(undefined)).toBe(false);
    expect(hasGoogleMobileAdsNativeModule({ RNGoogleMobileAdsModule: {} })).toBe(true);
    expect(canLoadGoogleMobileAds({ appOwnership: "expo", adsNativeBuildEnabled: true, nativeModuleIncluded: true })).toBe(false);
    expect(canLoadGoogleMobileAds({ appOwnership: "standalone", adsNativeBuildEnabled: false, nativeModuleIncluded: true })).toBe(false);
    expect(canLoadGoogleMobileAds({ appOwnership: "standalone", adsNativeBuildEnabled: true, nativeModuleIncluded: true })).toBe(true);
  });
});
