import { useState } from "react";
import { StyleSheet, Text, View, useWindowDimensions } from "react-native";
import Svg, { Circle, G, Line, Polyline, Text as SvgText } from "react-native-svg";

import { DataZoomChart, type TimeWindow } from "@/components/interactive-chart-frame";
import { getTimeTicks, timePositionInWindow } from "@/lib/chart-time-window";
import { formatStudyTime } from "@/lib/focusforge-core";
import type { DayAnalytics, EventTimelinePoint, SubjectAnalytics, TimelineEntry } from "@/lib/focusforge-analytics";

const LEFT = 42;
const RIGHT = 15;
const TOP = 18;
const BOTTOM = 31;
const PLOT_HEIGHT = 166;
const SUBJECT_COLORS = ["#087A50", "#1268A6", "#8B4EC8", "#E08A00", "#D63B25", "#008D9A"];
const EVENT_COLORS = { pause: "#E08A00", appLeave: "#D63B25", interruption: "#8B4EC8" } as const;

function minutesLabel(seconds: number) {
  const minutes = Math.round(seconds / 60);
  return minutes >= 60 ? `${Math.floor(minutes / 60)}h${minutes % 60 ? ` ${minutes % 60}m` : ""}` : `${minutes}m`;
}

function axisUpperBound(seconds: number) {
  const minutes = Math.max(1, Math.ceil(seconds / 60));
  const step = minutes <= 15 ? 5 : minutes <= 60 ? 15 : minutes <= 180 ? 30 : 60;
  return Math.ceil(minutes / step) * step * 60;
}

function timeOfDay(timestampMs: number) {
  const date = new Date(timestampMs);
  return date.getHours() + date.getMinutes() / 60 + date.getSeconds() / 3600;
}

function preciseTimeLabel(timestampMs: number) {
  const date = new Date(timestampMs);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function hourLabel(hour: number, span: number) {
  const totalMinutes = Math.round(hour * 60);
  const normalized = ((totalMinutes % 1440) + 1440) % 1440;
  const wholeHour = Math.floor(normalized / 60);
  const minutes = normalized % 60;
  const suffix = wholeHour < 12 ? "a" : "p";
  const displayHour = wholeHour % 12 || 12;
  if (span <= 6) return `${displayHour}:${String(minutes).padStart(2, "0")}${suffix}`;
  return minutes === 0 ? `${displayHour}${suffix}` : `${displayHour}:${String(minutes).padStart(2, "0")}${suffix}`;
}

function abbreviateSubject(subject: string) {
  return subject.length > 10 ? `${subject.slice(0, 9)}…` : subject;
}

function ChartInsight({ children, tone = "#087A50" }: { children: string; tone?: string }) {
  return <View style={[styles.insight, { borderColor: `${tone}55`, backgroundColor: `${tone}10` }]}><Text style={[styles.insightText, { color: tone }]}>{children}</Text></View>;
}

function TimeGrid({ width, yTicks, yMax, window, yFormatter }: { width: number; yTicks: number[]; yMax: number; window: TimeWindow; yFormatter: (value: number) => string }) {
  const plotWidth = width - LEFT - RIGHT;
  const span = window.endHour - window.startHour;
  const ticks = getTimeTicks(window);
  return <>
    {yTicks.map((tick) => { const y = TOP + PLOT_HEIGHT - (tick / yMax) * PLOT_HEIGHT; return <G key={`y-${tick}`}><Line x1={LEFT} y1={y} x2={width - RIGHT} y2={y} stroke="#DCEBE0" strokeWidth={1} /><SvgText x={LEFT - 7} y={y + 3.5} fill="#6F8977" fontSize={9} fontWeight="700" textAnchor="end">{yFormatter(tick)}</SvgText></G>; })}
    {ticks.map((tick) => { const x = LEFT + ((tick - window.startHour) / span) * plotWidth; return <G key={`x-${tick}`}><Line x1={x} y1={TOP} x2={x} y2={TOP + PLOT_HEIGHT} stroke="#EEF5EF" strokeWidth={1} /><SvgText x={x} y={TOP + PLOT_HEIGHT + 19} fill="#55735F" fontSize={8} fontWeight="900" textAnchor="middle">{hourLabel(tick, span)}</SvgText></G>; })}
    <Line x1={LEFT} y1={TOP} x2={LEFT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} />
    <Line x1={LEFT} y1={TOP + PLOT_HEIGHT} x2={width - RIGHT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} />
  </>;
}

export function SevenDayCoordinateChart({ days }: { days: DayAnalytics[] }) {
  const { width: windowWidth } = useWindowDimensions();
  const width = Math.max(270, windowWidth - 74);
  const height = TOP + PLOT_HEIGHT + BOTTOM;
  const plotWidth = width - LEFT - RIGHT;
  const yMax = axisUpperBound(Math.max(...days.map((day) => day.focusedSeconds)));
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((fraction) => Math.round(yMax * fraction));
  const points = days.map((day, index) => ({ x: LEFT + (days.length === 1 ? plotWidth / 2 : (index / (days.length - 1)) * plotWidth), y: TOP + PLOT_HEIGHT - (day.focusedSeconds / yMax) * PLOT_HEIGHT, ...day }));
  const peak = [...days].sort((a, b) => b.focusedSeconds - a.focusedSeconds)[0];
  return <View><View style={styles.axisHint}><Text style={styles.axisHintText}>Y · focused minutes</Text><Text style={styles.axisHintText}>X · day of week</Text></View><Svg width={width} height={height}>{ticks.map((tick) => { const y = TOP + PLOT_HEIGHT - (tick / yMax) * PLOT_HEIGHT; return <G key={tick}><Line x1={LEFT} y1={y} x2={width - RIGHT} y2={y} stroke="#DCEBE0" strokeWidth={1} /><SvgText x={LEFT - 7} y={y + 3.5} fill="#6F8977" fontSize={9} fontWeight="700" textAnchor="end">{minutesLabel(tick)}</SvgText></G>; })}<Line x1={LEFT} y1={TOP} x2={LEFT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} /><Line x1={LEFT} y1={TOP + PLOT_HEIGHT} x2={width - RIGHT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} />{points.some((point) => point.focusedSeconds > 0) ? <Polyline points={points.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke="#087A50" strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" /> : null}{points.map((point) => <G key={point.key}><Circle cx={point.x} cy={point.y} r={point.focusedSeconds > 0 ? 5.5 : 3.5} fill={point.focusedSeconds > 0 ? "#087A50" : "#C6DACB"} stroke="#FFFFFF" strokeWidth={2} /><SvgText x={point.x} y={TOP + PLOT_HEIGHT + 19} fill="#55735F" fontSize={10} fontWeight="800" textAnchor="middle">{point.label}</SvgText></G>)}</Svg><View style={styles.coordinateFooter}><View><Text style={styles.coordinateValue}>{formatStudyTime(days.reduce((sum, day) => sum + day.focusedSeconds, 0))}</Text><Text style={styles.coordinateCaption}>7-day focused total</Text></View><View style={styles.peakDetail}><Text style={styles.peakValue}>{peak.focusedSeconds ? minutesLabel(peak.focusedSeconds) : "—"}</Text><Text style={styles.coordinateCaption}>peak · {peak.label}</Text></View></View></View>;
}

export function CompletedGoalsChart({ days }: { days: DayAnalytics[] }) {
  const { width: windowWidth } = useWindowDimensions();
  const width = Math.max(270, windowWidth - 74);
  const height = TOP + PLOT_HEIGHT + BOTTOM;
  const plotWidth = width - LEFT - RIGHT;
  const total = days.reduce((sum, day) => sum + day.completedGoals, 0);
  const peak = [...days].sort((a, b) => b.completedGoals - a.completedGoals)[0];
  const yMax = Math.max(1, ...days.map((day) => day.completedGoals));
  const divisions = Math.min(4, yMax);
  const ticks = Array.from({ length: divisions + 1 }, (_, index) => Math.round((index / divisions) * yMax));
  const points = days.map((day, index) => ({ x: LEFT + (days.length === 1 ? plotWidth / 2 : (index / (days.length - 1)) * plotWidth), y: TOP + PLOT_HEIGHT - (day.completedGoals / yMax) * PLOT_HEIGHT, ...day }));
  return <View><View style={styles.axisHint}><Text style={styles.axisHintText}>Y · completed goals</Text><Text style={styles.axisHintText}>X · day of week</Text></View><Svg width={width} height={height} accessibilityLabel="Seven-day completed goals chart">{ticks.map((tick) => { const y = TOP + PLOT_HEIGHT - (tick / yMax) * PLOT_HEIGHT; return <G key={tick}><Line x1={LEFT} y1={y} x2={width - RIGHT} y2={y} stroke="#DCEBE0" strokeWidth={1} /><SvgText x={LEFT - 7} y={y + 3.5} fill="#6F8977" fontSize={9} fontWeight="700" textAnchor="end">{tick}</SvgText></G>; })}<Line x1={LEFT} y1={TOP} x2={LEFT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} /><Line x1={LEFT} y1={TOP + PLOT_HEIGHT} x2={width - RIGHT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} />{points.some((point) => point.completedGoals > 0) ? <Polyline points={points.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke="#1268A6" strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" /> : null}{points.map((point) => <G key={point.key}><Line x1={point.x} y1={point.y} x2={point.x} y2={TOP + PLOT_HEIGHT} stroke="#1268A6" strokeOpacity={point.completedGoals ? 0.28 : 0} strokeWidth={2} strokeDasharray="4 3" /><Circle cx={point.x} cy={point.y} r={point.completedGoals ? 6 : 3.5} fill={point.completedGoals ? "#1268A6" : "#C6DACB"} stroke="#FFFFFF" strokeWidth={2} />{point.completedGoals ? <SvgText x={point.x} y={point.y - 12} fill="#1268A6" fontSize={10} fontWeight="900" textAnchor="middle">{point.completedGoals}</SvgText> : null}<SvgText x={point.x} y={TOP + PLOT_HEIGHT + 19} fill="#55735F" fontSize={10} fontWeight="800" textAnchor="middle">{point.label}</SvgText></G>)}</Svg><View style={styles.coordinateFooter}><View><Text style={styles.coordinateValue}>{total}</Text><Text style={styles.coordinateCaption}>completed goals · 7 days</Text></View><View style={styles.peakDetail}><Text style={styles.peakValue}>{peak.completedGoals || "—"}</Text><Text style={styles.coordinateCaption}>peak · {peak.label}</Text></View></View></View>;
}

export function TodaySessionLengthChart({ entries }: { entries: TimelineEntry[] }) {
  const { width: windowWidth } = useWindowDimensions();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const width = Math.max(270, windowWidth - 74);
  const height = TOP + PLOT_HEIGHT + BOTTOM;
  const plotWidth = width - LEFT - RIGHT;
  if (!entries.length) return <View style={styles.emptyTimeline}><Text style={styles.emptyText}>Complete a study session today to plot its length against its time-of-day position.</Text></View>;
  const yMax = axisUpperBound(Math.max(...entries.map((entry) => entry.focusedSeconds)));
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((fraction) => Math.round(yMax * fraction));

  return <View><DataZoomChart plotWidth={plotWidth}>{(window) => {
    const span = window.endHour - window.startHour;
    const points = entries.filter((entry) => { const time = timeOfDay(entry.startedAtMs); return time >= window.startHour && time <= window.endHour; }).map((entry) => ({ x: LEFT + timePositionInWindow(timeOfDay(entry.startedAtMs), window, plotWidth), y: TOP + PLOT_HEIGHT - (entry.focusedSeconds / yMax) * PLOT_HEIGHT, ...entry }));
    const selected = points.find((point) => point.id === selectedId);
    return <View><View style={styles.axisHint}><Text style={styles.axisHintText}>Y · focused session length</Text><Text style={styles.axisHintText}>X · exact start time</Text></View><Svg width={width} height={height} accessibilityLabel="Data-domain zoomable session length chart"><TimeGrid width={width} yTicks={yTicks} yMax={yMax} window={window} yFormatter={minutesLabel} />{points.length > 1 ? <Polyline points={points.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke="#E17817" strokeOpacity={0.45} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" /> : null}{points.map((point) => <G key={point.id}><Line x1={point.x} y1={point.y} x2={point.x} y2={TOP + PLOT_HEIGHT} stroke="#E17817" strokeOpacity={0.32} strokeWidth={2} strokeDasharray="4 3" /><Circle onPress={() => setSelectedId(point.id)} cx={point.x} cy={point.y} r={selectedId === point.id ? 8.5 : 6.5} fill="#E17817" stroke="#FFFFFF" strokeWidth={2.3} /><SvgText x={point.x} y={point.y - 13} fill="#C7670B" fontSize={10} fontWeight="900" textAnchor="middle">{minutesLabel(point.focusedSeconds)}</SvgText><SvgText x={point.x} y={TOP + PLOT_HEIGHT + 31} fill="#C7670B" fontSize={8} fontWeight="900" textAnchor="middle">{preciseTimeLabel(point.startedAtMs)}</SvgText></G>)}</Svg>{selected ? <ChartInsight tone="#E17817">{`${preciseTimeLabel(selected.startedAtMs)} start · ${formatStudyTime(selected.focusedSeconds)} focused`}</ChartInsight> : points.length ? <Text style={styles.tapHint}>Zoom for finer clock labels; tap a point for its exact time and duration.</Text> : <Text style={styles.tapHint}>No session starts in this time window. Pan horizontally to inspect another range.</Text>}</View>;
  }}</DataZoomChart></View>;
}

export function TodayEventTimelineChart({ events }: { events: EventTimelinePoint[] }) {
  const { width: windowWidth } = useWindowDimensions();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const width = Math.max(270, windowWidth - 74);
  const height = TOP + PLOT_HEIGHT + BOTTOM;
  const plotWidth = width - LEFT - RIGHT;
  if (!events.length) return <View style={styles.emptyTimeline}><Text style={styles.emptyText}>No timestamped pauses, app leaves, or return interruptions have occurred today. New active sessions record these events as they happen.</Text></View>;
  const yMax = Math.max(1, ...events.map((event) => event.cumulativeCount));
  const divisor = Math.min(4, yMax);
  const yTicks = Array.from({ length: divisor + 1 }, (_, index) => Math.round((index / divisor) * yMax));
  const types = ["pause", "appLeave", "interruption"] as const;

  return <View><DataZoomChart plotWidth={plotWidth}>{(window) => {
    const span = window.endHour - window.startHour;
    const points = events.filter((event) => { const time = timeOfDay(event.atMs); return time >= window.startHour && time <= window.endHour; }).map((event) => ({ ...event, x: LEFT + timePositionInWindow(timeOfDay(event.atMs), window, plotWidth), y: TOP + PLOT_HEIGHT - (event.cumulativeCount / yMax) * PLOT_HEIGHT }));
    const selected = points.find((point) => point.id === selectedId);
    return <View><View style={styles.axisHint}><Text style={styles.axisHintText}>Y · cumulative occurrences</Text><Text style={styles.axisHintText}>X · exact event time</Text></View><Svg width={width} height={height} accessibilityLabel="Data-domain zoomable full-day event occurrence chart"><TimeGrid width={width} yTicks={yTicks} yMax={yMax} window={window} yFormatter={(value) => String(value)} />{types.map((type) => { const series = points.filter((point) => point.type === type); return series.length > 1 ? <Polyline key={type} points={series.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke={EVENT_COLORS[type]} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" /> : null; })}{points.map((point) => <G key={point.id}><Line x1={point.x} y1={point.y} x2={point.x} y2={TOP + PLOT_HEIGHT} stroke={EVENT_COLORS[point.type]} strokeOpacity={0.28} strokeWidth={2} strokeDasharray="3 3" /><Circle onPress={() => setSelectedId(point.id)} cx={point.x} cy={point.y} r={selectedId === point.id ? 8 : 6} fill={EVENT_COLORS[point.type]} stroke="#FFFFFF" strokeWidth={2.2} /><SvgText x={point.x} y={point.y - 11} fill={EVENT_COLORS[point.type]} fontSize={9} fontWeight="900" textAnchor="middle">{point.cumulativeCount}</SvgText><SvgText x={point.x} y={TOP + PLOT_HEIGHT + 31} fill={EVENT_COLORS[point.type]} fontSize={8} fontWeight="900" textAnchor="middle">{preciseTimeLabel(point.atMs)}</SvgText></G>)}</Svg><View style={styles.legend}><EventLegend type="pause" label="Pause" /><EventLegend type="appLeave" label="App leave" /><EventLegend type="interruption" label="Return interruption" /></View>{selected ? <ChartInsight tone={EVENT_COLORS[selected.type]}>{`${eventLabel(selected.type)} · ${preciseTimeLabel(selected.atMs)} · occurrence #${selected.cumulativeCount}`}</ChartInsight> : points.length ? <Text style={styles.tapHint}>Zoom for finer clock labels; tap a point for its exact time and occurrence number.</Text> : <Text style={styles.tapHint}>No events in this time window. Pan horizontally to inspect another range.</Text>}</View>;
  }}</DataZoomChart></View>;
}

export function SubjectDistributionChart({ subjects, rangeLabel }: { subjects: SubjectAnalytics[]; rangeLabel: "Today" | "Last 7 days" }) {
  const { width: windowWidth } = useWindowDimensions();
  const width = Math.max(270, windowWidth - 74);
  const bottom = 49;
  const height = TOP + PLOT_HEIGHT + bottom;
  const plotWidth = width - LEFT - RIGHT;
  if (!subjects.length) return <View style={styles.emptyTimeline}><Text style={styles.emptyText}>Tag and complete a study session to plot your {rangeLabel.toLocaleLowerCase()} subject distribution.</Text></View>;
  const yMax = axisUpperBound(Math.max(...subjects.map((subject) => subject.focusedSeconds)));
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((fraction) => Math.round(yMax * fraction));
  const points = subjects.map((subject, index) => ({ ...subject, color: SUBJECT_COLORS[index % SUBJECT_COLORS.length], x: LEFT + (subjects.length === 1 ? plotWidth / 2 : (index / (subjects.length - 1)) * plotWidth), y: TOP + PLOT_HEIGHT - (subject.focusedSeconds / yMax) * PLOT_HEIGHT }));
  return <View><View style={styles.axisHint}><Text style={styles.axisHintText}>Y · focused minutes</Text><Text style={styles.axisHintText}>X · subject</Text></View><Svg width={width} height={height}>{yTicks.map((tick) => { const y = TOP + PLOT_HEIGHT - (tick / yMax) * PLOT_HEIGHT; return <G key={tick}><Line x1={LEFT} y1={y} x2={width - RIGHT} y2={y} stroke="#DCEBE0" strokeWidth={1} /><SvgText x={LEFT - 7} y={y + 3.5} fill="#6F8977" fontSize={9} fontWeight="700" textAnchor="end">{minutesLabel(tick)}</SvgText></G>; })}<Line x1={LEFT} y1={TOP} x2={LEFT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} /><Line x1={LEFT} y1={TOP + PLOT_HEIGHT} x2={width - RIGHT} y2={TOP + PLOT_HEIGHT} stroke="#96BFA0" strokeWidth={1.2} />{points.map((point) => <G key={point.subjectTag}><Line x1={point.x} y1={point.y} x2={point.x} y2={TOP + PLOT_HEIGHT} stroke={point.color} strokeOpacity={0.32} strokeWidth={3} /><Circle cx={point.x} cy={point.y} r={7} fill={point.color} stroke="#FFFFFF" strokeWidth={2.5} /><SvgText x={point.x} y={point.y - 13} fill={point.color} fontSize={10} fontWeight="900" textAnchor="middle">{minutesLabel(point.focusedSeconds)}</SvgText><SvgText x={point.x} y={TOP + PLOT_HEIGHT + 19} fill="#55735F" fontSize={9} fontWeight="800" textAnchor="middle">{abbreviateSubject(point.subjectTag)}</SvgText></G>)}</Svg><View style={styles.legend}>{points.map((point) => <View key={point.subjectTag} style={[styles.legendItem, { borderColor: `${point.color}55`, backgroundColor: `${point.color}12` }]}><View style={[styles.legendMarker, { backgroundColor: point.color }]} /><Text style={[styles.legendText, { color: point.color }]}>{point.subjectTag} · {formatStudyTime(point.focusedSeconds)}</Text></View>)}</View></View>;
}

function EventLegend({ type, label }: { type: keyof typeof EVENT_COLORS; label: string }) {
  return <View style={[styles.legendItem, { borderColor: `${EVENT_COLORS[type]}55`, backgroundColor: `${EVENT_COLORS[type]}12` }]}><View style={[styles.legendMarker, { backgroundColor: EVENT_COLORS[type] }]} /><Text style={[styles.legendText, { color: EVENT_COLORS[type] }]}>{label}</Text></View>;
}

function eventLabel(type: keyof typeof EVENT_COLORS) {
  return type === "appLeave" ? "App leave" : type === "interruption" ? "Return interruption" : "Pause";
}

const styles = StyleSheet.create({
  axisHint: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  axisHintText: { color: "#6F8977", fontSize: 9, fontWeight: "900", letterSpacing: 0.35 },
  coordinateFooter: { marginTop: 8, flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  coordinateValue: { color: "#173423", fontSize: 17, fontWeight: "900" },
  peakDetail: { alignItems: "flex-end" },
  peakValue: { color: "#087A50", fontSize: 14, fontWeight: "900" },
  coordinateCaption: { color: "#6B8573", fontSize: 10, fontWeight: "700", marginTop: 2 },
  legend: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 13 },
  legendItem: { minHeight: 30, borderRadius: 10, borderWidth: 1, paddingHorizontal: 8, flexDirection: "row", alignItems: "center", gap: 6 },
  legendMarker: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 10, fontWeight: "900" },
  emptyTimeline: { minHeight: 136, borderRadius: 16, alignItems: "center", justifyContent: "center", paddingHorizontal: 24, backgroundColor: "#F3F9F4", borderWidth: 1, borderStyle: "dashed", borderColor: "#C9E0CD" },
  emptyText: { color: "#63796B", fontSize: 12, lineHeight: 18, textAlign: "center" },
  tapHint: { color: "#6F8977", fontSize: 10, lineHeight: 15, fontWeight: "800", marginTop: 9, textAlign: "center" },
  insight: { minHeight: 36, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 10, marginTop: 9 },
  insightText: { fontSize: 11, fontWeight: "900", textAlign: "center" },
});
