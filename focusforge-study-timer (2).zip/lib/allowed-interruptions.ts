export type InterruptibleApp = {
  id: string;
  label: string;
  packageName: string;
  detected?: boolean;
  manual?: boolean;
};

export const ALLOWLIST_STORAGE_KEY = "focusforge.allowed-interruptions.v1";
export const CUSTOM_INTERRUPTIBLE_APPS_STORAGE_KEY = "focusforge.custom-interruptions.v1";

export const SUGGESTED_EMERGENCY_APPS: InterruptibleApp[] = [
  { id: "phone", label: "Phone", packageName: "system.phone" },
  { id: "whatsapp", label: "WhatsApp", packageName: "com.whatsapp" },
  { id: "messenger", label: "Messenger", packageName: "com.facebook.orca" },
];

export function mergeInterruptibleApps(detectedApps: InterruptibleApp[]) {
  const byPackage = new Map<string, InterruptibleApp>();
  [...SUGGESTED_EMERGENCY_APPS, ...detectedApps].forEach((app) => {
    const current = byPackage.get(app.packageName);
    byPackage.set(app.packageName, current ? { ...current, ...app, detected: current.detected || app.detected } : app);
  });
  return [...byPackage.values()].sort((a, b) => a.label.localeCompare(b.label));
}

export function toggleAllowedApp(selectedPackageNames: string[], packageName: string) {
  return selectedPackageNames.includes(packageName)
    ? selectedPackageNames.filter((item) => item !== packageName)
    : [...selectedPackageNames, packageName];
}

export function createManualInterruptibleApp(label: string, existing: InterruptibleApp[]): InterruptibleApp | null {
  const cleaned = label.trim().replace(/\s+/g, " ").slice(0, 48);
  if (!cleaned) return null;
  const base = `manual:${cleaned.toLocaleLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "app"}`;
  const known = existing.find((app) => app.packageName === base || app.label.toLocaleLowerCase() === cleaned.toLocaleLowerCase());
  if (known) return known;
  return { id: base, label: cleaned, packageName: base, manual: true };
}
