import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Alert, AppState, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import Constants from "expo-constants";
import { router } from "expo-router";
import { useEffect, useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { SectionLabel, SettingToggle, Surface } from "@/components/focusforge-ui";
import { useFocusForgeStatic } from "@/lib/focusforge-provider";
import { getCueChannelDiagnostic, hasCurrentAndroidCueBuild, scheduleLockedScreenCueTest, type CueChannelDiagnostic } from "@/lib/focusforge-notifications";
import { LOCKED_SCREEN_CUE_SOUNDS, type LockedScreenCueSound } from "@/lib/focusforge-core";
import { canDrawOverlays, isSessionBubbleSupported, openOverlayPermissionSettings } from "@/lib/session-bubble";

export default function SettingsScreen() {
  const { settings, session, permission, updateSettings, requestCueAccess, testCue, previewCueSound, lastCueResult } = useFocusForgeStatic();
  const isExpoGo = Constants.appOwnership === "expo";
  const hasCurrentCueBuild = hasCurrentAndroidCueBuild();
  const [cueCheck, setCueCheck] = useState<"idle" | "testing" | "played" | "disabled" | "preview-only" | "unavailable">("idle");
  const [channelDiagnostic, setChannelDiagnostic] = useState<CueChannelDiagnostic | null>(null);
  const [lockedScreenTest, setLockedScreenTest] = useState<"idle" | "scheduling" | "scheduled" | "failed">("idle");
  const [previewingSound, setPreviewingSound] = useState<LockedScreenCueSound | null>(null);
  const [soundPreviewResult, setSoundPreviewResult] = useState<"idle" | "played" | "preview-only" | "unavailable">("idle");
  const [awaitingOverlayPermission, setAwaitingOverlayPermission] = useState(false);
  const runCueCheck = async () => {
    setCueCheck("testing");
    const result = await testCue();
    setCueCheck(result);
  };
  const runLockedScreenTest = async () => {
    setLockedScreenTest("scheduling");
    setLockedScreenTest(await scheduleLockedScreenCueTest(15, settings.lockedScreenCueSound) ? "scheduled" : "failed");
  };
  const runSoundPreview = async (sound: LockedScreenCueSound) => {
    setPreviewingSound(sound);
    const result = await previewCueSound(sound);
    setPreviewingSound(null);
    setSoundPreviewResult(result === "played" || result === "preview-only" || result === "unavailable" ? result : "unavailable");
  };
  const setBubbleEnabled = async (enabled: boolean) => {
    if (!enabled) {
      await updateSettings({ floatingSessionBubbleEnabled: false });
      return;
    }
    if (!isSessionBubbleSupported()) {
      Alert.alert("Bubble needs the updated Android build", "The floating session bubble is an Android-only feature. Install the latest custom Android build to use it.");
      return;
    }
    if (canDrawOverlays()) {
      await updateSettings({ floatingSessionBubbleEnabled: true });
      return;
    }
    Alert.alert(
      "Allow the floating session bubble",
      "FocusForge needs Android’s “Display over other apps” permission to show its small countdown after you leave an active session. It never appears for ads and you can turn it off anytime in Settings.",
      [
        { text: "Not now", style: "cancel" },
        { text: "Open Android settings", onPress: () => { setAwaitingOverlayPermission(true); void openOverlayPermissionSettings(); } },
      ],
    );
  };
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState !== "active" || !awaitingOverlayPermission) return;
      setAwaitingOverlayPermission(false);
      if (canDrawOverlays()) {
        void updateSettings({ floatingSessionBubbleEnabled: true });
        Alert.alert("Bubble ready", "Permission is enabled. During an active, unpaused session, leave FocusForge to see the compact countdown.");
      } else {
        Alert.alert("Bubble permission not enabled", "Android did not grant Display over other apps. You can turn the bubble switch on again whenever you are ready.");
      }
    });
    return () => subscription.remove();
  }, [awaitingOverlayPermission, updateSettings]);
  const cueCheckCopy = cueCheck === "preview-only"
    ? "Preview note: this browser view cannot verify Android timer sound. Install the new APK on your phone, then test here."
    : cueCheck === "played"
      ? "A loud in-app tone was requested. If you did not hear it, raise Android Media volume and make sure the phone is not in silent mode."
      : cueCheck === "disabled"
        ? "Enable Audible study cues, then test again."
        : cueCheck === "unavailable"
          ? "Audio playback was unavailable. Close and reopen the installed app, then try again."
          : isExpoGo || !hasCurrentCueBuild
            ? "This is Expo Go or an older APK: it can preview foreground sound only. Screen-off/background cues require the newest custom Android build."
            : "Installed APK mode: Android can queue the round beeps, triple rest cue, and post-rest round-one beep while your session remains active. Confirm the installed channels and your phone’s battery/DND settings below.";

  return <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.eyebrow}>PREFERENCES</Text><Text style={styles.title}>Shape your ritual.</Text><Text style={styles.description}>Changes to a live session take effect the next time you start. Your current session always keeps its original rhythm.</Text>
    {Platform.OS === "android" && !hasCurrentCueBuild ? <View style={styles.buildRequired}><MaterialIcons name="phonelink-setup" size={20} color="#1268A6" /><View style={styles.buildRequiredCopy}><Text style={styles.buildRequiredTitle}>Background beeps need the newest Android build</Text><Text style={styles.buildRequiredText}>Expo Go and older APKs cannot use FocusForge’s bundled screen-off cue channels. Install the newest custom build, then run the 15-second locked-screen test below.</Text></View></View> : null}
    <View style={styles.section}><SectionLabel>DEFAULT RHYTHM</SectionLabel><Surface style={styles.rhythmSurface}>
      <ValueRow title="Study round" detail={`${settings.roundsPerCycle} study rounds make one cycle`} value={`${settings.roundMinutes} min`} />
      <View style={styles.divider} /><ValueRow title="Round-end cue" detail="One beep starts the following study round" value="1 beep" />
      <View style={styles.divider} /><ValueRow title="Rest round" detail={`Three beeps after the final round, then ${settings.restSeconds % 60 === 0 ? `${settings.restSeconds / 60} min` : `${settings.restSeconds} sec`} rest`} value="3 beeps" />
      <View style={styles.divider} /><Pressable onPress={() => router.push("/rhythm-designer" as never)} style={({ pressed }) => [styles.designRow, pressed && { backgroundColor: "#F2FAF3" }]}><View><Text style={styles.designTitle}>Design your rhythm</Text><Text style={styles.designDetail}>Set round length, cycle count, and rest time.</Text></View><MaterialIcons name="arrow-forward" size={18} color="#087A50" /></Pressable>
    </Surface></View>
    <View style={styles.section}><SectionLabel>SESSION FEEDBACK</SectionLabel><Surface>
      <SettingToggle icon="volume-up" title="Audible study cues" detail={permission === "granted" ? "Installed APK: active sessions queue cues for screen lock and display-off." : "Enable, then allow notifications for screen-lock cues."} value={settings.soundEnabled} onValueChange={(value) => { void updateSettings({ soundEnabled: value }); if (value && permission !== "granted") void requestCueAccess(); }} />
      <View style={styles.dividerInset} /><SettingToggle icon="vibration" tone="#5FE0B6" title="Haptic confirmation" detail="Gentle feedback for important controls." value={settings.hapticsEnabled} onValueChange={(value) => void updateSettings({ hapticsEnabled: value })} />
      <View style={styles.dividerInset} /><SettingToggle icon="screen-lock-portrait" tone="#FFB55F" title="Keep display awake" detail="Optional; turn off to let your screen lock normally." value={settings.keepScreenAwake} onValueChange={(value) => void updateSettings({ keepScreenAwake: value })} />
    </Surface></View>
    <Pressable disabled={!settings.soundEnabled || cueCheck === "testing"} onPress={() => void runCueCheck()} style={({ pressed }) => [styles.testCueButton, (!settings.soundEnabled || pressed || cueCheck === "testing") && { opacity: settings.soundEnabled ? 0.78 : 0.42, transform: pressed ? [{ scale: 0.98 }] : undefined }]}><MaterialIcons name="volume-up" size={20} color="#FFFFFF" /><Text style={styles.testCueText}>{cueCheck === "testing" ? "Testing loud beep…" : "Test loud beep"}</Text></Pressable>
    <View style={[styles.audioNote, cueCheck === "preview-only" || Platform.OS === "web" ? styles.audioNotePreview : cueCheck === "played" ? styles.audioNoteSuccess : undefined]}><MaterialIcons name={cueCheck === "played" ? "check-circle" : cueCheck === "preview-only" || Platform.OS === "web" ? "info-outline" : "volume-up"} size={18} color={cueCheck === "played" ? "#0BA66A" : "#63816C"} /><Text style={styles.audioNoteText}>{cueCheckCopy}</Text></View>
    <View style={styles.section}><SectionLabel>LOCKED-SCREEN CUE SOUND</SectionLabel><Surface style={styles.cueSoundSurface}><Text style={styles.cueSoundIntro}>Preview a sound first, then select the tone Android uses for scheduled screen-off round and rest cues. The selected sound is ready in your next freshly built Android version.</Text><View style={styles.cueSoundChoices}>{LOCKED_SCREEN_CUE_SOUNDS.map((sound) => <CueSoundChoice key={sound.id} sound={sound} selected={settings.lockedScreenCueSound === sound.id} previewing={previewingSound === sound.id} previewDisabled={previewingSound !== null} onPress={() => void updateSettings({ lockedScreenCueSound: sound.id })} onPreview={() => void runSoundPreview(sound.id)} />)}</View>{soundPreviewResult !== "idle" ? <View style={styles.previewNote}><MaterialIcons name={soundPreviewResult === "played" ? "check-circle" : "info-outline"} size={16} color={soundPreviewResult === "played" ? "#087A50" : "#63816C"} /><Text style={styles.previewNoteText}>{soundPreviewResult === "played" ? "Cue preview played. Select a sound only when it is the one you want for locked-screen cues." : soundPreviewResult === "preview-only" ? "This browser preview cannot play the Android cue. Use the fresh Android build to hear each option." : "The cue preview could not play. Check Android Media volume and try again."}</Text></View> : null}</Surface></View>
    {Platform.OS === "android" ? <View style={styles.section}><SectionLabel>SESSION BUBBLE</SectionLabel><Surface><SettingToggle icon="picture-in-picture-alt" tone="#1268A6" title="Floating session bubble" detail="Show a compact countdown when you leave an active session. Turning this on guides you to Android’s Display over other apps permission if needed." value={settings.floatingSessionBubbleEnabled} onValueChange={(value) => void setBubbleEnabled(value)} />{awaitingOverlayPermission ? <View style={styles.overlayPrompt}><MaterialIcons name="open-in-new" size={18} color="#1268A6" /><View style={styles.overlayPromptCopy}><Text style={styles.overlayPromptTitle}>Finish in Android settings</Text><Text style={styles.overlayPromptText}>Allow “Display over other apps” for FocusForge, then return here. We will confirm when the bubble is ready.</Text></View></View> : null}<View style={styles.dividerInset} /><Pressable onPress={() => router.push("/shield" as never)} style={({ pressed }) => [styles.designRow, { paddingHorizontal: 16 }, pressed && { backgroundColor: "#F2FAF3" }]}><View><Text style={styles.designTitle}>Bubble permission and help</Text><Text style={styles.designDetail}>Open Focus Shield for Android overlay details and manual permission support.</Text></View><MaterialIcons name="arrow-forward" size={18} color="#087A50" /></Pressable></Surface></View> : null}
    {hasCurrentCueBuild ? <View style={styles.channelSection}><SectionLabel>LOCKED-SCREEN CUE CHECK</SectionLabel><Surface style={styles.channelCard}><View style={styles.channelHead}><View><Text style={styles.channelTitle}>Installed APK channels</Text><Text style={styles.channelDetail}>Checks whether the selected {settings.lockedScreenCueSound} round and rest channels exist, expose sound, and request DND bypass. Your phone can still override these channel choices.</Text></View><Pressable onPress={() => void getCueChannelDiagnostic(settings.lockedScreenCueSound).then(setChannelDiagnostic)} style={({ pressed }) => [styles.channelButton, pressed && { opacity: 0.72 }]}><Text style={styles.channelButtonText}>Check</Text></Pressable></View>{channelDiagnostic ? <View style={styles.channelResults}><ChannelResult okay={channelDiagnostic.channelsPresent} label="Round and rest channels are present" /><ChannelResult okay={channelDiagnostic.soundReady} label="Both channels expose an audible sound setting" /><ChannelResult okay={channelDiagnostic.bypassDndReady} label="Both channels request DND bypass" /></View> : null}<Pressable disabled={lockedScreenTest === "scheduling"} onPress={() => void runLockedScreenTest()} style={({ pressed }) => [styles.lockedTestButton, (pressed || lockedScreenTest === "scheduling") && { opacity: 0.72 }]}><MaterialIcons name="lock" size={16} color="#FFFFFF" /><Text style={styles.lockedTestButtonText}>{lockedScreenTest === "scheduling" ? "Scheduling…" : "Test with screen locked"}</Text></Pressable><Text style={styles.lockedTestNote}>{lockedScreenTest === "scheduled" ? "Scheduled for 15 seconds. Lock the screen immediately. The beep should play while the display is off." : lockedScreenTest === "failed" ? "Could not schedule the test. Check notification permission and the FocusForge notification channels in Android Settings." : "This is a real Android notification test, not the in-app beep. Tap it, then lock your phone immediately."}</Text></Surface></View> : null}
    <View style={styles.section}><SectionLabel>LOCAL DATA</SectionLabel><Surface><View style={styles.dataRow}><Text style={styles.dataTitle}>On-device study log</Text><Text style={styles.dataDetail}>Sessions are stored only on this phone. No account, cloud sync, or data sharing is used.</Text></View><View style={styles.divider} /><Pressable onPress={() => router.push("/privacy-policy" as never)} style={({ pressed }) => [styles.designRow, { paddingHorizontal: 16 }, pressed && { backgroundColor: "#F2FAF3" }]}><View><Text style={styles.designTitle}>Privacy policy</Text><Text style={styles.designDetail}>Read how FocusForge handles local records and Android controls.</Text></View><MaterialIcons name="arrow-forward" size={18} color="#087A50" /></Pressable></Surface></View>
    {session ? <View style={styles.liveNote}><Text style={styles.liveNoteText}>A session is active. Timer lengths shown above will be used on your next session.</Text></View> : null}
    {lastCueResult ? <View style={[styles.audioNote, lastCueResult === "played" ? styles.audioNoteSuccess : undefined]}><MaterialIcons name={lastCueResult === "played" ? "check-circle" : "error-outline"} size={18} color={lastCueResult === "played" ? "#0BA66A" : "#BE4B38"} /><Text style={styles.audioNoteText}>Latest scheduled or test cue: {lastCueResult === "played" ? "audio source reset and playback requested" : lastCueResult === "unavailable" ? "audio source could not load" : lastCueResult}.</Text></View> : null}
  </ScrollView></ScreenContainer>;
}

function ValueRow({ title, detail, value }: { title: string; detail: string; value: string }) { return <View style={styles.valueRow}><View style={styles.valueCopy}><Text style={styles.valueTitle}>{title}</Text><Text style={styles.valueDetail}>{detail}</Text></View><Text style={styles.fixedValue}>{value}</Text></View>; }
function ChannelResult({ okay, label }: { okay: boolean; label: string }) { return <View style={styles.channelResult}><MaterialIcons name={okay ? "check-circle" : "error-outline"} size={16} color={okay ? "#087A50" : "#D63B25"} /><Text style={styles.channelResultText}>{label}</Text></View>; }
function CueSoundChoice({ sound, selected, previewing, previewDisabled, onPress, onPreview }: { sound: { id: LockedScreenCueSound; label: string; detail: string }; selected: boolean; previewing: boolean; previewDisabled: boolean; onPress: () => void; onPreview: () => void }) { return <View style={[styles.cueSoundChoice, selected && styles.cueSoundChoiceSelected]}><Pressable accessibilityRole="radio" accessibilityState={{ selected }} onPress={onPress} style={({ pressed }) => [styles.cueSoundSelect, pressed && { opacity: 0.72 }]}><View style={styles.cueSoundChoiceCopy}><Text style={[styles.cueSoundChoiceTitle, selected && styles.cueSoundChoiceTitleSelected]}>{sound.label}</Text><Text style={styles.cueSoundChoiceDetail}>{sound.detail}</Text></View><MaterialIcons name={selected ? "check-circle" : "radio-button-unchecked"} size={20} color={selected ? "#087A50" : "#9AB5A1"} /></Pressable><Pressable accessibilityLabel={`Preview ${sound.label} cue sound`} disabled={previewDisabled} onPress={onPreview} style={({ pressed }) => [styles.previewButton, previewDisabled && !previewing && styles.previewButtonDisabled, pressed && !previewDisabled && { opacity: 0.72 }]}><MaterialIcons name={previewing ? "hourglass-top" : "play-arrow"} size={15} color="#087A50" /><Text style={styles.previewButtonText}>{previewing ? "Playing" : "Preview"}</Text></Pressable></View>; }

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 16, paddingBottom: 32 }, eyebrow: { color: "#087A50", fontSize: 11, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#173423", fontSize: 29, lineHeight: 36, fontWeight: "900", marginTop: 5 }, description: { color: "#63796B", fontSize: 13, lineHeight: 19, marginTop: 7 }, buildRequired: { marginTop: 16, borderRadius: 15, padding: 13, flexDirection: "row", gap: 10, backgroundColor: "#EEF5FD", borderWidth: 1, borderColor: "#C9DCF4" }, buildRequiredCopy: { flex: 1 }, buildRequiredTitle: { color: "#245783", fontSize: 12, fontWeight: "900" }, buildRequiredText: { color: "#54718A", fontSize: 11, lineHeight: 16, marginTop: 3 }, section: { marginTop: 23 }, rhythmSurface: { paddingHorizontal: 16 }, valueRow: { minHeight: 80, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, valueCopy: { flex: 1 }, valueTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, valueDetail: { color: "#63796B", fontSize: 12, marginTop: 3 }, fixedValue: { color: "#087A50", fontSize: 13, fontWeight: "900" }, divider: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0" }, designRow: { minHeight: 70, paddingVertical: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, designTitle: { color: "#087A50", fontSize: 13, fontWeight: "900" }, designDetail: { color: "#63796B", fontSize: 11, marginTop: 3 }, dividerInset: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0", marginLeft: 66 }, testCueButton: { minHeight: 54, borderRadius: 17, backgroundColor: "#087A50", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 13, shadowColor: "#087A50", shadowOpacity: 0.2, shadowOffset: { width: 0, height: 8 }, shadowRadius: 12, elevation: 3 }, testCueText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" }, audioNote: { flexDirection: "row", gap: 9, borderRadius: 14, padding: 13, marginTop: 10, backgroundColor: "#F1F8F2", borderWidth: 1, borderColor: "#D5EAD8" }, audioNotePreview: { backgroundColor: "#F1F8F2", borderWidth: 1, borderColor: "#D5EAD8" }, audioNoteSuccess: { backgroundColor: "#E6F7EA", borderWidth: 1, borderColor: "#B9E5C3" }, audioNoteText: { flex: 1, color: "#53725D", fontSize: 12, lineHeight: 18 }, cueSoundSurface: { padding: 14 }, cueSoundIntro: { color: "#53725D", fontSize: 11, lineHeight: 16 }, cueSoundChoices: { gap: 8, marginTop: 13 }, cueSoundChoice: { minHeight: 72, borderRadius: 14, padding: 8, backgroundColor: "#F7FBF8", borderWidth: 1, borderColor: "#E1EEE4" }, cueSoundChoiceSelected: { backgroundColor: "#ECF8EF", borderColor: "#81C996" }, cueSoundSelect: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, paddingHorizontal: 4 }, cueSoundChoiceCopy: { flex: 1 }, cueSoundChoiceTitle: { color: "#2C4B35", fontSize: 13, fontWeight: "900" }, cueSoundChoiceTitleSelected: { color: "#087A50" }, cueSoundChoiceDetail: { color: "#66806E", fontSize: 11, marginTop: 2 }, previewButton: { minHeight: 30, alignSelf: "flex-start", marginTop: 7, marginLeft: 4, paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#DDF3E3", flexDirection: "row", alignItems: "center", gap: 4 }, previewButtonDisabled: { opacity: 0.52 }, previewButtonText: { color: "#087A50", fontSize: 10, fontWeight: "900" }, previewNote: { flexDirection: "row", gap: 7, marginTop: 10, padding: 10, borderRadius: 11, backgroundColor: "#F1F8F2" }, previewNoteText: { flex: 1, color: "#55735F", fontSize: 10, lineHeight: 15 }, overlayPrompt: { flexDirection: "row", gap: 9, marginHorizontal: 14, marginBottom: 14, padding: 12, borderRadius: 13, backgroundColor: "#EEF5FD", borderWidth: 1, borderColor: "#C9DCF4" }, overlayPromptCopy: { flex: 1 }, overlayPromptTitle: { color: "#245783", fontSize: 12, fontWeight: "900" }, overlayPromptText: { color: "#54718A", fontSize: 11, lineHeight: 16, marginTop: 3 }, channelSection: { marginTop: 22 }, channelCard: { padding: 15 }, channelHead: { flexDirection: "row", gap: 12, alignItems: "center" }, channelTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, channelDetail: { color: "#63796B", fontSize: 11, lineHeight: 16, marginTop: 3, maxWidth: 230 }, channelButton: { minWidth: 54, minHeight: 34, borderRadius: 11, backgroundColor: "#1268A6", alignItems: "center", justifyContent: "center" }, channelButtonText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" }, channelResults: { gap: 7, marginTop: 14, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#DDECE0" }, channelResult: { flexDirection: "row", alignItems: "center", gap: 7 }, channelResultText: { color: "#53725D", fontSize: 11, fontWeight: "800" }, lockedTestButton: { minHeight: 46, marginTop: 14, borderRadius: 13, backgroundColor: "#1268A6", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 }, lockedTestButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, lockedTestNote: { color: "#53725D", fontSize: 11, lineHeight: 16, marginTop: 9 }, dataRow: { padding: 16 }, dataTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, dataDetail: { color: "#63796B", fontSize: 12, lineHeight: 18, marginTop: 4 }, liveNote: { marginTop: 18, borderRadius: 15, padding: 13, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#CDE5D2" }, liveNoteText: { color: "#356447", fontSize: 12, lineHeight: 18 },
});
