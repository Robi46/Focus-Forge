import AsyncStorage from "@react-native-async-storage/async-storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Linking, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { IconCircle, SectionLabel, Surface } from "@/components/focusforge-ui";
import { ScreenContainer } from "@/components/screen-container";
import { ALLOWLIST_STORAGE_KEY, createManualInterruptibleApp, CUSTOM_INTERRUPTIBLE_APPS_STORAGE_KEY, mergeInterruptibleApps, toggleAllowedApp, type InterruptibleApp } from "@/lib/allowed-interruptions";

export default function AllowedInterruptionsScreen() {
  const [manualApps, setManualApps] = useState<InterruptibleApp[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [manualLabel, setManualLabel] = useState("");
  const apps = useMemo(() => mergeInterruptibleApps(manualApps), [manualApps]);

  useEffect(() => {
    void (async () => {
      const [savedSelection, savedApps] = await Promise.all([
        AsyncStorage.getItem(ALLOWLIST_STORAGE_KEY),
        AsyncStorage.getItem(CUSTOM_INTERRUPTIBLE_APPS_STORAGE_KEY),
      ]);
      try { setSelected(savedSelection ? JSON.parse(savedSelection) as string[] : []); } catch { setSelected([]); }
      try { setManualApps(savedApps ? JSON.parse(savedApps) as InterruptibleApp[] : []); } catch { setManualApps([]); }
    })();
  }, []);

  const toggle = (packageName: string) => setSelected((current) => {
    const next = toggleAllowedApp(current, packageName);
    void AsyncStorage.setItem(ALLOWLIST_STORAGE_KEY, JSON.stringify(next));
    return next;
  });
  const addManualApp = () => {
    const app = createManualInterruptibleApp(manualLabel, apps);
    if (!app) return;
    if (app.manual) {
      const next = [...manualApps, app];
      setManualApps(next);
      void AsyncStorage.setItem(CUSTOM_INTERRUPTIBLE_APPS_STORAGE_KEY, JSON.stringify(next));
    }
    setManualLabel("");
  };
  const openSystemSettings = () => void Linking.openSettings();

  return <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      <View style={styles.header}><IconCircle icon="arrow-back" color="#087A50" onPress={() => router.back()} /><View style={styles.headerCopy}><Text style={styles.eyebrow}>FOCUS SHIELD</Text><Text style={styles.title}>Allowed interruptions</Text></View></View>
      <Text style={styles.description}>Select or type the apps you personally regard as emergencies. This private list is a setup checklist; Android Do Not Disturb is the system control that actually blocks non-allowed notifications.</Text>

      <Surface style={styles.summary}><View style={styles.summaryIcon}><MaterialIcons name="verified-user" size={22} color="#087A50" /></View><View style={styles.summaryCopy}><Text style={styles.summaryTitle}>{selected.length ? `${selected.length} app${selected.length === 1 ? "" : "s"} selected — match in Android` : "No apps selected yet"}</Text><Text style={styles.summaryDetail}>FocusForge keeps this checklist on your device. Android owns the final DND exceptions and controls whether a selected app may interrupt you.</Text></View></Surface>

      <View style={styles.section}><SectionLabel>ANDROID SETUP</SectionLabel><Surface><GuideRow title="1. Open Android Modes or DND" detail="Use Settings and search for Do Not Disturb, Modes, or Focus mode. The wording differs by phone." action="Open" onPress={openSystemSettings} /><View style={styles.divider} /><GuideRow title="2. Match Android exceptions" detail="Allow only the emergency contacts and selected apps you want to hear from during study." action="Review" onPress={openSystemSettings} /><View style={styles.divider} /><GuideRow title="3. Enable your Study mode" detail="Turn on the Android mode before starting a strict focus period. It is the only device-level control for notification filtering." action="Settings" onPress={openSystemSettings} /></Surface></View>

      <View style={styles.section}><SectionLabel>EMERGENCY APP LIST</SectionLabel><Surface style={styles.manualEntry}><Text style={styles.manualTitle}>Add any app manually</Text><Text style={styles.manualDetail}>Type the exact app name you will allow in Android’s own DND or Focus mode.</Text><View style={styles.manualControls}><TextInput value={manualLabel} onChangeText={setManualLabel} onSubmitEditing={addManualApp} placeholder="e.g. Signal" placeholderTextColor="#819789" style={styles.manualInput} maxLength={48} returnKeyType="done" /><Pressable disabled={!manualLabel.trim()} onPress={addManualApp} style={({ pressed }) => [styles.addAction, (!manualLabel.trim() || pressed) && { opacity: manualLabel.trim() ? 0.72 : 0.38 }]}><MaterialIcons name="add" size={19} color="#FFFFFF" /></Pressable></View></Surface><Surface style={styles.appList}>{apps.map((app, index) => <View key={app.packageName}><AppRow app={app} selected={selected.includes(app.packageName)} onPress={() => toggle(app.packageName)} />{index < apps.length - 1 ? <View style={styles.divider} /> : null}</View>)}</Surface></View>

      <View style={styles.warning}><MaterialIcons name="privacy-tip" size={19} color="#087A50" /><Text style={styles.warningText}>For privacy, the Play release does not read your full installed-app inventory. Type extra emergency apps above, then match each selected item in Android’s DND or Focus mode.</Text></View>
      <View style={styles.note}><MaterialIcons name="info-outline" size={19} color="#087A50" /><Text style={styles.noteText}>DND can silence notifications, but a normal app cannot guarantee filtering of every third-party call, bypass-DND alert, Home action, or Recents action. Screen Pinning prevents leaving FocusForge, including to these apps.</Text></View>
    </ScrollView>
  </ScreenContainer>;
}

function GuideRow({ title, detail, action, onPress }: { title: string; detail: string; action: string; onPress: () => void }) { return <View style={styles.guideRow}><View style={styles.guideCopy}><Text style={styles.guideTitle}>{title}</Text><Text style={styles.guideDetail}>{detail}</Text></View><Pressable onPress={onPress} style={({ pressed }) => [styles.compactAction, pressed && { opacity: 0.7 }]}><Text style={styles.compactActionText}>{action}</Text></Pressable></View>; }
function AppRow({ app, selected, onPress }: { app: InterruptibleApp; selected: boolean; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.appRow, pressed && { backgroundColor: "#F1F8F2" }]}><View style={[styles.appIcon, selected && styles.appIconSelected]}><MaterialIcons name={app.packageName === "system.phone" ? "phone" : "chat"} size={20} color={selected ? "#FFFFFF" : "#087A50"} /></View><View style={styles.appCopy}><Text style={styles.appTitle}>{app.label}</Text><Text style={styles.appDetail}>{app.manual ? "Added by you" : "Common emergency app"}</Text></View><View style={[styles.check, selected && styles.checkSelected]}>{selected ? <MaterialIcons name="check" size={17} color="#FFFFFF" /> : null}</View></Pressable>; }

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 16, paddingBottom: 32 }, header: { flexDirection: "row", alignItems: "center", gap: 13 }, headerCopy: { flex: 1 }, eyebrow: { color: "#087A50", fontSize: 11, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#173423", fontSize: 26, fontWeight: "900", marginTop: 4 }, description: { color: "#63796B", fontSize: 13, lineHeight: 19, marginTop: 15 }, summary: { marginTop: 20, padding: 16, flexDirection: "row", gap: 12, borderColor: "#BDE2C6", backgroundColor: "#FCFFFC" }, summaryIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#E7F6EA", alignItems: "center", justifyContent: "center" }, summaryCopy: { flex: 1 }, summaryTitle: { color: "#173423", fontSize: 15, fontWeight: "900" }, summaryDetail: { color: "#63796B", fontSize: 12, lineHeight: 17, marginTop: 3 }, section: { marginTop: 23 }, guideRow: { minHeight: 90, padding: 15, flexDirection: "row", alignItems: "center", gap: 12 }, guideCopy: { flex: 1 }, guideTitle: { color: "#173423", fontSize: 13, fontWeight: "900" }, guideDetail: { color: "#63796B", fontSize: 11, lineHeight: 16, marginTop: 3 }, compactAction: { minWidth: 57, minHeight: 35, borderRadius: 12, paddingHorizontal: 10, backgroundColor: "#087A50", alignItems: "center", justifyContent: "center" }, compactActionText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" }, divider: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0", marginLeft: 66 }, manualEntry: { marginTop: 10, padding: 14 }, manualTitle: { color: "#173423", fontSize: 13, fontWeight: "900" }, manualDetail: { color: "#63796B", fontSize: 11, lineHeight: 16, marginTop: 3 }, manualControls: { flexDirection: "row", gap: 8, marginTop: 11 }, manualInput: { flex: 1, minHeight: 42, borderRadius: 12, borderWidth: 1, borderColor: "#C9E0CE", backgroundColor: "#FFFFFF", color: "#173423", paddingHorizontal: 12, fontSize: 12, fontWeight: "700" }, addAction: { width: 42, minHeight: 42, borderRadius: 12, backgroundColor: "#087A50", alignItems: "center", justifyContent: "center" }, appList: { marginTop: 10 }, appRow: { minHeight: 72, flexDirection: "row", alignItems: "center", padding: 15, gap: 12 }, appIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: "#EAF7EC", alignItems: "center", justifyContent: "center" }, appIconSelected: { backgroundColor: "#087A50" }, appCopy: { flex: 1 }, appTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, appDetail: { color: "#63796B", fontSize: 12, marginTop: 3 }, check: { width: 25, height: 25, borderRadius: 8, borderWidth: 1.5, borderColor: "#B7D6BD", alignItems: "center", justifyContent: "center" }, checkSelected: { backgroundColor: "#087A50", borderColor: "#087A50" }, warning: { marginTop: 14, borderRadius: 15, padding: 13, flexDirection: "row", gap: 9, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#CDE5D2" }, warningText: { flex: 1, color: "#45634F", fontSize: 12, lineHeight: 18 }, note: { marginTop: 13, borderRadius: 15, padding: 13, flexDirection: "row", gap: 9, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#CDE5D2" }, noteText: { flex: 1, color: "#45634F", fontSize: 12, lineHeight: 18 },
});
