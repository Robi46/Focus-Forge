"""Generate compact, original notification-tone WAV assets for FocusForge."""

from math import pi, sin
from pathlib import Path
import struct
import wave

ROOT = Path(__file__).resolve().parents[1]
SOUNDS = {
    "focusforge_bright.wav": (1180.0, 0.28),
    "focusforge_calm.wav": (610.0, 0.38),
}
SAMPLE_RATE = 44_100


def write_tone(path: Path, frequency: float, seconds: float) -> None:
    sample_count = int(SAMPLE_RATE * seconds)
    frames = bytearray()
    for index in range(sample_count):
        position = index / SAMPLE_RATE
        attack = min(1.0, position / 0.015)
        release = min(1.0, max(0.0, seconds - position) / 0.08)
        envelope = attack * release
        sample = 0.62 * envelope * (sin(2 * pi * frequency * position) + 0.18 * sin(2 * pi * frequency * 2 * position))
        frames.extend(struct.pack("<h", int(max(-1.0, min(1.0, sample)) * 32767)))
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(frames)


for file_name, (frequency, duration) in SOUNDS.items():
    write_tone(ROOT / "assets" / "sounds" / file_name, frequency, duration)
