import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { IconCircle, Surface } from "@/components/focusforge-ui";
import { ScreenContainer } from "@/components/screen-container";

export default function PrivacyPolicyScreen() {
  return <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.header}><IconCircle icon="arrow-back" color="#087A50" onPress={() => router.back()} /><View><Text style={styles.eyebrow}>PRIVACY</Text><Text style={styles.title}>Local by design.</Text></View></View>
    <Text style={styles.updated}>Last updated · 23 August 2026</Text>
    <Surface style={styles.card}><PolicySection title="Your study information stays on your device" text="FocusForge stores study sessions, timer settings, goals, subjects, notes, folders, tags, routines, and manually entered emergency-app labels in local app storage on this device." /><PolicySection title="No account or advertising analytics" text="FocusForge does not require an account, use advertising analytics, sell personal information, or provide cloud sync in this release." /><PolicySection title="Android controls remain yours" text="Notification, Do Not Disturb, battery, and app-pinning choices are controlled by Android and your phone settings. FocusForge does not read the public-release device app inventory." /><PolicySection title="Deleting local data" text="Removing FocusForge app data or uninstalling the app removes local FocusForge records, subject to any device-level backup controls you have enabled." /></Surface>
    <View style={styles.note}><Text style={styles.noteText}>The full Play Store policy is provided by the developer with the public release listing. If the app adds cloud backup, analytics, advertising, accounts, or new third-party services, this policy will be updated before that release.</Text></View>
  </ScrollView></ScreenContainer>;
}

function PolicySection({ title, text }: { title: string; text: string }) { return <View style={styles.section}><Text style={styles.sectionTitle}>{title}</Text><Text style={styles.sectionText}>{text}</Text></View>; }

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 16, paddingBottom: 32 }, header: { flexDirection: "row", alignItems: "center", gap: 13 }, eyebrow: { color: "#087A50", fontSize: 11, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#173423", fontSize: 27, lineHeight: 34, fontWeight: "900", marginTop: 4 }, updated: { color: "#63796B", fontSize: 12, marginTop: 19 }, card: { marginTop: 13, paddingHorizontal: 17 }, section: { paddingVertical: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#DDECE0" }, sectionTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, sectionText: { color: "#5B7864", fontSize: 12, lineHeight: 18, marginTop: 5 }, note: { marginTop: 15, borderRadius: 15, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#CDE5D2", padding: 14 }, noteText: { color: "#45634F", fontSize: 12, lineHeight: 18 },
});
