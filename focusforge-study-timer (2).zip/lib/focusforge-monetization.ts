export const AD_FREE_REWARD_MS = 12 * 60 * 60 * 1_000;

export function isAdFree(adFreeUntilMs: number, nowMs = Date.now()) {
  return Number.isFinite(adFreeUntilMs) && adFreeUntilMs > nowMs;
}

export function grantTwelveHourAdFreeTime(nowMs = Date.now()) {
  return nowMs + AD_FREE_REWARD_MS;
}

export function formatAdFreeExpiry(adFreeUntilMs: number) {
  return new Date(adFreeUntilMs).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}
