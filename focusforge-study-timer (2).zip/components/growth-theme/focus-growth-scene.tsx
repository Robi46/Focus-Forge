import { useEffect, useRef, useState } from "react";
import { AccessibilityInfo, AppState, StyleSheet, Text, View } from "react-native";
import Animated, { cancelAnimation, Easing, runOnJS, useAnimatedStyle, useSharedValue, withDelay, withRepeat, withSequence, withTiming } from "react-native-reanimated";
import Svg, { Circle, Ellipse, Line, Path, Polygon, Rect } from "react-native-svg";

import { Surface } from "@/components/focusforge-ui";
import { GROWTH_JOURNEY_ROUNDS, getButterflyVariant, getGrowthJourneyChapter, getGrowthJourneyProgress, getGrowthJourneyRound, getGrowthSubjectTint, getHiveBeeCount, type GrowthTheme } from "@/lib/focusforge-growth";

export type FocusGrowthSceneState = {
  sessionId: string;
  growthTheme?: GrowthTheme;
  subjectTag?: string;
  phase: "focus" | "reset" | "paused";
  roundsCompleted: number;
  roundsPerCycle: number;
  growthJourneyStartedAtRounds?: number;
  growthJourneyIndex?: number;
  paused: boolean;
};

type FocusGrowthSceneProps = {
  scene: FocusGrowthSceneState | null;
  abandonSignal: number;
  onStageSettled?: () => void;
};

const GARDEN_BURST = [[-42, -25], [-22, -48], [5, -42], [30, -31], [43, -6]] as const;
const HIVE_BURST = [[-38, -18], [-16, -44], [12, -39], [38, -19], [47, 6]] as const;
// Bees are anchored to the hive edge and honeycomb openings rather than scattered across the sky.
const BEE_POSITIONS = [[39, 8], [56, 5], [70, 13], [20, 22], [80, 29], [16, 39], [85, 43], [14, 56], [87, 58], [23, 70], [78, 72], [34, 83], [67, 85], [50, 96]] as const;
const BEE_PERCHES = [[0, 0], [0, 0], [3, -2], [-3, 1], [0, 0], [0, 0], [5, -3], [-4, 2], [0, 0], [0, 0], [3, -2], [-3, 2], [0, 0], [0, 0]] as const;

function useReduceMotion() {
  const [reduceMotion, setReduceMotion] = useState(false);
  useEffect(() => {
    let active = true;
    void AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (active) setReduceMotion(value);
    });
    const subscription = AccessibilityInfo.addEventListener?.("reduceMotionChanged", setReduceMotion);
    return () => {
      active = false;
      subscription?.remove();
    };
  }, []);
  return reduceMotion;
}

/**
 * Exactly one live themed scene mounts at a time. Every continuous movement is a
 * bounded Reanimated transform or opacity loop; particle arrays are fixed-size.
 */
export function FocusGrowthScene({ scene, abandonSignal, onStageSettled }: FocusGrowthSceneProps) {
  const reduceMotion = useReduceMotion();
  const [settlingScene, setSettlingScene] = useState<FocusGrowthSceneState | null>(null);
  const [stageSignal, setStageSignal] = useState(0);
  const [capstoneSignal, setCapstoneSignal] = useState(0);
  const previousSceneRef = useRef<FocusGrowthSceneState | null>(null);
  const previousStageRef = useRef<string | null>(null);
  const previousCapstoneRef = useRef<string | null>(null);
  const suppressNextGrowthBeatRef = useRef(false);
  const activeScene = scene ?? settlingScene;
  const settling = Boolean(settlingScene);

  useEffect(() => {
    if (scene) previousSceneRef.current = scene;
  }, [scene]);

  useEffect(() => {
    let wasAway = false;
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "inactive" || state === "background") wasAway = true;
      if (state === "active" && wasAway) {
        suppressNextGrowthBeatRef.current = true;
        wasAway = false;
      }
    });
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    if (!scene || settling) {
      previousStageRef.current = null;
      previousCapstoneRef.current = null;
      return;
    }
    const journeyRound = getGrowthJourneyRound(scene.roundsCompleted - (scene.growthJourneyStartedAtRounds ?? 0));
    const key = `${scene.sessionId}-journey-round-${journeyRound}`;
    const suppressGrowthBeat = suppressNextGrowthBeatRef.current;
    if (journeyRound > 0 && previousStageRef.current && previousStageRef.current !== key && !suppressGrowthBeat) setStageSignal((value) => value + 1);
    previousStageRef.current = key;

    const capstoneKey = journeyRound === GROWTH_JOURNEY_ROUNDS ? `${scene.sessionId}-journey-complete` : null;
    if (capstoneKey && previousCapstoneRef.current !== capstoneKey && !suppressGrowthBeat) setCapstoneSignal((value) => value + 1);
    previousCapstoneRef.current = capstoneKey;
    suppressNextGrowthBeatRef.current = false;
  }, [scene, settling]);

  useEffect(() => {
    if (!abandonSignal || !previousSceneRef.current) return;
    setSettlingScene(previousSceneRef.current);
    const timeout = setTimeout(() => setSettlingScene(null), reduceMotion ? 0 : 1_800);
    return () => clearTimeout(timeout);
  }, [abandonSignal, reduceMotion]);

  if (!activeScene) return <NeutralRestingScene />;
  const journeyRound = getGrowthJourneyRound(activeScene.roundsCompleted - (activeScene.growthJourneyStartedAtRounds ?? 0));
  const journeyChapter = getGrowthJourneyChapter(journeyRound);
  const journeyProgress = getGrowthJourneyProgress(journeyRound);
  const storyComplete = journeyRound === GROWTH_JOURNEY_ROUNDS;
  const theme = activeScene.growthTheme ?? "butterfly";
  const title = theme === "hive" ? "The Hive" : theme === "river" ? "River Birth" : "Chrysalis Garden";
  const detail = settling
    ? theme === "hive" ? "The bees return to the hive. Your earned cells remain." : theme === "river" ? "The river rests. Water and life remain in place." : "The garden rests. Earned growth remains with you."
    : activeScene.paused ? "Paused — every living detail is held in place."
      : storyComplete ? theme === "river" ? "Round 26 complete — the hillside river has reached its living course." : theme === "hive" ? "Round 26 complete — the hive has reached its fullest living stage." : "Round 26 complete — the chrysalis opens and your butterfly emerges."
        : activeScene.phase === "reset" ? `Round ${journeyRound} of ${GROWTH_JOURNEY_ROUNDS} — the story holds its place through rest.`
          : journeyRound ? `Round ${journeyRound} of ${GROWTH_JOURNEY_ROUNDS} — each completed round adds a small, lasting change.` : "Round 1 begins a 26-round living story.";

  return <View style={styles.section} accessible accessibilityLabel={`${title}. ${detail}`}>
    <View style={styles.heading}><View><Text style={styles.eyebrow}>LIVE FOCUS WORLD</Text><Text style={styles.title}>{title}</Text></View><Text style={[styles.themeBadge, theme === "hive" && styles.hiveBadge, theme === "river" && styles.riverBadge]}>{theme === "hive" ? "HIVE" : theme === "river" ? "RIVER" : "GARDEN"}</Text></View>
    <Surface style={styles.sceneCard}>
      {theme === "hive"
        ? <HiveScene sessionId={`${activeScene.sessionId}-${activeScene.growthJourneyIndex ?? 0}`} stage={Math.min(4, journeyChapter)} journeyRound={journeyRound} journeyProgress={journeyProgress} storyComplete={storyComplete} paused={Boolean(activeScene.paused) || settling} reduceMotion={reduceMotion} stageSignal={stageSignal} capstoneSignal={capstoneSignal} settling={settling} onStageSettled={onStageSettled} tint={getGrowthSubjectTint(activeScene.subjectTag)} />
        : theme === "river"
          ? <RiverScene sessionId={`${activeScene.sessionId}-${activeScene.growthJourneyIndex ?? 0}`} journeyRound={journeyRound} journeyProgress={journeyProgress} storyComplete={storyComplete} paused={Boolean(activeScene.paused) || settling} reduceMotion={reduceMotion} />
          : <GardenScene sessionId={`${activeScene.sessionId}-${activeScene.growthJourneyIndex ?? 0}`} stage={Math.min(4, journeyChapter)} journeyRound={journeyRound} journeyProgress={journeyProgress} storyComplete={storyComplete} paused={Boolean(activeScene.paused) || settling} reduceMotion={reduceMotion} stageSignal={stageSignal} capstoneSignal={capstoneSignal} settling={settling} onStageSettled={onStageSettled} tint={getGrowthSubjectTint(activeScene.subjectTag)} />}
      <View pointerEvents="none" style={styles.caption}><Text style={styles.captionText}>{detail}</Text></View>
    </Surface>
  </View>;
}

function NeutralRestingScene() {
  return <View style={styles.section} accessible accessibilityLabel="Focus world ready. Start a session to reveal a random living theme.">
    <View style={styles.heading}><View><Text style={styles.eyebrow}>LIVE FOCUS WORLD</Text><Text style={styles.title}>Ready to grow</Text></View><Text style={styles.themeBadge}>READY</Text></View>
    <Surface style={styles.sceneCard}>
      <View style={styles.neutralSky}><View style={styles.neutralDappleOne} /><View style={styles.neutralDappleTwo} /></View>
      <Svg width="100%" height="150" viewBox="0 0 320 150" preserveAspectRatio="none" style={styles.neutralBranch}><Path d="M-4 121 C48 96, 91 105, 132 83 C178 59, 218 68, 324 23" fill="none" stroke="#6F8B6F" strokeWidth="9" strokeLinecap="round" opacity={0.72} /><Path d="M113 92 C93 64, 82 48, 66 38" fill="none" stroke="#7FA27C" strokeWidth="4" strokeLinecap="round" opacity={0.58} /><Path d="M146 77 C160 47, 176 29, 196 19" fill="none" stroke="#7FA27C" strokeWidth="4" strokeLinecap="round" opacity={0.58} /></Svg>
      <Text style={styles.neutralLabel}>A new living focus world is chosen when you begin.</Text>
    </Surface>
  </View>;
}

function GardenScene({ sessionId, stage, journeyRound, journeyProgress, storyComplete, paused, reduceMotion, stageSignal, capstoneSignal, settling, onStageSettled, tint }: SceneProps) {
  const leafX = useSharedValue(0);
  const leafY = useSharedValue(0);
  const dapple = useSharedValue(0.38);
  const settle = useSharedValue(1);
  const gardenStyle = useAnimatedStyle(() => ({ opacity: settle.value }));
  const leafStyle = useAnimatedStyle(() => ({ transform: [{ translateX: leafX.value }, { translateY: leafY.value }] }));
  const dappleStyle = useAnimatedStyle(() => ({ opacity: dapple.value }));

  useEffect(() => {
    if (paused || reduceMotion) {
      cancelAnimation(leafX); cancelAnimation(leafY); cancelAnimation(dapple);
      return;
    }
    leafX.value = withRepeat(withSequence(withTiming(2.2, { duration: 2_900, easing: Easing.inOut(Easing.sin) }), withTiming(-2.2, { duration: 2_900, easing: Easing.inOut(Easing.sin) })), -1, true);
    leafY.value = withRepeat(withSequence(withTiming(-2.8, { duration: 2_900, easing: Easing.inOut(Easing.sin) }), withTiming(2.8, { duration: 2_900, easing: Easing.inOut(Easing.sin) })), -1, true);
    dapple.value = withRepeat(withSequence(withTiming(0.66, { duration: 4_200, easing: Easing.inOut(Easing.sin) }), withTiming(0.3, { duration: 4_200, easing: Easing.inOut(Easing.sin) })), -1, true);
    return () => { cancelAnimation(leafX); cancelAnimation(leafY); cancelAnimation(dapple); };
  }, [dapple, leafX, leafY, paused, reduceMotion]);

  useEffect(() => {
    if (!settling || reduceMotion) { settle.value = 1; return; }
    settle.value = withSequence(withDelay(900, withTiming(0.84, { duration: 600, easing: Easing.inOut(Easing.quad) })), withTiming(0, { duration: 300 }));
  }, [reduceMotion, settle, settling]);

  return <Animated.View style={[styles.world, gardenStyle]}>
    <View style={styles.gardenBackdrop}><Animated.View style={[styles.gardenDapple, dappleStyle]} /><View style={styles.gardenLeafBlurOne} /><View style={styles.gardenLeafBlurTwo} /></View>
    <GardenLandscape stage={stage} />
    <View style={styles.grassBand}>{[5, 22, 40, 57, 74, 90].map((left, index) => <View key={left} style={[styles.grassBlade, { left: `${left}%`, height: 15 + (index % 3) * 4, transform: [{ rotate: `${-14 + (index % 4) * 10}deg` }] }]} />)}</View>
    <Animated.View style={[styles.mainLeaf, leafStyle]}><Svg width="230" height="105" viewBox="0 0 230 105"><Path d="M12 82 C43 7, 157 0, 220 41 C176 103, 74 107, 12 82 Z" fill="#4E9C62" /><Path d="M20 81 C90 68, 149 52, 214 39" fill="none" stroke="#B6E4AA" strokeWidth="3" opacity={0.75} /><Path d="M77 69 L63 46 M118 58 L107 31 M156 48 L151 25" fill="none" stroke="#B6E4AA" strokeWidth="2" opacity={0.55} />{stage >= 2 ? <><Circle cx="203" cy="58" r="5" fill="#EAF4DC" opacity={0.7} /><Circle cx="193" cy="67" r="4" fill="#EAF4DC" opacity={0.62} /></> : null}{stage >= 3 ? <Circle cx="185" cy="75" r="4" fill="#EAF4DC" opacity={0.64} /> : null}</Svg></Animated.View>
    {storyComplete ? <ButterflyEmergence sessionId={sessionId} signal={capstoneSignal} paused={paused} reduceMotion={reduceMotion} /> : stage ? <Caterpillar sessionId={sessionId} stage={stage} journeyRound={journeyRound} journeyProgress={journeyProgress} storyComplete={storyComplete} paused={paused} reduceMotion={reduceMotion} stageSignal={stageSignal} capstoneSignal={capstoneSignal} settling={settling} tint={tint} onStageSettled={onStageSettled} /> : null}
    <GardenRoundDetails journeyRound={journeyRound} tint={tint} />
    {stage >= 3 ? <GardenMotes count={stage === 4 ? 6 : 4} paused={paused} reduceMotion={reduceMotion} /> : null}
    {settling ? <View style={styles.gardenSettlingShade} /> : null}
  </Animated.View>;
}

function Caterpillar({ stage, journeyProgress, paused, reduceMotion, stageSignal, capstoneSignal, tint, onStageSettled }: SceneProps) {
  const grow = useSharedValue(1);
  const breath = useSharedValue(1);
  const antenna = useSharedValue(0);
  const chrysalisSway = useSharedValue(0);
  const bodyStyle = useAnimatedStyle(() => ({ transform: [{ scaleX: grow.value * (0.74 + journeyProgress * 0.72) }, { scaleY: grow.value * breath.value * (0.84 + journeyProgress * 0.18) }] }));
  const antennaStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${antenna.value}deg` }] }));
  const chrysalisStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${chrysalisSway.value}deg` }] }));
  useEffect(() => {
    if (paused || reduceMotion) { cancelAnimation(breath); cancelAnimation(antenna); cancelAnimation(chrysalisSway); return; }
    breath.value = withRepeat(withSequence(withTiming(1.025, { duration: 1_450, easing: Easing.inOut(Easing.sin) }), withTiming(0.99, { duration: 1_450, easing: Easing.inOut(Easing.sin) })), -1, true);
    antenna.value = withRepeat(withSequence(withDelay(4_600, withTiming(9, { duration: 260, easing: Easing.out(Easing.quad) })), withTiming(0, { duration: 240, easing: Easing.out(Easing.quad) }), withDelay(1_850, withTiming(-6, { duration: 240, easing: Easing.inOut(Easing.quad) })), withTiming(0, { duration: 240, easing: Easing.out(Easing.quad) })), -1, false);
    if (stage === 4) chrysalisSway.value = withRepeat(withSequence(withTiming(2.2, { duration: 2_300, easing: Easing.inOut(Easing.sin) }), withTiming(-2.2, { duration: 2_300, easing: Easing.inOut(Easing.sin) })), -1, true);
    else cancelAnimation(chrysalisSway);
    return () => { cancelAnimation(breath); cancelAnimation(antenna); cancelAnimation(chrysalisSway); };
  }, [antenna, breath, chrysalisSway, paused, reduceMotion, stage]);
  useEffect(() => {
    if (!stageSignal) return;
    grow.value = 0.92;
    grow.value = withSequence(withTiming(1.06, { duration: 420, easing: Easing.out(Easing.cubic) }), withTiming(1, { duration: 280, easing: Easing.out(Easing.quad) }, (finished) => { if (finished && onStageSettled) runOnJS(onStageSettled)(); }));
  }, [grow, onStageSettled, stageSignal]);

  return <View pointerEvents="none" style={styles.caterpillarWrap}>
    {stage === 4 ? <Animated.View style={[styles.preChrysalis, chrysalisStyle]}><View style={styles.chrysalisGlow} /><View style={[styles.chrysalisBody, { borderColor: tint }]}><View style={styles.chrysalisRidge} /><View style={styles.chrysalisRidgeSecond} /><View style={styles.chrysalisHighlight} /></View><View style={styles.chrysalisThread} /></Animated.View> : <Animated.View style={[styles.caterpillar, bodyStyle]}>{[0, 1, 2, 3, 4].map((segment) => <View key={segment} style={[styles.caterpillarSegment, { backgroundColor: segment >= 2 && stage >= 3 ? tint : "#48A05E", marginLeft: segment ? -4 : 0 }]}>{segment === 0 ? <><View style={styles.caterpillarEye} /><View style={styles.caterpillarCheek} /></> : null}{stage >= 2 && segment < 4 ? <LegPair index={segment} paused={paused} reduceMotion={reduceMotion} stageSignal={stageSignal} /> : null}</View>)}<Animated.View style={[styles.antennae, antennaStyle]}><View style={styles.antenna} /><View style={[styles.antenna, styles.antennaRight]} /></Animated.View></Animated.View>}
    <BurstParticles pattern={GARDEN_BURST} signal={stageSignal + capstoneSignal} color="#F7E58B" paused={paused} reduceMotion={reduceMotion} />
  </View>;
}

function ButterflyEmergence({ sessionId, signal, paused, reduceMotion }: { sessionId: string; signal: number; paused: boolean; reduceMotion: boolean }) {
  const rise = useSharedValue(-20);
  const opacity = useSharedValue(0);
  const wing = useSharedValue(0.82);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value, transform: [{ translateY: rise.value }, { scale: wing.value }] }));
  const leftWing = useAnimatedStyle(() => ({ transform: [{ scaleX: wing.value }] }));
  const rightWing = useAnimatedStyle(() => ({ transform: [{ scaleX: wing.value }] }));
  useEffect(() => {
    if (paused || reduceMotion) { cancelAnimation(rise); cancelAnimation(opacity); cancelAnimation(wing); return; }
    if (!signal) { rise.value = -20; opacity.value = 1; wing.value = 1; return; }
    rise.value = 8; opacity.value = 0; wing.value = 0.48;
    rise.value = withSequence(withTiming(-38, { duration: 760, easing: Easing.out(Easing.cubic) }), withTiming(-31, { duration: 1_100, easing: Easing.inOut(Easing.sin) }));
    opacity.value = withSequence(withTiming(1, { duration: 260 }), withTiming(1, { duration: 1_600 }));
    wing.value = withSequence(withTiming(1.22, { duration: 250, easing: Easing.out(Easing.cubic) }), withTiming(0.82, { duration: 250, easing: Easing.inOut(Easing.sin) }), withTiming(1.06, { duration: 250, easing: Easing.inOut(Easing.sin) }), withTiming(1, { duration: 420, easing: Easing.out(Easing.quad) }));
    return () => { cancelAnimation(rise); cancelAnimation(opacity); cancelAnimation(wing); };
  }, [opacity, paused, reduceMotion, rise, signal, wing]);
  const variant = getButterflyVariant(sessionId);
  return <Animated.View pointerEvents="none" style={[styles.butterfly, style]}><Animated.View style={[styles.butterflyWing, styles.butterflyWingLeft, leftWing, { backgroundColor: variant.primary }]} /><Animated.View style={[styles.butterflyWing, styles.butterflyWingRight, rightWing, { backgroundColor: variant.secondary }]} /><View style={styles.butterflyBody}><View style={styles.butterflyAntenna} /><View style={[styles.butterflyAntenna, styles.butterflyAntennaRight]} /></View></Animated.View>;
}

function LegPair({ index, paused, reduceMotion, stageSignal }: { index: number; paused: boolean; reduceMotion: boolean; stageSignal: number }) {
  const leg = useSharedValue(0);
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: leg.value }] }));
  useEffect(() => {
    if (!stageSignal || reduceMotion) return;
    leg.value = 0;
    leg.value = withDelay(index * 40, withSequence(withTiming(3, { duration: 120, easing: Easing.out(Easing.quad) }), withTiming(0, { duration: 140, easing: Easing.in(Easing.quad) })));
  }, [index, leg, reduceMotion, stageSignal]);
  useEffect(() => { if (paused) cancelAnimation(leg); }, [leg, paused]);
  return <Animated.View style={[styles.legPair, style]}><View style={styles.leg} /><View style={[styles.leg, styles.legRight]} /></Animated.View>;
}

function GardenMotes({ count, paused, reduceMotion }: { count: number; paused: boolean; reduceMotion: boolean }) {
  return <View pointerEvents="none" style={styles.moteLayer}>{Array.from({ length: count }, (_, index) => <AmbientMote key={index} index={index} paused={paused} reduceMotion={reduceMotion} color="#F5E99A" />)}</View>;
}

const GARDEN_SPROUT_POINTS = [[8, 42], [18, 52], [29, 45], [40, 60], [51, 48], [63, 57], [76, 43], [88, 53], [13, 69], [24, 76], [36, 67], [47, 80], [59, 70], [71, 77], [84, 66], [94, 73], [5, 88], [17, 91], [31, 86], [44, 94], [56, 87], [68, 93], [80, 85], [92, 91], [38, 38], [68, 35]] as const;
const HIVE_WAX_POINTS = [[39, 5], [56, 5], [26, 18], [72, 18], [12, 34], [86, 34], [4, 52], [94, 52], [8, 72], [90, 72], [18, 88], [80, 88], [29, 104], [69, 104], [39, 119], [56, 119], [25, 136], [73, 136], [12, 151], [86, 151], [48, 20], [48, 151], [20, 49], [76, 49], [30, 75], [66, 75]] as const;

function GardenRoundDetails({ journeyRound, tint }: { journeyRound: number; tint: string }) {
  const unlocked = Math.min(26, Math.max(0, journeyRound));
  return <View pointerEvents="none" style={styles.gardenRoundDetails}>{GARDEN_SPROUT_POINTS.slice(0, unlocked).map(([left, bottom], index) => <View key={index} style={[styles.gardenSprout, { left: `${left}%`, bottom: `${bottom}%`, backgroundColor: tint, transform: [{ rotate: `${index % 2 ? 18 : -18}deg` }, { scale: 0.75 + (index % 4) * 0.08 }] }]} />)}</View>;
}

function HiveRoundDetails({ journeyRound, tint }: { journeyRound: number; tint: string }) {
  const unlocked = Math.min(26, Math.max(0, journeyRound));
  return <View pointerEvents="none" style={styles.hiveRoundDetails}>{HIVE_WAX_POINTS.slice(0, unlocked).map(([left, top], index) => <View key={index} style={[styles.hiveWaxCell, { left: `${left}%`, top, backgroundColor: index % 3 === 0 ? "#E9A83B" : tint }]}><View style={styles.hiveWaxHighlight} /></View>)}</View>;
}

const COMB_CELLS = Array.from({ length: 42 }, (_, index) => ({ x: 24 + (index % 7) * 22 + (Math.floor(index / 7) % 2 ? 11 : 0), y: 69 + Math.floor(index / 7) * 14 }));

function HangingComb({ journeyProgress, stage, storyComplete }: Pick<SceneProps, "journeyProgress" | "stage" | "storyComplete">) {
  const visibleCells = Math.max(4, Math.min(COMB_CELLS.length, Math.ceil(journeyProgress * COMB_CELLS.length)));
  const combDepth = 48 + Math.min(68, Math.round(journeyProgress * 68));
  return <View pointerEvents="none" style={styles.hangingComb}><Svg width="178" height="166" viewBox="0 0 178 166"><Path d="M18 17 C49 12, 127 12, 160 18" fill="none" stroke="#4E2D1A" strokeWidth="6" strokeLinecap="round" /><Path d="M31 22 C52 27, 125 27, 147 22" fill="none" stroke="#8A5726" strokeWidth="2" strokeLinecap="round" /><Path d={`M28 35 Q89 20 150 35 L${142 - combDepth * 0.12} ${54 + combDepth} Q89 ${153 + combDepth * 0.08} ${36 + combDepth * 0.12} ${54 + combDepth} Z`} fill={storyComplete ? "#C77722" : stage >= 3 ? "#D9952F" : "#E3AA43"} stroke="#774317" strokeWidth="3" /><Path d={`M38 47 Q89 33 140 47 L${136 - combDepth * 0.1} ${58 + combDepth * 0.88} Q89 ${139 + combDepth * 0.06} ${42 + combDepth * 0.1} ${58 + combDepth * 0.88} Z`} fill="#F0B94E" opacity="0.7" />{COMB_CELLS.map(({ x, y }, index) => index < visibleCells ? <Polygon key={index} points={`${x},${y} ${x + 8},${y - 5} ${x + 16},${y} ${x + 16},${y + 9} ${x + 8},${y + 14} ${x},${y + 9}`} fill={index % 5 === 0 ? "#8E4B1E" : "#B96420"} opacity={0.45 + (index / COMB_CELLS.length) * 0.42} /> : null)}{stage >= 2 ? <Path d="M34 50 Q89 39 144 50" fill="none" stroke="#FFE7A0" strokeWidth="3" opacity={0.82} /> : null}<Path d="M48 30 Q89 18 130 30" fill="none" stroke="#FFF0B1" strokeWidth="3" opacity={0.7} /></Svg></View>;
}

function HiveScene({ journeyRound, stage, journeyProgress, storyComplete, paused, reduceMotion, stageSignal, capstoneSignal, settling, onStageSettled, tint }: SceneProps) {
  const shafts = useSharedValue(0.24);
  const settle = useSharedValue(1);
  const worldStyle = useAnimatedStyle(() => ({ opacity: settle.value }));
  const shaftStyle = useAnimatedStyle(() => ({ opacity: shafts.value }));
  useEffect(() => {
    if (paused || reduceMotion) { cancelAnimation(shafts); return; }
    shafts.value = withRepeat(withSequence(withTiming(0.48, { duration: 3_500, easing: Easing.inOut(Easing.sin) }), withTiming(0.2, { duration: 3_500, easing: Easing.inOut(Easing.sin) })), -1, true);
    return () => cancelAnimation(shafts);
  }, [paused, reduceMotion, shafts]);
  useEffect(() => {
    if (!settling || reduceMotion) { settle.value = 1; return; }
    settle.value = withSequence(withDelay(900, withTiming(0.86, { duration: 600, easing: Easing.inOut(Easing.quad) })), withTiming(0, { duration: 300 }));
  }, [reduceMotion, settle, settling]);
  const beeCount = getHiveBeeCount(journeyRound);
  return <Animated.View style={[styles.world, worldStyle]}>
    <View style={styles.hiveBackdrop}><Animated.View style={[styles.lightShaftOne, shaftStyle]} /><Animated.View style={[styles.lightShaftTwo, shaftStyle]} /></View>
    <HiveLandscape stage={stage} />
    <View style={styles.hiveCluster}><HangingComb journeyProgress={journeyProgress} stage={stage} storyComplete={storyComplete} /><View style={styles.hiveCells}>{[0, 1, 2, 3].map((index) => index < Math.ceil(journeyProgress * 4) ? <HoneyCell key={index} index={index} journeyProgress={journeyProgress} storyComplete={storyComplete} signal={stageSignal} capstoneSignal={capstoneSignal} tint={tint} paused={paused} reduceMotion={reduceMotion} onStageSettled={index === Math.ceil(journeyProgress * 4) - 1 ? onStageSettled : undefined} /> : null)}</View></View>
    <HiveRoundDetails journeyRound={journeyRound} tint={tint} />
    {Array.from({ length: beeCount }, (_, index) => <RoamingBee key={index} index={index} journeyRound={journeyRound} paused={paused} reduceMotion={reduceMotion} settling={settling} />)}
    {stage >= 3 ? <View pointerEvents="none" style={styles.hivePollen}>{Array.from({ length: 3 }, (_, index) => <AmbientMote key={index} index={index + 2} paused={paused} reduceMotion={reduceMotion} color="#F5C75A" />)}</View> : null}
    <BurstParticles pattern={HIVE_BURST} signal={stageSignal + capstoneSignal} color="#FFD668" paused={paused} reduceMotion={reduceMotion} />
  </Animated.View>;
}

function HoneyCell({ index, journeyProgress, storyComplete, signal, capstoneSignal, tint, paused, reduceMotion, onStageSettled }: { index: number; journeyProgress: number; storyComplete: boolean; signal: number; capstoneSignal: number; tint: string; paused: boolean; reduceMotion: boolean; onStageSettled?: () => void }) {
  const pop = useSharedValue(1);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: pop.value }] }));
  const fill = storyComplete || (capstoneSignal && index === 3) ? 100 : Math.min(100, Math.max(0, Math.round((journeyProgress * 4 - index) * 100)));
  const position = [[48, 11], [17, 56], [79, 56], [48, 101]][index] ?? [48, 11];
  useEffect(() => {
    if (!signal || reduceMotion) return;
    pop.value = 0.78;
    pop.value = withSequence(withTiming(1.08, { duration: 320, easing: Easing.out(Easing.cubic) }), withTiming(1, { duration: 260, easing: Easing.out(Easing.quad) }, (finished) => { if (finished && onStageSettled) runOnJS(onStageSettled)(); }));
  }, [onStageSettled, pop, reduceMotion, signal]);
  useEffect(() => { if (paused) cancelAnimation(pop); }, [paused, pop]);
  return <Animated.View style={[styles.honeyCell, style, { left: position[0], top: position[1] }]}><Svg width="69" height="77" viewBox="0 0 69 77"><Polygon points="34.5,3 62,18.5 62,50.5 34.5,66 7,50.5 7,18.5" fill="#FBE8AE" stroke="#9A6221" strokeWidth="3" /><Polygon points="34.5,6 59,20 59,49 34.5,63 10,49 10,20" fill="none" stroke="#FFF6D1" strokeWidth="1.4" opacity={0.85} />{fill ? <Polygon points="34.5,9 57,22 57,49 34.5,62 12,49 12,22" fill={fill === 100 ? "#D88B26" : tint} opacity={0.18 + (fill / 100) * 0.74} /> : null}{fill >= 90 ? <><Path d="M19 27 C28 18, 42 19, 51 24" fill="none" stroke="#FFF8D6" strokeWidth="4" strokeLinecap="round" opacity={0.84} /><Circle cx="47" cy="32" r="3" fill="#FFF1A9" opacity={0.88} /><Circle cx="25" cy="43" r="1.8" fill="#FFF1A9" opacity={0.72} /></> : null}</Svg></Animated.View>;
}

function RoamingBee({ index, journeyRound, paused, reduceMotion, settling }: { index: number; journeyRound: number; paused: boolean; reduceMotion: boolean; settling: boolean }) {
  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const buzz = useSharedValue(0);
  const wingBeat = useSharedValue(0);
  const opacity = useSharedValue(0);
  const left = BEE_POSITIONS[index]?.[0] ?? 50;
  const top = BEE_POSITIONS[index]?.[1] ?? 50;
  const [perchX, perchY] = BEE_PERCHES[index] ?? [10, 16];
  const flightStyle = useAnimatedStyle(() => ({ opacity: opacity.value, transform: [{ translateX: x.value }, { translateY: y.value + buzz.value }, { rotate: `${(x.value * 0.18) + (index % 2 ? 2 : -2)}deg` }] }));
  const wingStyle = useAnimatedStyle(() => ({ transform: [{ scaleY: 0.72 + wingBeat.value * 0.42 }] }));
  useEffect(() => {
    if (paused || reduceMotion || settling) { cancelAnimation(x); cancelAnimation(y); cancelAnimation(buzz); cancelAnimation(wingBeat); return; }
    opacity.value = withTiming(1, { duration: 350 });
    const duration = 2_900 + index * 230;
    const flyer = index % 4 === 2 || index % 5 === 0;
    const flightX = flyer ? (index % 2 ? 12 : -12) : 0;
    const flightY = flyer ? (index % 3 ? 8 : -8) : 0;
    const loopPause = flyer ? 1_250 + (index % 3) * 280 : 2_800;
    x.value = withRepeat(flyer ? withSequence(withTiming(flightX * 0.35, { duration: duration * 0.28, easing: Easing.inOut(Easing.sin) }), withTiming(flightX, { duration: duration * 0.28, easing: Easing.inOut(Easing.sin) }), withDelay(loopPause, withTiming(flightX, { duration: 1 })), withTiming(-flightX * 0.65, { duration: duration * 0.45, easing: Easing.inOut(Easing.sin) }), withTiming(-flightX * 0.18, { duration: duration * 0.32, easing: Easing.inOut(Easing.sin) }), withDelay(loopPause * 0.72, withTiming(-flightX * 0.18, { duration: 1 })), withTiming(0, { duration: duration * 0.42, easing: Easing.inOut(Easing.sin) })) : withSequence(withDelay(loopPause, withTiming(0, { duration: 1 }))), -1, false);
    y.value = withRepeat(flyer ? withSequence(withTiming(flightY, { duration: duration * 0.34, easing: Easing.inOut(Easing.sin) }), withTiming(flightY * 0.35, { duration: duration * 0.28, easing: Easing.inOut(Easing.sin) }), withDelay(loopPause, withTiming(flightY * 0.35, { duration: 1 })), withTiming(-flightY * 0.55, { duration: duration * 0.45, easing: Easing.inOut(Easing.sin) }), withTiming(-flightY * 0.12, { duration: duration * 0.32, easing: Easing.inOut(Easing.sin) }), withDelay(loopPause * 0.72, withTiming(-flightY * 0.12, { duration: 1 })), withTiming(0, { duration: duration * 0.42, easing: Easing.inOut(Easing.sin) })) : withSequence(withDelay(loopPause, withTiming(0, { duration: 1 }))), -1, false);
    buzz.value = withRepeat(withSequence(withTiming(-0.9, { duration: 95, easing: Easing.inOut(Easing.sin) }), withTiming(0.9, { duration: 95, easing: Easing.inOut(Easing.sin) }), withDelay(820, withTiming(0, { duration: 120 })), withTiming(-0.9, { duration: 95, easing: Easing.inOut(Easing.sin) }), withTiming(0.9, { duration: 95, easing: Easing.inOut(Easing.sin) })), -1, false);
    wingBeat.value = withRepeat(withSequence(withTiming(1, { duration: 105 }), withTiming(0, { duration: 105 }), withDelay(700 + (index % 3) * 180, withTiming(0, { duration: 120 }))), -1, false);
    return () => { cancelAnimation(x); cancelAnimation(y); cancelAnimation(buzz); cancelAnimation(wingBeat); };
  }, [buzz, index, opacity, paused, reduceMotion, settling, wingBeat, x, y]);
  useEffect(() => { if (!settling || reduceMotion) return; opacity.value = withTiming(0, { duration: 900 + index * 150, easing: Easing.in(Easing.quad) }); }, [index, opacity, reduceMotion, settling]);
  return <Animated.View pointerEvents="none" style={[styles.bee, flightStyle, { left: `${left}%`, top: `${top}%` }]}><Animated.View style={[styles.beeWingLeft, wingStyle]} /><Animated.View style={[styles.beeWingRight, wingStyle]} /><View style={styles.beeAntennaLeft} /><View style={styles.beeAntennaRight} /><View style={styles.beeLegPair}><View style={styles.beeLeg} /><View style={[styles.beeLeg, styles.beeLegRight]} /></View><View style={styles.beeBody}><View style={styles.beeHead}><View style={styles.beeEye} /></View><View style={styles.beeThorax} /><View style={styles.beeAbdomen}><View style={styles.beeStripe} /><View style={styles.beeStripe} /><View style={styles.beeStripe} /></View><View style={styles.beeTail} /></View></Animated.View>;
}

function RiverScene({ journeyRound, journeyProgress, paused, reduceMotion }: Pick<SceneProps, "journeyRound" | "journeyProgress" | "paused" | "reduceMotion"> & { sessionId: string; storyComplete: boolean }) {
  const flow = useSharedValue(0);
  const shimmerStyle = useAnimatedStyle(() => ({ transform: [{ translateX: flow.value }] }));
  const phase = Math.max(0, Math.min(GROWTH_JOURNEY_ROUNDS, journeyRound));
  const flowers = Math.min(12, Math.max(0, Math.floor((phase - 6) / 2)));
  const fish = Math.min(3, Math.max(0, Math.floor((phase - 14) / 4)));
  const roamingBees = Math.min(4, Math.max(0, Math.floor((phase - 10) / 4)));
  const waterWidth = 7 + journeyProgress * 34;
  useEffect(() => {
    if (paused || reduceMotion) { cancelAnimation(flow); return; }
    flow.value = withRepeat(withSequence(withTiming(9, { duration: 1_800, easing: Easing.inOut(Easing.sin) }), withTiming(-9, { duration: 1_800, easing: Easing.inOut(Easing.sin) })), -1, true);
    return () => cancelAnimation(flow);
  }, [flow, paused, reduceMotion]);
  return <Animated.View style={styles.world}>
    <View style={styles.riverBackdrop} />
    <Svg width="100%" height="170" viewBox="0 0 320 170" preserveAspectRatio="none" style={styles.landscape} pointerEvents="none">
      <Path d="M-12 45 C54 28, 89 47, 135 40 C186 32, 222 17, 332 26 L332 174 L-12 174 Z" fill="#B9D889" />
      <Path d="M-12 69 C59 47, 93 65, 137 58 C191 49, 237 32, 332 42 L332 174 L-12 174 Z" fill="#79B86B" opacity={0.82} />
      <Path d={`M166 34 C${158 - waterWidth} 49, ${164 - waterWidth * 0.5} 66, 154 82 C${145 - waterWidth} 102, ${150 - waterWidth * 0.55} 123, 143 174 L177 174 C${170 + waterWidth} 124, ${174 + waterWidth * 0.55} 103, 166 82 C${156 + waterWidth * 0.5} 65, ${162 + waterWidth} 48, 166 34 Z`} fill="#74C7D6" stroke="#3E9CAD" strokeWidth="2" />
      <Path d="M166 34 C161 49, 164 67, 154 83 C149 102, 151 125, 143 174" fill="none" stroke="#D9F7F2" strokeWidth="2" opacity={0.9} />
      <Path d="M166 34 C171 49, 168 67, 166 83 C170 104, 168 126, 177 174" fill="none" stroke="#2D8699" strokeWidth="2" opacity={0.5} />
      <Path d="M160 35 Q166 25 172 35" fill="none" stroke="#EEFBEA" strokeWidth="3" strokeLinecap="round" />
      {Array.from({ length: flowers }, (_, index) => { const x = 20 + ((index * 37) % 282); const y = 92 + ((index * 19) % 58); return <><Path key={`stem-${index}`} d={`M${x} ${y + 8} L${x + (index % 2 ? 2 : -2)} ${y - 4}`} stroke="#347B48" strokeWidth="2" /><Circle key={`flower-${index}`} cx={x} cy={y - 6} r="4" fill={index % 3 === 0 ? "#ECA5B8" : index % 3 === 1 ? "#F5C85B" : "#A997D8"} /></>; })}
      {Array.from({ length: fish }, (_, index) => { const x = 135 + index * 18; const y = 117 + (index % 2) * 20; return <Path key={`fish-${index}`} d={`M${x} ${y} q8 -7 16 0 q-8 7 -16 0 M${x + 16} ${y} l6 -5 l-1 5 l1 5 Z`} fill="#E9945F" stroke="#A95F48" strokeWidth="1.3" />; })}
    </Svg>
    <Animated.View pointerEvents="none" style={[styles.riverShimmer, shimmerStyle]}><View style={styles.riverShimmerLine} /><View style={[styles.riverShimmerLine, styles.riverShimmerLineTwo]} /><View style={[styles.riverShimmerLine, styles.riverShimmerLineThree]} /></Animated.View>
    {Array.from({ length: roamingBees }, (_, index) => <RoamingBee key={`river-bee-${index}`} index={(index * 3) % BEE_POSITIONS.length} journeyRound={journeyRound} paused={paused} reduceMotion={reduceMotion} settling={false} />)}
  </Animated.View>;
}

function GardenLandscape({ stage }: { stage: number }) {
  return <Svg width="100%" height="170" viewBox="0 0 320 170" preserveAspectRatio="none" style={styles.landscape} pointerEvents="none"><Path d="M-12 28 C33 7, 72 10, 113 36 C146 56, 191 49, 238 20 C272 0, 300 1, 337 13" fill="none" stroke="#527953" strokeWidth="11" strokeLinecap="round" opacity={0.78} /><Path d="M4 36 C45 10, 73 18, 101 41 M197 45 C216 20, 250 13, 288 19" fill="none" stroke="#8DBA7D" strokeWidth="5" strokeLinecap="round" opacity={0.74} /><Ellipse cx="44" cy="66" rx="16" ry="8" fill="#B4DA8D" opacity={0.75} transform="rotate(-32 44 66)" /><Ellipse cx="278" cy="54" rx="18" ry="8" fill="#B4DA8D" opacity={0.75} transform="rotate(28 278 54)" />{stage >= 2 ? <><Circle cx="43" cy="117" r="6" fill="#F2A8B3" /><Circle cx="37" cy="111" r="5" fill="#FFD985" /><Circle cx="50" cy="111" r="5" fill="#FFD985" /><Circle cx="283" cy="126" r="6" fill="#B88DCE" /><Circle cx="277" cy="120" r="5" fill="#F1B2D0" /><Circle cx="289" cy="120" r="5" fill="#F1B2D0" /></> : null}{stage >= 3 ? <><Circle cx="83" cy="133" r="6" fill="#F0A66E" /><Circle cx="77" cy="127" r="5" fill="#FFE08C" /><Circle cx="89" cy="127" r="5" fill="#FFE08C" /><Circle cx="233" cy="139" r="6" fill="#F29FB8" /><Circle cx="227" cy="133" r="5" fill="#F6E29A" /><Circle cx="239" cy="133" r="5" fill="#F6E29A" /></> : null}</Svg>;
}

function HiveLandscape({ stage }: { stage: number }) {
  return <Svg width="100%" height="170" viewBox="0 0 320 170" preserveAspectRatio="none" style={styles.landscape} pointerEvents="none"><Path d="M-18 28 C58 18, 112 24, 164 27 C224 31, 278 22, 338 15" fill="none" stroke="#654529" strokeWidth="16" strokeLinecap="round" /><Path d="M-9 22 C62 14, 116 20, 166 23 C226 27, 281 18, 332 11" fill="none" stroke="#94704A" strokeWidth="4" strokeLinecap="round" opacity={0.85} /><Path d="M54 29 Q39 52 47 70 M267 26 Q281 49 273 69" fill="none" stroke="#4D7A4A" strokeWidth="3" strokeLinecap="round" opacity={0.78} /><Ellipse cx="42" cy="72" rx="16" ry="7" fill="#8EB873" opacity={0.8} transform="rotate(-28 42 72)" /><Ellipse cx="278" cy="70" rx="16" ry="7" fill="#9AC47A" opacity={0.8} transform="rotate(28 278 70)" />{stage >= 2 ? <Path d="M85 29 Q98 41 116 37" fill="none" stroke="#719D5A" strokeWidth="3" strokeLinecap="round" opacity={0.7} /> : null}</Svg>;
}

function AmbientMote({ index, paused, reduceMotion, color }: { index: number; paused: boolean; reduceMotion: boolean; color: string }) {
  const y = useSharedValue(0);
  const x = useSharedValue(0);
  const opacity = useSharedValue(0.2);
  const left = 31 + index * 10;
  const top = 56 + (index % 2) * 12;
  const style = useAnimatedStyle(() => ({ opacity: opacity.value, transform: [{ translateX: x.value }, { translateY: y.value }] }));
  useEffect(() => {
    if (paused || reduceMotion) { cancelAnimation(x); cancelAnimation(y); cancelAnimation(opacity); return; }
    const duration = 2_000 + index * 240;
    x.value = withRepeat(withSequence(withTiming(index % 2 ? 7 : -7, { duration, easing: Easing.inOut(Easing.sin) }), withTiming(0, { duration, easing: Easing.inOut(Easing.sin) })), -1, true);
    y.value = withRepeat(withSequence(withTiming(-22, { duration, easing: Easing.inOut(Easing.sin) }), withTiming(0, { duration, easing: Easing.inOut(Easing.sin) })), -1, true);
    opacity.value = withRepeat(withSequence(withTiming(0.95, { duration: duration * 0.55 }), withTiming(0.18, { duration: duration * 0.45 })), -1, true);
    return () => { cancelAnimation(x); cancelAnimation(y); cancelAnimation(opacity); };
  }, [index, opacity, paused, reduceMotion, x, y]);
  return <Animated.View style={[styles.ambientMote, style, { left: `${left}%`, top: `${top}%`, backgroundColor: color }]} />;
}

function BurstParticles({ pattern, signal, color, paused, reduceMotion }: { pattern: readonly (readonly [number, number])[]; signal: number; color: string; paused: boolean; reduceMotion: boolean }) {
  return <View pointerEvents="none" style={styles.burstLayer}>{pattern.map(([x, y], index) => <BurstParticle key={index} x={x} y={y} signal={signal} color={color} paused={paused} reduceMotion={reduceMotion} delay={index * 38 + 90} />)}</View>;
}

function BurstParticle({ x, y, signal, color, paused, reduceMotion, delay }: { x: number; y: number; signal: number; color: string; paused: boolean; reduceMotion: boolean; delay: number }) {
  const offsetX = useSharedValue(0);
  const offsetY = useSharedValue(0);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.4);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value, transform: [{ translateX: offsetX.value }, { translateY: offsetY.value }, { scale: scale.value }] }));
  useEffect(() => {
    if (!signal || reduceMotion) return;
    offsetX.value = 0; offsetY.value = 0; opacity.value = 0; scale.value = 0.4;
    offsetX.value = withDelay(delay, withTiming(x, { duration: 520, easing: Easing.out(Easing.cubic) }));
    offsetY.value = withDelay(delay, withTiming(y, { duration: 520, easing: Easing.out(Easing.cubic) }));
    opacity.value = withDelay(delay, withSequence(withTiming(1, { duration: 120 }), withTiming(0, { duration: 420 })));
    scale.value = withDelay(delay, withSequence(withTiming(1, { duration: 160 }), withTiming(0.2, { duration: 360 })));
  }, [delay, offsetX, offsetY, opacity, reduceMotion, scale, signal, x, y]);
  useEffect(() => { if (paused) { cancelAnimation(offsetX); cancelAnimation(offsetY); cancelAnimation(opacity); cancelAnimation(scale); } }, [offsetX, offsetY, opacity, paused, scale]);
  return <Animated.View style={[styles.burstParticle, style, { backgroundColor: color }]} />;
}

type SceneProps = {
  sessionId: string;
  stage: number;
  journeyRound: number;
  journeyProgress: number;
  storyComplete: boolean;
  paused: boolean;
  reduceMotion: boolean;
  stageSignal: number;
  capstoneSignal: number;
  settling: boolean;
  tint: string;
  onStageSettled?: () => void;
};

const styles = StyleSheet.create({
  section: { marginTop: 18 }, heading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }, eyebrow: { color: "#087A50", fontSize: 9, fontWeight: "900", letterSpacing: 1.15 }, title: { color: "#173423", fontSize: 17, fontWeight: "900", marginTop: 2 }, themeBadge: { color: "#087A50", fontSize: 9, fontWeight: "900", letterSpacing: 0.75, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10, backgroundColor: "#EAF7EC" }, hiveBadge: { color: "#9E6815", backgroundColor: "#FFF2CE" }, riverBadge: { color: "#247A7E", backgroundColor: "#DDF6F1" }, sceneCard: { height: 196, overflow: "hidden", borderColor: "#D3E6D6", backgroundColor: "#F4FAF3" }, world: { ...StyleSheet.absoluteFillObject, overflow: "hidden" }, caption: { position: "absolute", left: 0, right: 0, bottom: 0, minHeight: 27, paddingHorizontal: 11, justifyContent: "center", backgroundColor: "#FFFDF8E8" }, captionText: { color: "#5F7766", fontSize: 9, lineHeight: 13, fontWeight: "800", textAlign: "center" },
  neutralSky: { ...StyleSheet.absoluteFillObject, backgroundColor: "#EFF8F0" }, neutralDappleOne: { position: "absolute", width: 135, height: 135, borderRadius: 70, backgroundColor: "#E0F0C6", opacity: 0.46, right: -22, top: -28 }, neutralDappleTwo: { position: "absolute", width: 102, height: 102, borderRadius: 52, backgroundColor: "#D7EADB", opacity: 0.75, left: -26, top: 25 }, neutralBranch: { position: "absolute", bottom: 1 }, neutralLabel: { position: "absolute", bottom: 46, left: 26, right: 26, color: "#5B7762", fontSize: 11, lineHeight: 16, fontWeight: "800", textAlign: "center" },
  gardenBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "#EFF8E7" }, gardenDapple: { position: "absolute", width: 135, height: 135, borderRadius: 70, backgroundColor: "#FFF2B5", top: -30, right: 12 }, gardenLeafBlurOne: { position: "absolute", width: 78, height: 106, borderRadius: 50, backgroundColor: "#9DCE85", opacity: 0.2, left: -10, top: 12, transform: [{ rotate: "-23deg" }] }, gardenLeafBlurTwo: { position: "absolute", width: 84, height: 122, borderRadius: 54, backgroundColor: "#70B578", opacity: 0.16, right: -22, top: 47, transform: [{ rotate: "28deg" }] }, landscape: { position: "absolute", left: 0, right: 0, top: 0, bottom: 0 }, grassBand: { position: "absolute", bottom: 26, left: 0, right: 0, height: 26, backgroundColor: "#87C77D" }, grassBlade: { position: "absolute", bottom: 0, width: 3, borderRadius: 2, backgroundColor: "#4E9C62" }, mainLeaf: { position: "absolute", width: 230, height: 105, left: "50%", marginLeft: -115, bottom: 29, shadowColor: "#264A2C", shadowOpacity: 0.2, shadowRadius: 7, shadowOffset: { width: 0, height: 4 }, elevation: 3 }, caterpillarWrap: { position: "absolute", width: 150, height: 86, left: "50%", marginLeft: -65, bottom: 55, alignItems: "center", justifyContent: "center" }, caterpillar: { height: 31, width: 112, flexDirection: "row", alignItems: "center", justifyContent: "center", shadowColor: "#214C2A", shadowOpacity: 0.25, shadowRadius: 5, shadowOffset: { width: 0, height: 4 }, elevation: 3 }, caterpillarSegment: { width: 27, height: 27, borderRadius: 15, borderWidth: 1.5, borderColor: "#2B7C48", alignItems: "center", justifyContent: "center" }, caterpillarEye: { position: "absolute", width: 5, height: 5, borderRadius: 3, backgroundColor: "#153120", right: 6, top: 7 }, caterpillarCheek: { position: "absolute", width: 7, height: 3, borderRadius: 3, backgroundColor: "#D5EEAE", opacity: 0.75, right: 5, bottom: 6 }, antennae: { position: "absolute", width: 40, height: 25, left: -3, top: -17 }, antenna: { position: "absolute", width: 2, height: 19, borderRadius: 2, backgroundColor: "#2F6C3E", transform: [{ rotate: "-26deg" }], left: 9 }, antennaRight: { left: 24, transform: [{ rotate: "26deg" }] }, legPair: { position: "absolute", width: 22, height: 11, bottom: -8 }, leg: { position: "absolute", width: 2, height: 9, borderRadius: 2, backgroundColor: "#29693D", left: 4, transform: [{ rotate: "22deg" }] }, legRight: { left: 16, transform: [{ rotate: "-22deg" }] }, preChrysalis: { width: 42, height: 61, alignItems: "center", justifyContent: "flex-end", transformOrigin: "top" }, chrysalisThread: { position: "absolute", top: 0, width: 1.5, height: 19, backgroundColor: "#6F8B6F" }, chrysalisGlow: { position: "absolute", bottom: 0, width: 58, height: 58, borderRadius: 29, backgroundColor: "#F7E58B", opacity: 0.34 }, chrysalisBody: { width: 31, height: 42, borderRadius: 18, backgroundColor: "#73A45C", borderWidth: 3, marginBottom: 0, overflow: "hidden", shadowColor: "#375B2B", shadowOpacity: 0.35, shadowRadius: 5, shadowOffset: { width: 0, height: 3 }, elevation: 3 }, chrysalisRidge: { position: "absolute", width: 4, top: 6, bottom: 6, left: 8, borderRadius: 3, backgroundColor: "#BEDC87", opacity: 0.7 }, chrysalisRidgeSecond: { position: "absolute", width: 3, top: 8, bottom: 7, right: 7, borderRadius: 3, backgroundColor: "#3E8150", opacity: 0.66 }, chrysalisHighlight: { position: "absolute", width: 10, height: 17, borderRadius: 8, top: 6, right: 8, backgroundColor: "#F2F0B5", opacity: 0.45 }, butterfly: { position: "absolute", width: 76, height: 54, left: "50%", marginLeft: -38, bottom: 76, alignItems: "center", justifyContent: "center" }, butterflyWing: { position: "absolute", width: 33, height: 42, borderRadius: 24, top: 5, opacity: 0.92, borderWidth: 1, borderColor: "#FFF5C9" }, butterflyWingLeft: { left: 3, transform: [{ rotate: "-22deg" }] }, butterflyWingRight: { right: 3, transform: [{ rotate: "22deg" }] }, butterflyBody: { width: 8, height: 35, borderRadius: 6, backgroundColor: "#453C2E", zIndex: 2 }, butterflyAntenna: { position: "absolute", width: 1.5, height: 13, borderRadius: 2, top: -10, left: 1, backgroundColor: "#453C2E", transform: [{ rotate: "-25deg" }] }, butterflyAntennaRight: { left: 5, transform: [{ rotate: "25deg" }] }, gardenSettlingShade: { ...StyleSheet.absoluteFillObject, backgroundColor: "#284033", opacity: 0.15 }, gardenRoundDetails: { ...StyleSheet.absoluteFillObject, zIndex: 2 }, gardenSprout: { position: "absolute", width: 13, height: 6, borderRadius: 8, borderWidth: 1, borderColor: "#F7F5D9", opacity: 0.88 },
  moteLayer: { ...StyleSheet.absoluteFillObject }, ambientMote: { position: "absolute", width: 5, height: 5, borderRadius: 3 }, burstLayer: { ...StyleSheet.absoluteFillObject, alignItems: "center", justifyContent: "center", pointerEvents: "none" }, burstParticle: { position: "absolute", width: 6, height: 6, borderRadius: 4 },
  hiveBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "#DDEBD2" }, riverBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "#DFF3EA" }, riverShimmer: { position: "absolute", left: "28%", right: "21%", top: 75, height: 92, overflow: "hidden", opacity: 0.72 }, riverShimmerLine: { position: "absolute", width: 74, height: 2, borderRadius: 2, backgroundColor: "#E8FFFA", top: 12, left: 4 }, riverShimmerLineTwo: { top: 42, left: 38, width: 58, opacity: 0.76 }, riverShimmerLineThree: { top: 68, left: 14, width: 92, opacity: 0.55 }, lightShaftOne: { position: "absolute", width: 58, height: 230, backgroundColor: "#FFE49A", opacity: 0.3, left: 42, top: -32, transform: [{ rotate: "-22deg" }] }, lightShaftTwo: { position: "absolute", width: 46, height: 230, backgroundColor: "#F9D77A", opacity: 0.22, right: 45, top: -40, transform: [{ rotate: "-22deg" }] }, hiveCluster: { position: "absolute", width: 200, height: 171, left: "50%", marginLeft: -100, bottom: 19 }, hangingComb: { position: "absolute", width: 178, height: 166, left: "50%", marginLeft: -89, top: 8, alignItems: "center" }, hiveCells: { ...StyleSheet.absoluteFillObject }, honeyCell: { position: "absolute", width: 69, height: 77, shadowColor: "#6D4016", shadowOpacity: 0.15, shadowRadius: 4, shadowOffset: { width: 0, height: 3 }, elevation: 2 }, bee: { position: "absolute", width: 36, height: 28, alignItems: "center", justifyContent: "center", zIndex: 5 }, beeBody: { width: 31, height: 16, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", zIndex: 2 }, beeHead: { position: "absolute", width: 9, height: 9, borderRadius: 6, backgroundColor: "#29241D", left: -3, top: 3, alignItems: "flex-end", justifyContent: "center", paddingRight: 1, zIndex: 4 }, beeEye: { width: 2.2, height: 2.2, borderRadius: 2, backgroundColor: "#FFFFFF" }, beeThorax: { width: 8, height: 14, borderRadius: 7, backgroundColor: "#4A3825", borderWidth: 1, borderColor: "#2A251D", zIndex: 2 }, beeAbdomen: { width: 18, height: 13, borderRadius: 8, backgroundColor: "#D58A27", borderWidth: 1.2, borderColor: "#6F451D", alignItems: "center", justifyContent: "space-evenly", overflow: "hidden", zIndex: 2 }, beeTail: { position: "absolute", width: 7, height: 5, right: -3, top: 5, borderLeftWidth: 3, borderRightWidth: 3, borderTopWidth: 5, borderLeftColor: "transparent", borderRightColor: "transparent", borderTopColor: "#2A251D", transform: [{ rotate: "90deg" }] }, beeStripe: { width: "100%", height: 2, backgroundColor: "#3F2E1E" }, beeLegPair: { position: "absolute", width: 18, height: 8, left: 10, bottom: 0, zIndex: 1 }, beeLeg: { position: "absolute", width: 1.4, height: 8, borderRadius: 2, backgroundColor: "#4A3825", left: 4, transform: [{ rotate: "20deg" }] }, beeLegRight: { left: 12, transform: [{ rotate: "-20deg" }] }, beeWingLeft: { position: "absolute", width: 15, height: 10, borderRadius: 9, backgroundColor: "#E9F6FB", opacity: 0.86, left: 2, top: 0, transform: [{ rotate: "-24deg" }] }, beeWingRight: { position: "absolute", width: 15, height: 10, borderRadius: 9, backgroundColor: "#E9F6FB", opacity: 0.86, right: 2, top: 0, transform: [{ rotate: "24deg" }] }, beeAntennaLeft: { position: "absolute", width: 7, height: 5, borderTopWidth: 1, borderLeftWidth: 1, borderColor: "#30281E", left: 4, top: 0, transform: [{ rotate: "-28deg" }], zIndex: 3 }, beeAntennaRight: { position: "absolute", width: 7, height: 5, borderTopWidth: 1, borderRightWidth: 1, borderColor: "#30281E", right: 4, top: 0, transform: [{ rotate: "28deg" }], zIndex: 3 }, hivePollen: { ...StyleSheet.absoluteFillObject }, hiveRoundDetails: { ...StyleSheet.absoluteFillObject, zIndex: 2 }, hiveWaxCell: { position: "absolute", width: 18, height: 16, borderRadius: 5, borderWidth: 1.2, borderColor: "#FFF2B1", opacity: 0.9, transform: [{ rotate: "30deg" }] }, hiveWaxHighlight: { position: "absolute", width: 6, height: 3, borderRadius: 3, backgroundColor: "#FFF8D2", opacity: 0.75, top: 3, left: 5 },
});
