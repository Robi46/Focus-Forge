import { describe, expect, it } from "vitest";

import { getChecklistSessionGoal, getNoteSessionGoal, normalizeNoteFolder, normalizeNoteTags, normalizePersonalNote, normalizeRoutineEntry, sortFolders, sortNotes, sortRoutine } from "../lib/focusforge-notes";

describe("FocusForge local notes and routine workspace", () => {
  it("keeps a meaningful note, trims checklist items, and ignores blank notes", () => {
    const note = normalizePersonalNote({
      id: "note-1",
      title: "  Exam plan  ",
      body: "  Review chapters  ",
      checklist: [{ id: "task-1", text: "  Practise equations ", checked: true }, { id: "task-2", text: " ", checked: false }],
      createdAtMs: 1,
      updatedAtMs: 2,
    });
    expect(note).toEqual(expect.objectContaining({ title: "Exam plan", body: "Review chapters", checklist: [{ id: "task-1", text: "Practise equations", checked: true }] }));
    expect(normalizePersonalNote({ title: " ", body: " ", checklist: [] })).toBeNull();
  });

  it("sorts pinned notes before newer ordinary notes", () => {
    const pinned = normalizePersonalNote({ id: "pinned", title: "Pinned", body: "", checklist: [], isPinned: true, createdAtMs: 1, updatedAtMs: 1 })!;
    const newer = normalizePersonalNote({ id: "newer", title: "Newer", body: "", checklist: [], isPinned: false, createdAtMs: 1, updatedAtMs: 99 })!;
    expect(sortNotes([newer, pinned]).map((note) => note.id)).toEqual(["pinned", "newer"]);
  });

  it("normalizes reusable tags and orders meaningful custom folders", () => {
    expect(normalizeNoteTags([" Exam ", "#exam", "Mathematics", " ", "mathematics"])).toEqual(["Exam", "Mathematics"]);
    const blue = normalizeNoteFolder({ id: "blue", name: "  Class notes ", color: "#1268A6", createdAtMs: 1 })!;
    const green = normalizeNoteFolder({ id: "green", name: "Archive", color: "not-a-colour", createdAtMs: 1 })!;
    expect(green.color).toBe("#087A50");
    expect(sortFolders([blue, green]).map((folder) => folder.name)).toEqual(["Archive", "Class notes"]);
  });

  it("normalizes, limits, and orders routine entries by day then hour", () => {
    const mondayAfternoon = normalizeRoutineEntry({ id: "late", dayIndex: 0, startHour: 15, durationHours: 2, title: "Practice", detail: "", color: "#1268A6", updatedAtMs: 1 })!;
    const mondayMorning = normalizeRoutineEntry({ id: "early", dayIndex: 0, startHour: 8, durationHours: 1, title: "Read", detail: "", color: "#087A50", updatedAtMs: 1 })!;
    const sunday = normalizeRoutineEntry({ id: "sunday", dayIndex: 7, startHour: -1, durationHours: 40, title: "Plan", detail: "", color: "not-a-colour", updatedAtMs: 1 })!;
    expect(sunday).toEqual(expect.objectContaining({ dayIndex: 6, startHour: 0, durationHours: 12, color: "#087A50" }));
    expect(sortRoutine([mondayAfternoon, sunday, mondayMorning]).map((entry) => entry.id)).toEqual(["early", "late", "sunday"]);
  });

  it("derives concise local session goals from notes and checklist items", () => {
    expect(getNoteSessionGoal({ title: "  Revise chemistry  ", body: "Longer context" })).toBe("Revise chemistry");
    expect(getNoteSessionGoal({ title: "", body: "  Read the chapter summary  " })).toBe("Read the chapter summary");
    expect(getChecklistSessionGoal({ text: "  Solve twenty algebra problems  " })).toBe("Solve twenty algebra problems");
  });
});
