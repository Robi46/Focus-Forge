const fs = require("node:fs");
const path = require("node:path");

const moduleFile = path.join(
  process.cwd(),
  "node_modules",
  "react-native-google-mobile-ads",
  "android",
  "src",
  "main",
  "java",
  "io",
  "invertase",
  "googlemobileads",
  "ReactNativeGoogleMobileAdsModule.kt",
);

if (!fs.existsSync(moduleFile)) {
  console.log("[mobile-ads-patch] Mobile Ads Android source is absent; skipping patch.");
  process.exit(0);
}

const replacements = [
  [
    "currentActivity ?: reactApplicationContext,",
    "reactApplicationContext.currentActivity ?: reactApplicationContext,",
  ],
  [
    "val activity = currentActivity",
    "val activity = reactApplicationContext.currentActivity",
  ],
  [
    "currentActivity?.runOnUiThread {\n      MobileAds.openDebugMenu(currentActivity!!, adUnit)",
    "reactApplicationContext.currentActivity?.runOnUiThread {\n      MobileAds.openDebugMenu(reactApplicationContext.currentActivity!!, adUnit)",
  ],
];

let source = fs.readFileSync(moduleFile, "utf8");
let changes = 0;

for (const [legacyCode, compatibleCode] of replacements) {
  if (source.includes(compatibleCode)) continue;
  if (!source.includes(legacyCode)) {
    throw new Error(`[mobile-ads-patch] Expected Mobile Ads source was not found: ${legacyCode}`);
  }
  source = source.replace(legacyCode, compatibleCode);
  changes += 1;
}

if (changes > 0) {
  fs.writeFileSync(moduleFile, source, "utf8");
  console.log(`[mobile-ads-patch] Applied ${changes} React Native 0.81 compatibility update(s).`);
} else {
  console.log("[mobile-ads-patch] Mobile Ads compatibility patch already applied.");
}
