import { describe, expect, it } from "vitest";

import { BUTTERFLY_VARIANTS, CHRYSALIS_THRESHOLD, EMPTY_FOCUS_GROWTH, GROWTH_JOURNEY_CYCLE_ROUNDS, GROWTH_JOURNEY_HOLD_ROUNDS, GROWTH_JOURNEY_ROUNDS, addGardenCompletion, addHiveCluster, createHiveCluster, didCompleteGrowthJourney, drawBalancedGrowthTheme, drawGrowthTheme, getButterflyVariant, getGrowthJourneyChapter, getGrowthJourneyProgress, getGrowthJourneyRound, getGrowthStage, getGrowthStageThreshold, getHiveBeeCount, normalizeFocusGrowth, normalizeGrowthTheme, normalizeGrowthThemeDeck, shouldResetGrowthJourney } from "../lib/focusforge-growth";

describe("FocusForge growth themes", () => {
  it("draws a fresh, independent three-way theme while keeping a stored session choice stable", () => {
    expect(drawGrowthTheme(() => 0.1)).toBe("butterfly");
    expect(drawGrowthTheme(() => 0.5)).toBe("hive");
    expect(drawGrowthTheme(() => 0.9)).toBe("river");
    const storedTheme = normalizeGrowthTheme("hive");
    expect(storedTheme).toBe("hive");
    expect(normalizeGrowthTheme("invalid")).toBe("butterfly");
  });

  it("uses a balanced-random fresh-session set so all three worlds follow the initial random draw", () => {
    const gardenFirst = drawBalancedGrowthTheme([], () => 0.1);
    expect(gardenFirst).toEqual({ theme: "butterfly", remainingDeck: ["hive", "river"] });
    const hiveSecond = drawBalancedGrowthTheme(gardenFirst.remainingDeck, () => 0.1);
    expect(hiveSecond).toEqual({ theme: "hive", remainingDeck: ["river"] });
    expect(drawBalancedGrowthTheme(hiveSecond.remainingDeck, () => 0.1)).toEqual({ theme: "river", remainingDeck: [] });

    const riverFirst = drawBalancedGrowthTheme([], () => 0.9);
    expect(riverFirst).toEqual({ theme: "river", remainingDeck: ["butterfly", "hive"] });
    expect(drawBalancedGrowthTheme(riverFirst.remainingDeck, () => 0.9)).toEqual({ theme: "butterfly", remainingDeck: ["hive"] });
    expect(normalizeGrowthThemeDeck(["hive", "butterfly"])).toEqual(["hive", "butterfly"]);
    expect(normalizeGrowthThemeDeck(["invalid"])).toEqual([]);
  });

  it("maps custom rhythm progress proportionally into the four visual stages", () => {
    expect([1, 2, 3, 4].map((stage) => getGrowthStageThreshold(stage, 4))).toEqual([1, 2, 3, 4]);
    expect([1, 2, 3, 4].map((stage) => getGrowthStageThreshold(stage, 6))).toEqual([2, 3, 5, 6]);
    expect(getGrowthStage(1, 6)).toBe(0);
    expect(getGrowthStage(2, 6)).toBe(1);
    expect(getGrowthStage(5, 6)).toBe(3);
    expect(getGrowthStage(6, 6)).toBe(4);
  });

  it("keeps the live story advancing across rest cycles and completes only on its twenty-sixth study round", () => {
    expect(GROWTH_JOURNEY_ROUNDS).toBe(26);
    expect(GROWTH_JOURNEY_HOLD_ROUNDS).toBe(2);
    expect(GROWTH_JOURNEY_CYCLE_ROUNDS).toBe(28);
    expect(getGrowthJourneyRound(4)).toBe(4);
    expect(getGrowthJourneyRound(20)).toBe(20);
    expect(getGrowthJourneyRound(99)).toBe(26);
    expect([0, 1, 7, 8, 13, 14, 19, 20, 25, 26].map(getGrowthJourneyChapter)).toEqual([0, 1, 1, 2, 2, 3, 3, 4, 4, 5]);
    expect(getGrowthJourneyProgress(13)).toBe(0.5);
    expect(getGrowthJourneyProgress(26)).toBe(1);
    expect(getHiveBeeCount(0)).toBe(1);
    expect(getHiveBeeCount(1)).toBe(1);
    expect(getHiveBeeCount(2)).toBe(2);
    expect(getHiveBeeCount(25)).toBe(13);
    expect(getHiveBeeCount(26)).toBe(14);
    expect(getHiveBeeCount(28)).toBe(14);
    expect(getGrowthJourneyRound(27)).toBe(26);
    expect(getGrowthJourneyRound(28)).toBe(26);
    expect(shouldResetGrowthJourney("reset", 4, 28)).toBe(false);
    expect(shouldResetGrowthJourney("focus", 2, 28)).toBe(false);
    expect(shouldResetGrowthJourney("focus", 1, 27)).toBe(false);
    expect(shouldResetGrowthJourney("focus", 1, 28)).toBe(true);
  });

  it("selects a stable colourful butterfly variant from the random session identity and fires completion only once", () => {
    expect(BUTTERFLY_VARIANTS).toHaveLength(5);
    expect(getButterflyVariant("random-session-a")).toEqual(getButterflyVariant("random-session-a"));
    expect(BUTTERFLY_VARIANTS).toContain(getButterflyVariant("random-session-b"));
    expect(didCompleteGrowthJourney(25, 26)).toBe(true);
    expect(didCompleteGrowthJourney(26, 27)).toBe(false);
    expect(didCompleteGrowthJourney(12, 20)).toBe(false);
  });

  it("increments the Garden only for qualifying complete butterfly cycles and emerges at the named threshold", () => {
    let state = EMPTY_FOCUS_GROWTH;
    for (let cycleIndex = 0; cycleIndex < CHRYSALIS_THRESHOLD; cycleIndex += 1) state = addGardenCompletion(state, { sessionId: `butterfly-${cycleIndex}`, cycleIndex: 0, subjectTag: "Physics", completedAtMs: cycleIndex + 1 });
    expect(state.garden).toHaveLength(0);
    expect(state.butterflies).toHaveLength(1);
    expect(state.butterflies[0]?.contributionIds).toHaveLength(CHRYSALIS_THRESHOLD);
    expect(addGardenCompletion(state, { sessionId: "butterfly-4", cycleIndex: 0, subjectTag: "Physics", completedAtMs: 9 })).toEqual(state);
  });

  it("preserves partial Hive cells exactly and caps the final cell only for a completed cycle", () => {
    const incomplete = createHiveCluster({ sessionId: "hive", completedAtMs: 1, subjectTag: "Chemistry", roundsCompleted: 4, roundsPlanned: 4, status: "incomplete" });
    const complete = createHiveCluster({ sessionId: "hive", cycleIndex: 0, completedAtMs: 2, subjectTag: "Chemistry", roundsCompleted: 4, roundsPlanned: 4, status: "complete" });
    expect(incomplete?.cells.map((cell) => cell.fillPercent)).toEqual([100, 100, 40, 0]);
    expect(complete?.cells.map((cell) => cell.fillPercent)).toEqual([100, 100, 100, 100]);
    expect(addHiveCluster(EMPTY_FOCUS_GROWTH, incomplete).hive[0]?.cells).toEqual(incomplete?.cells);
  });

  it("normalizes persisted boards without mutating existing archived entries", () => {
    const restored = normalizeFocusGrowth({ hive: [{ id: "hive-1", sessionId: "session", completedAtMs: 10, subjectTag: "Math", roundsCompleted: 3, roundsPlanned: 4, status: "incomplete", cells: [{ fillPercent: 100 }, { fillPercent: 40 }, { fillPercent: 0 }] }] });
    expect(restored.hive[0]).toEqual(expect.objectContaining({ roundsCompleted: 3, status: "incomplete" }));
    expect(restored.hive[0]?.cells.map((cell) => cell.fillPercent)).toEqual([100, 40, 0]);
  });
});
