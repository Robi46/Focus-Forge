import { describe, expect, it } from "vitest";

import { replayCue } from "../lib/cue-replay";

describe("cue replay", () => {
  it("awaits a rewind before every replay in a triple cue", async () => {
    const events: string[] = [];
    const player = {
      isLoaded: true,
      volume: 0,
      pause: () => events.push("pause"),
      seekTo: async (seconds: number) => {
        events.push(`seek:${seconds}`);
      },
      play: () => events.push("play"),
    };

    const played = await replayCue(player, 3, async () => {
      events.push("wait");
    });

    expect(played).toBe(true);
    expect(player.volume).toBe(1);
    expect(events).toEqual([
      "pause", "seek:0", "play", "wait",
      "pause", "seek:0", "play", "wait",
      "pause", "seek:0", "play",
    ]);
  });

  it("does not attempt playback before the asset is loaded", async () => {
    const events: string[] = [];
    const played = await replayCue({
      isLoaded: false,
      volume: 0,
      pause: () => events.push("pause"),
      seekTo: async () => {
        events.push("seek");
      },
      play: () => events.push("play"),
    }, 1, async () => {
      events.push("wait");
    });

    expect(played).toBe(false);
    expect(events).toEqual([]);
  });
});
