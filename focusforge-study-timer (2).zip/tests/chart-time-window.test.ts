import { describe, expect, it } from "vitest";

import { FULL_DAY_WINDOW, getTimeTicks, panTimeWindow, timePositionInWindow, zoomTimeWindow } from "../lib/chart-time-window";

describe("chart time-window math", () => {
  it("zooms the full day into a true centered six-hour data window", () => {
    expect(zoomTimeWindow(FULL_DAY_WINDOW, 4)).toEqual({ startHour: 9, endHour: 15 });
  });

  it("pans a zoomed time window by hours instead of translating rendered pixels", () => {
    expect(panTimeWindow({ startHour: 9, endHour: 15 }, 50, 300)).toEqual({ startHour: 8, endHour: 14 });
  });

  it("uses quarter-hour ticks for a two-hour range and preserves exact point positions", () => {
    const window = { startHour: 9, endHour: 11 };
    expect(getTimeTicks(window)).toEqual([9, 9.25, 9.5, 9.75, 10, 10.25, 10.5, 10.75, 11]);
    expect(timePositionInWindow(10.2, window, 300)).toBeCloseTo(180, 5);
  });
});
