export type CueEvent = 1 | 3;
export type CuePhase = "focus" | "reset" | "paused";

/**
 * Emits one event per newly completed study round. Every fourth completed
 * round marks the start of rest and therefore emits a three-beep event.
 */
export function getCompletedRoundCueEvents(
  previousRoundsCompleted: number,
  currentRoundsCompleted: number,
  roundsPerCycle: number,
): CueEvent[] {
  if (currentRoundsCompleted <= previousRoundsCompleted || roundsPerCycle < 1) return [];

  const events: CueEvent[] = [];
  for (let round = previousRoundsCompleted + 1; round <= currentRoundsCompleted; round += 1) {
    events.push(round % roundsPerCycle === 0 ? 3 : 1);
  }
  return events;
}

/**
 * Adds the requested single start cue only when a completed rest changes
 * into the first study round of the following cycle.
 */
export function getCycleCueEvents(
  previousRoundsCompleted: number,
  currentRoundsCompleted: number,
  roundsPerCycle: number,
  previousPhase: CuePhase,
  currentPhase: CuePhase,
  currentRoundNumber: number,
): CueEvent[] {
  const events = getCompletedRoundCueEvents(previousRoundsCompleted, currentRoundsCompleted, roundsPerCycle);
  if (previousPhase === "reset" && currentPhase === "focus" && currentRoundNumber === 1) {
    events.push(1);
  }
  return events;
}
