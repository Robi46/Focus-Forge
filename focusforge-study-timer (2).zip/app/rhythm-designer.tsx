import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { IconCircle, SectionLabel, Stepper, Surface } from "@/components/focusforge-ui";
import { ScreenContainer } from "@/components/screen-container";
import { DEFAULT_SESSION_PLAN, formatSessionPlan, type SessionPlan } from "@/lib/focusforge-core";
import { useFocusForgeStatic } from "@/lib/focusforge-provider";

export default function RhythmDesignerScreen() {
  const { settings, session, updateSettings } = useFocusForgeStatic();
  const [draft, setDraft] = useState<SessionPlan>({
    roundMinutes: settings.roundMinutes,
    roundsPerCycle: settings.roundsPerCycle,
    restSeconds: settings.restSeconds,
  });
  const isDefault = draft.roundMinutes === DEFAULT_SESSION_PLAN.roundMinutes && draft.roundsPerCycle === DEFAULT_SESSION_PLAN.roundsPerCycle && draft.restSeconds === DEFAULT_SESSION_PLAN.restSeconds;

  const save = async () => {
    await updateSettings(draft);
    router.back();
  };

  return <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}><IconCircle icon="arrow-back" onPress={() => router.back()} /><View style={styles.headerCopy}><Text style={styles.eyebrow}>DEFAULT RHYTHM</Text><Text style={styles.title}>Design your flow</Text></View></View>
      <Text style={styles.description}>Build the study cycle you want to repeat. Each study round ends with one beep; the final round closes with three beeps, then rest begins.</Text>

      <Surface style={styles.preview}><View style={styles.previewTop}><View style={styles.previewIcon}><MaterialIcons name="auto-graph" size={22} color="#087A50" /></View><Text style={styles.previewTag}>{isDefault ? "FOCUSFORGE DEFAULT" : "YOUR CUSTOM RHYTHM"}</Text></View><Text style={styles.previewValue}>{formatSessionPlan(draft)}</Text><Text style={styles.previewDetail}>{draft.roundsPerCycle - 1 > 0 ? `${draft.roundsPerCycle - 1} round-change beep${draft.roundsPerCycle - 1 === 1 ? "" : "s"}, ` : ""}three beeps before rest, one beep after rest.</Text></Surface>

      <View style={styles.section}><SectionLabel>BUILD THE CYCLE</SectionLabel><Surface>
        <DesignRow icon="timer" tone="#087A50" title="Study round" detail="Time for each uninterrupted study round." value={draft.roundMinutes} suffix="min" decrement={() => setDraft((value) => ({ ...value, roundMinutes: Math.max(1, value.roundMinutes - 1) }))} increment={() => setDraft((value) => ({ ...value, roundMinutes: Math.min(180, value.roundMinutes + 1) }))} min={1} max={180} />
        <View style={styles.divider} />
        <DesignRow icon="repeat" tone="#0BA66A" title="Rounds before rest" detail="How many study rounds complete one cycle." value={draft.roundsPerCycle} suffix="rounds" decrement={() => setDraft((value) => ({ ...value, roundsPerCycle: Math.max(1, value.roundsPerCycle - 1) }))} increment={() => setDraft((value) => ({ ...value, roundsPerCycle: Math.min(12, value.roundsPerCycle + 1) }))} min={1} max={12} />
        <View style={styles.divider} />
        <DesignRow icon="self-improvement" tone="#AE7418" title="Rest after cycle" detail="Recovery time before the next first round." value={Math.round(draft.restSeconds / 60)} suffix="min" decrement={() => setDraft((value) => ({ ...value, restSeconds: Math.max(60, value.restSeconds - 60) }))} increment={() => setDraft((value) => ({ ...value, restSeconds: Math.min(3600, value.restSeconds + 60) }))} min={1} max={60} />
      </Surface></View>

      <View style={styles.note}><MaterialIcons name="info-outline" size={19} color="#087A50" /><Text style={styles.noteText}>{session ? "A session is already running, so your saved rhythm will begin with your next session." : "Your saved rhythm will begin with your next session."} The current FocusForge default is 4 rounds × 5 minutes, then 2 minutes rest.</Text></View>
      {!isDefault ? <Pressable onPress={() => setDraft(DEFAULT_SESSION_PLAN)} style={({ pressed }) => [styles.resetButton, pressed && { opacity: 0.66 }]}><MaterialIcons name="restart-alt" size={18} color="#087A50" /><Text style={styles.resetText}>Restore FocusForge default</Text></Pressable> : null}
      <Pressable onPress={() => void save()} style={({ pressed }) => [styles.saveButton, pressed && { opacity: 0.86, transform: [{ scale: 0.98 }] }]}><Text style={styles.saveText}>Save rhythm</Text><MaterialIcons name="arrow-forward" size={20} color="#FFFFFF" /></Pressable>
    </ScrollView>
  </ScreenContainer>;
}

function DesignRow({ icon, tone, title, detail, value, suffix, decrement, increment, min, max }: { icon: keyof typeof MaterialIcons.glyphMap; tone: string; title: string; detail: string; value: number; suffix: string; decrement: () => void; increment: () => void; min: number; max: number }) {
  return <View style={styles.designRow}><View style={[styles.designIcon, { backgroundColor: `${tone}18` }]}><MaterialIcons name={icon} size={20} color={tone} /></View><View style={styles.designCopy}><Text style={styles.designTitle}>{title}</Text><Text style={styles.designDetail}>{detail}</Text></View><Stepper value={value} suffix={suffix} decrement={decrement} increment={increment} min={min} max={max} /></View>;
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 16, paddingBottom: 32 }, header: { flexDirection: "row", alignItems: "center", gap: 13 }, headerCopy: { flex: 1 }, eyebrow: { color: "#087A50", fontSize: 11, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#173423", fontSize: 27, lineHeight: 34, fontWeight: "900", marginTop: 4 }, description: { color: "#63796B", fontSize: 13, lineHeight: 19, marginTop: 15 }, preview: { padding: 18, marginTop: 20, borderColor: "#BDE2C6", backgroundColor: "#FCFFFC" }, previewTop: { flexDirection: "row", alignItems: "center", gap: 8 }, previewIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#E7F6EA", alignItems: "center", justifyContent: "center" }, previewTag: { color: "#087A50", fontSize: 10, fontWeight: "900", letterSpacing: 1.25 }, previewValue: { color: "#173423", fontSize: 21, fontWeight: "900", marginTop: 14 }, previewDetail: { color: "#63796B", fontSize: 12, lineHeight: 18, marginTop: 4 }, section: { marginTop: 23 }, designRow: { minHeight: 96, flexDirection: "row", alignItems: "center", padding: 16, gap: 11 }, designIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" }, designCopy: { flex: 1 }, designTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, designDetail: { color: "#63796B", fontSize: 11, lineHeight: 16, marginTop: 3 }, divider: { height: StyleSheet.hairlineWidth, marginLeft: 67, backgroundColor: "#DDECE0" }, note: { marginTop: 18, borderRadius: 15, padding: 14, flexDirection: "row", gap: 9, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#CDE5D2" }, noteText: { flex: 1, color: "#45634F", fontSize: 12, lineHeight: 18 }, resetButton: { marginTop: 13, minHeight: 45, borderRadius: 15, borderWidth: 1, borderColor: "#BFE0C5", backgroundColor: "#F4FBF5", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 }, resetText: { color: "#087A50", fontSize: 13, fontWeight: "900" }, saveButton: { minHeight: 56, borderRadius: 18, backgroundColor: "#087A50", marginTop: 13, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, shadowColor: "#087A50", shadowOpacity: 0.18, shadowRadius: 13, shadowOffset: { width: 0, height: 8 }, elevation: 4 }, saveText: { color: "#FFFFFF", fontSize: 15, fontWeight: "900" },
});
