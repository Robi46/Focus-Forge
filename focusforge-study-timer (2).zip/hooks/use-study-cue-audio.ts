import { setAudioModeAsync, useAudioPlayer } from "expo-audio";
import { useCallback } from "react";
import { Platform } from "react-native";

import { replayCue } from "@/lib/cue-replay";
import type { LockedScreenCueSound } from "@/lib/focusforge-core";

const beepAsset = require("@/assets/sounds/focusforge_beep.wav");
const emergenceAsset = require("@/assets/audio/emergence-completion.mp3");
const cueSoundAssets: Record<LockedScreenCueSound, number> = {
  classic: beepAsset,
  bright: require("@/assets/sounds/focusforge_bright.wav"),
  calm: require("@/assets/sounds/focusforge_calm.wav"),
};

export type CuePlaybackResult = "played" | "disabled" | "preview-only" | "unavailable";

function wait(milliseconds: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, milliseconds));
}

async function resetCueSource(player: ReturnType<typeof useAudioPlayer>, sound: LockedScreenCueSound) {
  player.pause();
  player.replace(cueSoundAssets[sound]);
  await wait(180);
  for (let attempt = 0; attempt < 10; attempt += 1) {
    if (player.isLoaded) return true;
    await wait(120);
  }
  return player.isLoaded;
}

/** Awaits a rewind on the preloaded player before every requested study-round cue. */
export function useStudyCueAudio(enabled: boolean) {
  const player = useAudioPlayer(beepAsset, { downloadFirst: true });

  return useCallback(async (count: 1 | 3 = 1, sound: LockedScreenCueSound = "classic", bypassEnabled = false): Promise<CuePlaybackResult> => {
    if (!enabled && !bypassEnabled) return "disabled";
    if (Platform.OS === "web") return "preview-only";
    try {
      await setAudioModeAsync({ playsInSilentMode: true });
    } catch {
      return "unavailable";
    }

    try {
      if (!await resetCueSource(player, sound)) return "unavailable";
      return await replayCue(player, count, wait) ? "played" : "unavailable";
    } catch {
      return "unavailable";
    }
  }, [enabled, player]);
}

/** A calm optional reward tone, played only when the 26-round butterfly emergence completes. */
export function useEmergenceCompletionAudio(enabled: boolean) {
  const player = useAudioPlayer(emergenceAsset, { downloadFirst: true });

  return useCallback(async (): Promise<CuePlaybackResult> => {
    if (!enabled) return "disabled";
    if (Platform.OS === "web") return "preview-only";
    try {
      await setAudioModeAsync({ playsInSilentMode: true });
      for (let attempt = 0; attempt < 10 && !player.isLoaded; attempt += 1) await wait(120);
      if (!player.isLoaded) return "unavailable";
      return await replayCue(player, 1, wait) ? "played" : "unavailable";
    } catch {
      return "unavailable";
    }
  }, [enabled, player]);
}
