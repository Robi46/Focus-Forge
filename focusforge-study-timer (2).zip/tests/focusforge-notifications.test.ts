import { describe, expect, it } from "vitest";

import { getScheduledFocusCues } from "../lib/focusforge-cue-schedule";
import { getCueChannelIds, getCueSoundConfig } from "../lib/focusforge-cue-sound-config";
import type { ActiveSession } from "../lib/focusforge-core";

const session: ActiveSession = {
  id: "screen-lock-test",
  startedAtMs: 0,
  accumulatedPausedMs: 0,
  notificationIds: [],
  plan: { roundMinutes: 5, roundsPerCycle: 4, restSeconds: 120 },
};

describe("installed Android cue schedule", () => {
  it("queues every active-session boundary including the post-rest round-one beep", () => {
    const cues = getScheduledFocusCues(session, 0, 0.3);
    expect(cues.map((cue) => cue.kind)).toEqual(["round", "round", "round", "checkpoint", "checkpoint", "checkpoint", "restart"]);
    expect(cues.map((cue) => cue.atMs)).toEqual([300_000, 600_000, 900_000, 1_200_000, 1_201_050, 1_202_100, 1_320_000]);
    expect(cues.at(-1)?.body).toContain("Begin round 1");
  });

  it("uses distinct versioned channel IDs and bundled files for each selectable locked-screen cue sound", () => {
    expect(getCueSoundConfig("bright").fileName).toBe("focusforge_bright.wav");
    expect(getCueSoundConfig("calm").fileName).toBe("focusforge_calm.wav");
    expect(getCueChannelIds("classic").focus).not.toBe(getCueChannelIds("bright").focus);
    expect(getCueChannelIds("bright").checkpoint).not.toBe(getCueChannelIds("calm").checkpoint);
  });
});
