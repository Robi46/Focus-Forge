import { useCallback, useState, type ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { runOnJS, useSharedValue } from "react-native-reanimated";
import { FULL_DAY_WINDOW, panTimeWindow, type TimeWindow, zoomTimeWindow } from "@/lib/chart-time-window";

export type { TimeWindow } from "@/lib/chart-time-window";

function rangeLabel(window: TimeWindow) {
  const format = (hour: number) => {
    const whole = Math.floor(hour);
    const minutes = Math.round((hour - whole) * 60);
    const safeHour = minutes === 60 ? whole + 1 : whole;
    const safeMinutes = minutes === 60 ? 0 : minutes;
    const displayHour = safeHour % 12 || 12;
    return `${displayHour}:${String(safeMinutes).padStart(2, "0")} ${safeHour < 12 || safeHour === 24 ? "AM" : "PM"}`;
  };
  return `${format(window.startHour)}–${format(window.endHour)}`;
}

export function DataZoomChart({ plotWidth, children }: { plotWidth: number; children: (window: TimeWindow) => ReactNode }) {
  const [window, setWindow] = useState<TimeWindow>(FULL_DAY_WINDOW);
  const pinchStartHour = useSharedValue(0);
  const pinchSpan = useSharedValue(24);
  const panStartHour = useSharedValue(0);

  const commitZoom = useCallback((startHour: number, spanHours: number, scale: number) => {
    setWindow(zoomTimeWindow({ startHour, endHour: startHour + spanHours }, scale));
  }, []);

  const commitPan = useCallback((startHour: number, spanHours: number, translationX: number) => {
    setWindow(panTimeWindow({ startHour, endHour: startHour + spanHours }, translationX, plotWidth));
  }, [plotWidth]);

  const pinch = Gesture.Pinch()
    .onBegin(() => {
      pinchStartHour.value = window.startHour;
      pinchSpan.value = window.endHour - window.startHour;
    })
    .onEnd((event) => {
      runOnJS(commitZoom)(pinchStartHour.value, pinchSpan.value, event.scale);
    });

  const pan = Gesture.Pan()
    .activeOffsetX([-5, 5])
    .failOffsetY([-12, 12])
    .onBegin(() => {
      panStartHour.value = window.startHour;
    })
    .onEnd((event) => {
      runOnJS(commitPan)(panStartHour.value, window.endHour - window.startHour, event.translationX);
    });

  const reset = () => setWindow(FULL_DAY_WINDOW);
  const span = window.endHour - window.startHour;

  return <View><View style={styles.controls}><View><Text style={styles.hint}>PINCH TO CHANGE TIME RANGE · DRAG TO PAN</Text><Text style={styles.range}>{rangeLabel(window)} · {span < 24 ? `${Math.round(span * 60)} MIN WINDOW` : "FULL 24 HOURS"}</Text></View><Pressable onPress={reset} style={({ pressed }) => [styles.reset, span === 24 && styles.resetMuted, pressed && { opacity: 0.7 }]}><Text style={styles.resetText}>24h</Text></Pressable></View><GestureDetector gesture={Gesture.Exclusive(pinch, pan)}><View style={styles.viewport}>{children(window)}</View></GestureDetector></View>;
}

const styles = StyleSheet.create({
  controls: { minHeight: 36, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 },
  hint: { color: "#6E8775", fontSize: 8, fontWeight: "900", letterSpacing: 0.45 },
  range: { color: "#087A50", fontSize: 9, fontWeight: "900", marginTop: 2 },
  reset: { minHeight: 27, borderRadius: 8, paddingHorizontal: 9, alignItems: "center", justifyContent: "center", backgroundColor: "#E8F6EB", borderWidth: 1, borderColor: "#C8E5CE" },
  resetMuted: { opacity: 0.55 },
  resetText: { color: "#087A50", fontSize: 9, fontWeight: "900" },
  viewport: { overflow: "hidden", borderRadius: 12 },
});
