import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import Svg, { Circle, Path, Polygon } from "react-native-svg";

import { CHRYSALIS_THRESHOLD, type FocusGrowthState, type GardenButterfly, type GardenProgress, type HiveCluster } from "@/lib/focusforge-growth";

export type GrowthBoardSelection =
  | { kind: "butterfly"; entry: GardenButterfly }
  | { kind: "gardenProgress"; entry: GardenProgress }
  | { kind: "hive"; entry: HiveCluster };

export function GardenBoard({ growth, onSelect }: { growth: FocusGrowthState; onSelect: (selection: GrowthBoardSelection) => void }) {
  return <View style={styles.board}>
    <View style={styles.boardHeader}><View><Text style={styles.boardTitle}>Garden Board</Text><Text style={styles.boardSubtitle}>Five completed Garden sessions for one subject create a permanent butterfly.</Text></View><Text style={styles.boardCount}>{growth.butterflies.length} WINGS</Text></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
      {growth.butterflies.map((entry) => <Pressable key={entry.id} onPress={() => onSelect({ kind: "butterfly", entry })} style={({ pressed }) => [styles.gardenTile, pressed && styles.pressed]}><StaticButterfly /><Text style={styles.tileTitle}>{entry.subjectTag}</Text><Text style={styles.tileMeta}>{entry.contributionIds.length} sessions · emerged</Text></Pressable>)}
      {growth.garden.map((entry) => <Pressable key={entry.subjectTag} onPress={() => onSelect({ kind: "gardenProgress", entry })} style={({ pressed }) => [styles.gardenTile, styles.chrysalisTile, pressed && styles.pressed]}><StaticChrysalis progress={entry.completedSessionsTowardChrysalis} /><Text style={styles.tileTitle}>{entry.subjectTag}</Text><Text style={styles.tileMeta}>{entry.completedSessionsTowardChrysalis}/{CHRYSALIS_THRESHOLD} toward wings</Text></Pressable>)}
      {!growth.butterflies.length && !growth.garden.length ? <View style={styles.emptyTile}><StaticLeaf /><Text style={styles.emptyTitle}>Your garden is waiting.</Text><Text style={styles.emptyDetail}>A Butterfly theme completion begins a subject’s chrysalis progress.</Text></View> : null}
    </ScrollView>
  </View>;
}

export function HiveBoard({ growth, onSelect }: { growth: FocusGrowthState; onSelect: (selection: GrowthBoardSelection) => void }) {
  return <View style={styles.board}>
    <View style={styles.boardHeader}><View><Text style={styles.boardTitle}>Hive Board</Text><Text style={styles.boardSubtitle}>Every Hive session keeps its earned cells, including partial work.</Text></View><Text style={[styles.boardCount, styles.hiveCount]}>{growth.hive.length} CLUSTERS</Text></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
      {growth.hive.map((entry) => <Pressable key={entry.id} onPress={() => onSelect({ kind: "hive", entry })} style={({ pressed }) => [styles.hiveTile, pressed && styles.pressed]}><StaticHive cluster={entry} /><Text style={styles.tileTitle}>{entry.subjectTag}</Text><Text style={styles.tileMeta}>{entry.roundsCompleted}/{entry.roundsPlanned} rounds · {entry.status}</Text></Pressable>)}
      {!growth.hive.length ? <View style={[styles.emptyTile, styles.emptyHive]}><StaticHoneyCell fill={0} left={47} top={17} /><Text style={styles.emptyTitle}>Your hive is quiet.</Text><Text style={styles.emptyDetail}>A Hive session adds a permanent cluster to this board.</Text></View> : null}
    </ScrollView>
  </View>;
}

function StaticButterfly() {
  return <View style={styles.art}><Svg width="96" height="68" viewBox="0 0 96 68"><Path d="M45 35 C22 10, 6 10, 9 33 C11 52, 31 54, 44 41" fill="#5A9FDD" stroke="#2C6CA5" strokeWidth="2" /><Path d="M51 35 C74 10, 90 10, 87 33 C85 52, 65 54, 52 41" fill="#A775CB" stroke="#75469F" strokeWidth="2" /><Path d="M45 38 C27 47, 23 62, 39 61 C47 60, 49 49, 48 42" fill="#F0C65F" stroke="#B48525" strokeWidth="2" /><Path d="M51 38 C69 47, 73 62, 57 61 C49 60, 47 49, 48 42" fill="#E37F84" stroke="#A8454F" strokeWidth="2" /><Path d="M46 25 Q48 17 50 25 L51 49 Q48 56 45 49 Z" fill="#38523E" /><Circle cx="48" cy="20" r="4" fill="#38523E" /></Svg></View>;
}

function StaticChrysalis({ progress }: { progress: number }) {
  return <View style={styles.art}><View style={styles.chrysalisThread} /><View style={styles.chrysalisShell}>{Array.from({ length: progress }, (_, index) => <View key={index} style={[styles.chrysalisBand, { top: 8 + index * 9 }]} />)}</View><View style={styles.chrysalisTrack}>{Array.from({ length: CHRYSALIS_THRESHOLD }, (_, index) => <View key={index} style={[styles.progressDot, index < progress && styles.progressDotActive]} />)}</View></View>;
}

function StaticLeaf() {
  return <View style={styles.art}><Svg width="96" height="68" viewBox="0 0 96 68"><Path d="M12 51 C23 7, 70 5, 88 23 C72 58, 37 63, 12 51 Z" fill="#63A973" /><Path d="M18 51 C42 39, 59 30, 84 23" fill="none" stroke="#D5E9B4" strokeWidth="2" /></Svg></View>;
}

function StaticHive({ cluster }: { cluster: HiveCluster }) {
  return <View style={styles.hiveArt}>{cluster.cells.map((cell, index) => <StaticHoneyCell key={index} fill={cell.fillPercent} left={[33, 7, 59, 33][index] ?? 33} top={[3, 31, 31, 59][index] ?? 3} />)}</View>;
}

function StaticHoneyCell({ fill, left, top }: { fill: 0 | 40 | 100; left: number; top: number }) {
  return <View style={[styles.staticCell, { left, top }]}><Svg width="42" height="47" viewBox="0 0 42 47"><Polygon points="21,2 39,12 39,33 21,43 3,33 3,12" fill="#FBE8AF" stroke="#B98235" strokeWidth="2" />{fill ? <Polygon points="21,7 35,15 35,32 21,39 7,32 7,15" fill="#D69836" opacity={fill === 100 ? 0.92 : 0.42} /> : null}{fill === 100 ? <Path d="M12 17 Q21 11 30 16" fill="none" stroke="#FFF6C6" strokeWidth="2.5" strokeLinecap="round" /> : null}</Svg></View>;
}

const styles = StyleSheet.create({
  board: { borderRadius: 17, padding: 14, backgroundColor: "#FCFFFC", borderWidth: 1, borderColor: "#D3E7D7", marginTop: 10 }, boardHeader: { flexDirection: "row", justifyContent: "space-between", gap: 10 }, boardTitle: { color: "#173423", fontSize: 15, fontWeight: "900" }, boardSubtitle: { color: "#63796B", fontSize: 10, lineHeight: 14, marginTop: 3, maxWidth: 235 }, boardCount: { alignSelf: "flex-start", color: "#087A50", fontSize: 8, fontWeight: "900", letterSpacing: 0.75, backgroundColor: "#EAF7EC", borderRadius: 8, paddingHorizontal: 7, paddingVertical: 5 }, hiveCount: { color: "#9E6815", backgroundColor: "#FFF2CE" }, row: { gap: 9, paddingTop: 13, paddingRight: 12 }, gardenTile: { width: 126, borderRadius: 13, padding: 8, backgroundColor: "#F5FBF1", borderWidth: 1, borderColor: "#D7E9CF" }, chrysalisTile: { backgroundColor: "#F8F8ED" }, hiveTile: { width: 126, borderRadius: 13, padding: 8, backgroundColor: "#FFF9EA", borderWidth: 1, borderColor: "#F0D99B" }, pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] }, art: { height: 73, borderRadius: 10, backgroundColor: "#E9F5E5", alignItems: "center", justifyContent: "center", overflow: "hidden" }, hiveArt: { height: 73, borderRadius: 10, backgroundColor: "#FFF1C8", position: "relative", overflow: "hidden" }, tileTitle: { color: "#173423", fontSize: 10, fontWeight: "900", marginTop: 7 }, tileMeta: { color: "#63796B", fontSize: 8, lineHeight: 12, marginTop: 2 }, emptyTile: { width: 202, minHeight: 128, borderRadius: 13, padding: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#F5FBF1", borderWidth: 1, borderStyle: "dashed", borderColor: "#C8E2CC" }, emptyHive: { backgroundColor: "#FFF9EA", borderColor: "#EBCD7B", position: "relative", overflow: "hidden" }, emptyTitle: { color: "#173423", fontSize: 11, fontWeight: "900", marginTop: 3 }, emptyDetail: { color: "#63796B", fontSize: 9, lineHeight: 13, textAlign: "center", marginTop: 3 }, chrysalisThread: { position: "absolute", top: 3, width: 1, height: 19, backgroundColor: "#6F8B6F" }, chrysalisShell: { width: 29, height: 41, borderRadius: 17, marginTop: 12, backgroundColor: "#79A35F", borderWidth: 2, borderColor: "#547B45", overflow: "hidden" }, chrysalisBand: { position: "absolute", left: 4, right: 4, height: 3, borderRadius: 2, backgroundColor: "#CFE59B", opacity: 0.85 }, chrysalisTrack: { flexDirection: "row", gap: 3, marginTop: 6 }, progressDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: "#D6E4D2" }, progressDotActive: { backgroundColor: "#9EBD55" }, staticCell: { position: "absolute", width: 42, height: 47 },
});
