import { Text, View, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";

type FocusRingProps = {
  progress: number;
  time: string;
  phase: "focus" | "reset" | "paused" | "ready";
};

const RADIUS = 118;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function FocusRing({ progress, time, phase }: FocusRingProps) {
  const accent = phase === "reset" ? "#AE7418" : phase === "paused" ? "#668070" : "#087A50";
  const label = phase === "focus" ? "FOCUS" : phase === "reset" ? "REST" : phase === "paused" ? "PAUSED" : "READY";
  const subtitle = phase === "ready"
    ? "Four focused rounds, then rest."
    : phase === "reset"
      ? "Three chimes marked the rest round."
      : "One round at a time.";
  const dashOffset = CIRCUMFERENCE * (1 - Math.max(0, Math.min(1, progress)));

  return (
    <View style={styles.shell}>
      <Svg width={272} height={272} viewBox="0 0 272 272" style={StyleSheet.absoluteFill}>
        <Circle cx="136" cy="136" r={RADIUS} stroke="#D7E9DA" strokeWidth="11" fill="none" />
        <Circle
          cx="136"
          cy="136"
          r={RADIUS}
          stroke={accent}
          strokeWidth="11"
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${CIRCUMFERENCE} ${CIRCUMFERENCE}`}
          strokeDashoffset={dashOffset}
          transform="rotate(-90 136 136)"
        />
      </Svg>
      <View style={styles.content}>
        <Text style={[styles.phase, { color: accent }]}>{label}</Text>
        <Text style={styles.time}>{time}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  shell: { width: 272, height: 272, alignSelf: "center", alignItems: "center", justifyContent: "center" },
  content: { alignItems: "center", justifyContent: "center", paddingHorizontal: 32 },
  phase: { fontSize: 12, fontWeight: "800", letterSpacing: 2.4, marginBottom: 7 },
  time: { color: "#173423", fontSize: 54, lineHeight: 62, fontWeight: "800", fontVariant: ["tabular-nums"] },
  subtitle: { color: "#63796B", fontSize: 13, lineHeight: 18, textAlign: "center", marginTop: 8 },
});
