import type { ReactNode } from "react";
import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export function SectionLabel({ children }: { children: ReactNode }) {
  return <Text style={styles.sectionLabel}>{children}</Text>;
}

export function Surface({ children, style }: { children: ReactNode; style?: object }) {
  return <View style={[styles.surface, style]}>{children}</View>;
}

export function IconCircle({ icon, color = "#087A50", onPress }: { icon: keyof typeof MaterialIcons.glyphMap; color?: string; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.iconCircle, pressed && { opacity: 0.72, transform: [{ scale: 0.96 }] }]}>
      <MaterialIcons name={icon} size={20} color={color} />
    </Pressable>
  );
}

export function SettingToggle({ icon, title, detail, value, onValueChange, tone = "#087A50" }: {
  icon: keyof typeof MaterialIcons.glyphMap;
  title: string;
  detail: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  tone?: string;
}) {
  return (
    <View style={styles.toggleRow}>
      <View style={[styles.settingIcon, { backgroundColor: `${tone}22` }]}><MaterialIcons name={icon} size={20} color={tone} /></View>
      <View style={styles.toggleCopy}><Text style={styles.rowTitle}>{title}</Text><Text style={styles.rowDetail}>{detail}</Text></View>
      <Switch value={value} onValueChange={onValueChange} trackColor={{ false: "#C6D8CA", true: tone }} thumbColor="#FFFFFF" />
    </View>
  );
}

export function Stepper({ value, suffix, decrement, increment, min, max }: { value: number; suffix: string; decrement: () => void; increment: () => void; min: number; max: number }) {
  return (
    <View style={styles.stepper}>
      <Pressable disabled={value <= min} onPress={decrement} style={({ pressed }) => [styles.stepperButton, (pressed || value <= min) && { opacity: value <= min ? 0.35 : 0.68 }]}><MaterialIcons name="remove" size={20} color="#156443" /></Pressable>
      <Text style={styles.stepperValue}>{value}<Text style={styles.stepperSuffix}> {suffix}</Text></Text>
      <Pressable disabled={value >= max} onPress={increment} style={({ pressed }) => [styles.stepperButton, (pressed || value >= max) && { opacity: value >= max ? 0.35 : 0.68 }]}><MaterialIcons name="add" size={20} color="#156443" /></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  surface: { borderRadius: 24, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D6E7DA", overflow: "hidden", shadowColor: "#087A50", shadowOpacity: 0.055, shadowRadius: 16, shadowOffset: { width: 0, height: 7 }, elevation: 2 },
  sectionLabel: { color: "#087A50", fontSize: 11, lineHeight: 15, fontWeight: "900", letterSpacing: 1.5, marginBottom: 9, marginLeft: 4 },
  iconCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: "#F0F8F2", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#C7DFC9" },
  toggleRow: { minHeight: 78, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", gap: 12 },
  settingIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  toggleCopy: { flex: 1, paddingRight: 6 },
  rowTitle: { color: "#163222", fontSize: 15, fontWeight: "800", lineHeight: 20 },
  rowDetail: { color: "#63796B", fontSize: 12, lineHeight: 17, marginTop: 2 },
  stepper: { flexDirection: "row", alignItems: "center", backgroundColor: "#F1F8F2", borderRadius: 14, borderWidth: 1, borderColor: "#C7DFC9", overflow: "hidden" },
  stepperButton: { width: 38, height: 36, alignItems: "center", justifyContent: "center" },
  stepperValue: { minWidth: 74, textAlign: "center", color: "#156443", fontSize: 14, fontWeight: "900", fontVariant: ["tabular-nums"] },
  stepperSuffix: { color: "#6B8573", fontSize: 11, fontWeight: "800" },
});
