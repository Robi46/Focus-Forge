import type { ActiveSession } from "@/lib/focusforge-core";

export const FOCUS_CHANNEL_ID = "focusforge-focus-cues";
export const CHECKPOINT_CHANNEL_ID = "focusforge-checkpoint-cues";

export async function configureCueChannels() {
  return true;
}

export async function getCuePermission() {
  return "granted" as const;
}

export async function requestCuePermission() {
  return "granted" as const;
}

export async function cancelFocusCueSchedule() {
  return;
}

export async function scheduleFocusCues(_session: ActiveSession, _horizonHours = 24) {
  return [] as string[];
}
