import { requireOptionalNativeModule } from "expo-modules-core";

type SessionBubbleNativeModule = {
  canDrawOverlays(): boolean;
  openOverlayPermissionSettings(): Promise<boolean>;
  showSessionBubble(startedAtMs: number, accumulatedPausedMs: number, roundMinutes: number, roundsPerCycle: number, restSeconds: number): Promise<boolean>;
  hideSessionBubble(): Promise<boolean>;
};

const nativeModule = requireOptionalNativeModule<SessionBubbleNativeModule>("FocusForgeSessionBubble");

export function isSessionBubbleSupported() {
  return Boolean(nativeModule);
}

export function canDrawOverlays() {
  return nativeModule?.canDrawOverlays() ?? false;
}

export async function openOverlayPermissionSettings() {
  return (await nativeModule?.openOverlayPermissionSettings()) ?? false;
}

export async function showSessionBubble(startedAtMs: number, accumulatedPausedMs: number, roundMinutes: number, roundsPerCycle: number, restSeconds: number) {
  return (await nativeModule?.showSessionBubble(startedAtMs, accumulatedPausedMs, roundMinutes, roundsPerCycle, restSeconds)) ?? false;
}

export async function hideSessionBubble() {
  return (await nativeModule?.hideSessionBubble()) ?? false;
}
