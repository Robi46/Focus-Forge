import { describe, expect, it } from "vitest";
import { DEFAULT_SESSION_PLAN, getFocusedSeconds, getSessionSnapshot, normalizeSettings, restoreActiveSession, type ActiveSession } from "../lib/focusforge-core";

const session: ActiveSession = {
  id: "test",
  startedAtMs: 0,
  accumulatedPausedMs: 0,
  notificationIds: [],
  plan: { roundMinutes: 5, roundsPerCycle: 4, restSeconds: 120 },
};

describe("FocusForge four-round timer rhythm", () => {
  it("starts a five-minute first round and plans its single beep at the round end", () => {
    const state = getSessionSnapshot(session, 0);
    expect(state.phase).toBe("focus");
    expect(state.roundNumber).toBe(1);
    expect(state.remainingSeconds).toBe(300);
    expect(state.nextCueSeconds).toBe(300);
  });

  it("begins each following study round immediately after a one-beep round end", () => {
    const secondRound = getSessionSnapshot(session, 300_000);
    const thirdRound = getSessionSnapshot(session, 600_000);
    const fourthRound = getSessionSnapshot(session, 900_000);
    expect(secondRound.phase).toBe("focus");
    expect(secondRound.roundNumber).toBe(2);
    expect(secondRound.roundsCompleted).toBe(1);
    expect(secondRound.remainingSeconds).toBe(300);
    expect(thirdRound.roundNumber).toBe(3);
    expect(thirdRound.roundsCompleted).toBe(2);
    expect(fourthRound.roundNumber).toBe(4);
    expect(fourthRound.roundsCompleted).toBe(3);
  });

  it("enters the two-minute rest only after the fourth five-minute round", () => {
    const state = getSessionSnapshot(session, 1_200_000);
    expect(state.phase).toBe("reset");
    expect(state.remainingSeconds).toBe(120);
    expect(state.roundsCompleted).toBe(4);
    expect(state.completedBlocks).toBe(1);
  });

  it("starts a new first round after the two-minute rest and counts study time only", () => {
    const state = getSessionSnapshot(session, 1_320_000);
    expect(state.phase).toBe("focus");
    expect(state.roundNumber).toBe(1);
    expect(state.completedBlocks).toBe(1);
    expect(state.remainingSeconds).toBe(300);
    expect(getFocusedSeconds(session, 1_380_000)).toBe(1_260);
  });

  it("retains total completed-round progress across ordinary rests for long visual journeys", () => {
    const twentySixthRoundBoundary = 6 * 1_320_000 + 2 * 300_000;
    const state = getSessionSnapshot(session, twentySixthRoundBoundary);
    expect(state.phase).toBe("focus");
    expect(state.roundsCompleted).toBe(26);
    expect(state.completedBlocks).toBe(6);
  });

  it("holds the exact active round when paused", () => {
    const paused = { ...session, pausedAtMs: 450_000 };
    const state = getSessionSnapshot(paused, 900_000);
    expect(state.phase).toBe("paused");
    expect(state.roundNumber).toBe(2);
    expect(state.remainingSeconds).toBe(150);
  });

  it("keeps the clarified four-by-five-minute rhythm as the default when no custom plan is saved", () => {
    const settings = normalizeSettings({});
    expect(settings.roundMinutes).toBe(DEFAULT_SESSION_PLAN.roundMinutes);
    expect(settings.roundsPerCycle).toBe(DEFAULT_SESSION_PLAN.roundsPerCycle);
    expect(settings.restSeconds).toBe(DEFAULT_SESSION_PLAN.restSeconds);
    expect(settings.weeklyGoalMinutes).toBe(300);
    expect(settings.subjectTag).toBe("General study");
  });

  it("keeps a trimmed subject tag and valid weekly focus goal for future sessions", () => {
    const settings = normalizeSettings({ subjectTag: "  Calculus   II ", weeklyGoalMinutes: 420, customSubjects: ["Physics", " physics ", "History"] });
    expect(settings.subjectTag).toBe("Calculus II");
    expect(settings.weeklyGoalMinutes).toBe(420);
    expect(settings.customSubjects).toEqual(["Physics", "History"]);
  });

  it("persists valid locked-screen sound and floating-bubble preferences while safely repairing invalid values", () => {
    const selected = normalizeSettings({ lockedScreenCueSound: "calm", floatingSessionBubbleEnabled: false });
    expect(selected.lockedScreenCueSound).toBe("calm");
    expect(selected.floatingSessionBubbleEnabled).toBe(false);
    expect(normalizeSettings({ lockedScreenCueSound: "unsupported" as never }).lockedScreenCueSound).toBe("classic");
  });

  it("restores a drawn focus-world theme while safely assigning the migration fallback to older sessions", () => {
    expect(restoreActiveSession({ ...session, growthTheme: "hive" })?.growthTheme).toBe("hive");
    expect(restoreActiveSession(session)?.growthTheme).toBe("butterfly");
  });

  it("restores a persisted visual-cycle offset and defaults older sessions to the first visual story", () => {
    expect(restoreActiveSession({ ...session, growthJourneyStartedAtRounds: 28, growthJourneyIndex: 1 })).toEqual(expect.objectContaining({ growthJourneyStartedAtRounds: 28, growthJourneyIndex: 1 }));
    expect(restoreActiveSession(session)).toEqual(expect.objectContaining({ growthJourneyStartedAtRounds: 0, growthJourneyIndex: 0 }));
  });

  it("preserves a valid custom rhythm for the next session", () => {
    const settings = normalizeSettings({ roundMinutes: 30, roundsPerCycle: 2, restSeconds: 60 });
    expect(settings.roundMinutes).toBe(30);
    expect(settings.roundsPerCycle).toBe(2);
    expect(settings.restSeconds).toBe(60);
  });

  it("runs a saved custom two-round rhythm before its configured rest", () => {
    const customSession: ActiveSession = { ...session, plan: { roundMinutes: 30, roundsPerCycle: 2, restSeconds: 60 } };
    expect(getSessionSnapshot(customSession, 1_800_000).roundNumber).toBe(2);
    const rest = getSessionSnapshot(customSession, 3_600_000);
    expect(rest.phase).toBe("reset");
    expect(rest.remainingSeconds).toBe(60);
  });
});
