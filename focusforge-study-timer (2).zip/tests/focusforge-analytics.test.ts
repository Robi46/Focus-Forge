import { describe, expect, it } from "vitest";
import { getDayAnalytics, getFocusQuality, getSevenDayAnalytics, getSubjectAnalytics, getTodayEventTimeline, getTodaySubjectAnalytics, getTodayTimeline } from "../lib/focusforge-analytics";
import type { SessionRecord } from "../lib/focusforge-core";

const now = new Date(2026, 7, 23, 16, 0, 0).getTime();
const todayMorning = new Date(2026, 7, 23, 9, 0, 0).getTime();
const yesterday = new Date(2026, 7, 22, 13, 0, 0).getTime();

const records: SessionRecord[] = [
  { id: "today", startedAtMs: todayMorning, endedAtMs: todayMorning + 1_800_000, focusedSeconds: 1_500, completedBlocks: 1, pauseCount: 2, interruptionCount: 1, totalPausedSeconds: 90 },
  { id: "yesterday", startedAtMs: yesterday, endedAtMs: yesterday + 900_000, focusedSeconds: 600, completedBlocks: 0, pauseCount: 1, interruptionCount: 0 },
];

describe("FocusForge history analytics", () => {
  it("summarises today’s real focused time, cycles, pauses, and interruptions", () => {
    const summary = getDayAnalytics(records, now);
    expect(summary.focusedSeconds).toBe(1_500);
    expect(summary.sessions).toBe(1);
    expect(summary.cycles).toBe(1);
    expect(summary.pauses).toBe(2);
    expect(summary.interruptions).toBe(1);
    expect(summary.pausedSeconds).toBe(90);
  });

  it("creates seven chronological day buckets without fabricating focus time", () => {
    const days = getSevenDayAnalytics(records, now);
    expect(days).toHaveLength(7);
    expect(days[6].focusedSeconds).toBe(1_500);
    expect(days[5].focusedSeconds).toBe(600);
    expect(days.slice(0, 5).every((day) => day.focusedSeconds === 0)).toBe(true);
  });

  it("counts only session goals marked completed in the correct seven-day bucket", () => {
    const goalRecords = [
      { ...records[0], id: "completed-today-1", goal: "Solve problems", goalOutcome: "completed" as const },
      { ...records[0], id: "completed-today-2", goal: "Review notes", goalOutcome: "completed" as const, endedAtMs: todayMorning + 3_600_000 },
      { ...records[1], id: "partial-yesterday", goal: "Read chapter", goalOutcome: "partial" as const },
    ];
    const days = getSevenDayAnalytics(goalRecords, now);
    expect(days[6].completedGoals).toBe(2);
    expect(days[5].completedGoals).toBe(0);
    expect(days.slice(0, 5).every((day) => day.completedGoals === 0)).toBe(true);
  });

  it("positions only today’s sessions on the daily timeline", () => {
    const timeline = getTodayTimeline(records, now);
    expect(timeline).toHaveLength(1);
    expect(timeline[0].id).toBe("today");
    expect(timeline[0].leftPercent).toBeGreaterThan(30);
  });

  it("scores real interruptions more heavily than pauses and gives targeted advice", () => {
    const quality = getFocusQuality(getDayAnalytics(records, now));
    expect(quality.score).toBeLessThan(80);
    expect(quality.adviceTitle).toContain("app exits");
  });

  it("does not fabricate a score or advice from days without sessions", () => {
    const quality = getFocusQuality(getDayAnalytics([], now));
    expect(quality.score).toBeNull();
    expect(quality.level).toBe("Needs a start");
  });

  it("groups the saved seven-day history by subject without fabricating categories", () => {
    const tagged = [
      { ...records[0], id: "math", subjectTag: "Mathematics", focusedSeconds: 1_500 },
      { ...records[0], id: "science", subjectTag: "Science", focusedSeconds: 900, endedAtMs: todayMorning + 3_600_000 },
      { ...records[1], id: "outside-window", subjectTag: "Reading", endedAtMs: todayMorning - 9 * 86_400_000 },
    ];
    const subjects = getSubjectAnalytics(tagged, todayMorning - 6 * 86_400_000);
    expect(subjects.map((subject) => subject.subjectTag)).toEqual(["Mathematics", "Science"]);
    expect(subjects[0].focusedSeconds).toBe(1_500);
    expect(subjects[1].focusedSeconds).toBe(900);
  });

  it("separates today’s subject distribution from older saved subject time", () => {
    const tagged = [
      { ...records[0], id: "physics-today", subjectTag: "Physics", focusedSeconds: 1_500 },
      { ...records[0], id: "history-today", subjectTag: "History", focusedSeconds: 600, endedAtMs: todayMorning + 3_600_000 },
      { ...records[1], id: "physics-yesterday", subjectTag: "Physics", focusedSeconds: 900 },
    ];
    const todaySubjects = getTodaySubjectAnalytics(tagged, now);
    const weekSubjects = getSubjectAnalytics(tagged, todayMorning - 6 * 86_400_000);
    expect(todaySubjects).toEqual(expect.arrayContaining([
      expect.objectContaining({ subjectTag: "Physics", focusedSeconds: 1_500 }),
      expect.objectContaining({ subjectTag: "History", focusedSeconds: 600 }),
    ]));
    expect(weekSubjects.find((subject) => subject.subjectTag === "Physics")?.focusedSeconds).toBe(2_400);
  });

  it("plots timestamped pauses, app leaves, and returns at their real event times with cumulative counts", () => {
    const eventful = [{
      ...records[0],
      eventTimeline: [
        { type: "pause" as const, atMs: todayMorning + 300_000 },
        { type: "appLeave" as const, atMs: todayMorning + 600_000 },
        { type: "interruption" as const, atMs: todayMorning + 900_000 },
        { type: "pause" as const, atMs: todayMorning + 1_200_000 },
      ],
    }];
    const timeline = getTodayEventTimeline(eventful, now);
    expect(timeline.map((point) => point.type)).toEqual(["pause", "appLeave", "interruption", "pause"]);
    expect(timeline.map((point) => point.cumulativeCount)).toEqual([1, 1, 1, 2]);
    expect(timeline.map((point) => point.atMs)).toEqual([todayMorning + 300_000, todayMorning + 600_000, todayMorning + 900_000, todayMorning + 1_200_000]);
  });
});
