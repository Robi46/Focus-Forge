export type ReplayableCuePlayer = {
  isLoaded: boolean;
  volume: number;
  pause: () => void;
  seekTo: (seconds: number) => Promise<void>;
  play: () => void;
};

export async function replayCue(
  player: ReplayableCuePlayer,
  count: 1 | 3,
  wait: (milliseconds: number) => Promise<void>,
) {
  if (!player.isLoaded) return false;

  player.volume = 1;
  for (let index = 0; index < count; index += 1) {
    player.pause();
    await player.seekTo(0);
    player.play();
    if (index < count - 1) await wait(520);
  }
  return true;
}
