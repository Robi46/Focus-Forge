import type { ActiveSession } from "@/lib/focusforge-core";
import { createSessionBubblePayload } from "@/lib/session-bubble-core";
import {
  canDrawOverlays,
  hideSessionBubble,
  isSessionBubbleSupported,
  openOverlayPermissionSettings,
  showSessionBubble,
} from "@/modules/session-bubble";

export { canDrawOverlays, hideSessionBubble, isSessionBubbleSupported, openOverlayPermissionSettings };

export async function showBubbleForSession(session: ActiveSession) {
  const payload = createSessionBubblePayload(session);
  return showSessionBubble(
    payload.startedAtMs,
    payload.accumulatedPausedMs,
    payload.roundMinutes,
    payload.roundsPerCycle,
    payload.restSeconds,
  );
}
