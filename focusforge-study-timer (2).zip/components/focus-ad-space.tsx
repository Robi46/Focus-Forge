// Metro resolves .native/.web before this file at runtime. This base export only
// gives TypeScript a safe fallback and must never force-load the native Ads SDK.
export { FocusAdSpace } from "./focus-ad-space.web";
