import { describe, expect, it } from "vitest";

import { getCompletedRoundCueEvents, getCycleCueEvents } from "../lib/cue-events";

describe("study cycle cue events", () => {
  it("emits one beep for rounds one through three and three beeps for round four", () => {
    expect(getCompletedRoundCueEvents(0, 1, 4)).toEqual([1]);
    expect(getCompletedRoundCueEvents(1, 2, 4)).toEqual([1]);
    expect(getCompletedRoundCueEvents(2, 3, 4)).toEqual([1]);
    expect(getCompletedRoundCueEvents(3, 4, 4)).toEqual([3]);
  });

  it("repeats the exact cue rhythm in the second study/rest cycle", () => {
    expect(getCompletedRoundCueEvents(4, 8, 4)).toEqual([1, 1, 1, 3]);
  });

  it("does not replay a cue when the completed-round count is unchanged", () => {
    expect(getCompletedRoundCueEvents(4, 4, 4)).toEqual([]);
  });

  it("emits one start cue only when rest completes into the next first round", () => {
    expect(getCycleCueEvents(4, 4, 4, "reset", "focus", 1)).toEqual([1]);
    expect(getCycleCueEvents(4, 5, 4, "focus", "focus", 2)).toEqual([1]);
    expect(getCycleCueEvents(4, 4, 4, "reset", "focus", 2)).toEqual([]);
  });
});
