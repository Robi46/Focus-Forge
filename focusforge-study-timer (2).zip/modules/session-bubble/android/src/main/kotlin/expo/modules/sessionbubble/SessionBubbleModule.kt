package expo.modules.sessionbubble

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import expo.modules.kotlin.functions.Queues
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import kotlin.math.floor
import kotlin.math.max

class SessionBubbleModule : Module() {
  private data class SessionSpec(
    val startedAtMs: Long,
    val accumulatedPausedMs: Long,
    val roundMinutes: Int,
    val roundsPerCycle: Int,
    val restSeconds: Int,
  )

  private val handler = Handler(Looper.getMainLooper())
  private var bubble: LinearLayout? = null
  private var counterText: TextView? = null
  private var sessionSpec: SessionSpec? = null
  private var windowManager: WindowManager? = null
  private val ticker = object : Runnable {
    override fun run() {
      updateCounter()
      if (bubble != null) handler.postDelayed(this, 1_000)
    }
  }

  override fun definition() = ModuleDefinition {
    Name("FocusForgeSessionBubble")

    Function("canDrawOverlays") {
      val context = appContext.reactContext ?: return@Function false
      return@Function Settings.canDrawOverlays(context)
    }

    AsyncFunction("openOverlayPermissionSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      try {
        val intent = Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:${context.packageName}"),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
      } catch (_: Exception) {
        false
      }
    }.runOnQueue(Queues.MAIN)

    AsyncFunction("showSessionBubble") { startedAtMs: Double, accumulatedPausedMs: Double, roundMinutes: Int, roundsPerCycle: Int, restSeconds: Int ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      if (!Settings.canDrawOverlays(context)) return@AsyncFunction false
      sessionSpec = SessionSpec(
        startedAtMs = startedAtMs.toLong(),
        accumulatedPausedMs = accumulatedPausedMs.toLong(),
        roundMinutes = max(1, roundMinutes),
        roundsPerCycle = max(1, roundsPerCycle),
        restSeconds = max(1, restSeconds),
      )
      if (bubble == null) createBubble(context)
      updateCounter()
      handler.removeCallbacks(ticker)
      handler.post(ticker)
      true
    }.runOnQueue(Queues.MAIN)

    AsyncFunction("hideSessionBubble") {
      removeBubble()
      true
    }.runOnQueue(Queues.MAIN)
  }

  private fun createBubble(context: Context) {
    val manager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    windowManager = manager

    val root = LinearLayout(context).apply {
      orientation = LinearLayout.HORIZONTAL
      gravity = Gravity.CENTER_VERTICAL
      setPadding(dp(context, 10), dp(context, 6), dp(context, 5), dp(context, 6))
      background = roundedBackground(context, "#102D1B", 24, "#3A895B")
      elevation = dp(context, 8).toFloat()
      contentDescription = "FocusForge active session bubble"
      isClickable = true
      isFocusable = false
    }

    val counter = TextView(context).apply {
      setTextColor(Color.WHITE)
      textSize = 12f
      typeface = android.graphics.Typeface.DEFAULT_BOLD
      minWidth = dp(context, 95)
      gravity = Gravity.CENTER_VERTICAL
      setOnClickListener { openFocusForge(context) }
    }
    counterText = counter

    val open = TextView(context).apply {
      text = "↗"
      setTextColor(Color.parseColor("#9BE6B5"))
      textSize = 20f
      gravity = Gravity.CENTER
      contentDescription = "Open FocusForge dashboard"
      setPadding(dp(context, 5), 0, dp(context, 5), 0)
      setOnClickListener { openFocusForge(context) }
    }

    val close = TextView(context).apply {
      text = "×"
      setTextColor(Color.parseColor("#D9EEE0"))
      textSize = 21f
      gravity = Gravity.CENTER
      contentDescription = "Dismiss session bubble"
      setPadding(dp(context, 5), 0, dp(context, 4), 0)
      setOnClickListener { removeBubble() }
    }

    root.addView(counter, LinearLayout.LayoutParams(0, dp(context, 34), 1f))
    root.addView(open, LinearLayout.LayoutParams(dp(context, 30), dp(context, 34)))
    root.addView(close, LinearLayout.LayoutParams(dp(context, 27), dp(context, 34)))

    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    }
    val layoutParams = WindowManager.LayoutParams(
      dp(context, 172),
      dp(context, 48),
      type,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
      android.graphics.PixelFormat.TRANSLUCENT,
    ).apply {
      gravity = Gravity.TOP or Gravity.END
      x = dp(context, 10)
      y = dp(context, 116)
    }

    try {
      manager.addView(root, layoutParams)
      bubble = root
    } catch (_: Exception) {
      bubble = null
      counterText = null
    }
  }

  private fun removeBubble() {
    handler.removeCallbacks(ticker)
    val view = bubble
    val manager = windowManager
    if (view != null && manager != null) {
      try {
        manager.removeView(view)
      } catch (_: Exception) {
        // The system may have already detached this user-dismissible overlay.
      }
    }
    bubble = null
    counterText = null
    windowManager = null
  }

  private fun updateCounter() {
    val spec = sessionSpec ?: return
    val activeMs = max(0L, System.currentTimeMillis() - spec.startedAtMs - spec.accumulatedPausedMs)
    val roundMs = spec.roundMinutes * 60_000L
    val focusMs = roundMs * spec.roundsPerCycle
    val restMs = spec.restSeconds * 1_000L
    val cycleMs = focusMs + restMs
    val inCycleMs = if (cycleMs > 0) activeMs % cycleMs else 0L
    val label = if (inCycleMs < focusMs) {
      val roundNumber = floor(inCycleMs.toDouble() / roundMs).toInt() + 1
      "R$roundNumber  ${formatTime(roundMs - (inCycleMs % roundMs))}"
    } else {
      "REST  ${formatTime(cycleMs - inCycleMs)}"
    }
    counterText?.text = label
  }

  private fun openFocusForge(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
      ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    if (launchIntent != null) context.startActivity(launchIntent)
  }

  private fun formatTime(milliseconds: Long): String {
    val totalSeconds = max(0L, milliseconds / 1_000L)
    return String.format("%02d:%02d", totalSeconds / 60L, totalSeconds % 60L)
  }

  private fun roundedBackground(context: Context, fill: String, radiusDp: Int, stroke: String): GradientDrawable {
    return GradientDrawable().apply {
      setColor(Color.parseColor(fill))
      cornerRadius = radiusDp.toFloat() * context.resources.displayMetrics.density
      setStroke(context.resources.displayMetrics.density.toInt(), Color.parseColor(stroke))
    }
  }

  private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
