export type TimeWindow = { startHour: number; endHour: number };

export const FULL_DAY_WINDOW: TimeWindow = { startHour: 0, endHour: 24 };

export function clampTimeWindow(startHour: number, spanHours: number): TimeWindow {
  const span = Math.max(0.25, Math.min(24, spanHours));
  const start = Math.max(0, Math.min(24 - span, startHour));
  return { startHour: start, endHour: start + span };
}

export function zoomTimeWindow(window: TimeWindow, scale: number): TimeWindow {
  const span = window.endHour - window.startHour;
  const center = (window.startHour + window.endHour) / 2;
  const nextSpan = span / Math.max(0.1, scale);
  return clampTimeWindow(center - nextSpan / 2, nextSpan);
}

export function panTimeWindow(window: TimeWindow, translationX: number, plotWidth: number): TimeWindow {
  const span = window.endHour - window.startHour;
  const hourShift = -(translationX / Math.max(1, plotWidth)) * span;
  return clampTimeWindow(window.startHour + hourShift, span);
}

export function timeTickStep(spanHours: number) {
  if (spanHours <= 0.75) return 1 / 12;
  if (spanHours <= 2) return 0.25;
  if (spanHours <= 4) return 0.5;
  if (spanHours <= 8) return 1;
  if (spanHours <= 14) return 2;
  return 4;
}

export function getTimeTicks(window: TimeWindow) {
  const span = window.endHour - window.startHour;
  const step = timeTickStep(span);
  const first = Math.ceil(window.startHour / step) * step;
  const ticks: number[] = [];
  for (let value = first; value <= window.endHour + 0.0001; value += step) ticks.push(Math.round(value * 1000) / 1000);
  return ticks;
}

export function timePositionInWindow(hour: number, window: TimeWindow, plotWidth: number) {
  return ((hour - window.startHour) / Math.max(0.0001, window.endHour - window.startHour)) * plotWidth;
}
