/**
 * The JavaScript package may be present while an older APK or Expo Go lacks its
 * compiled native module. Loading the package in that state throws immediately,
 * so the dashboard must check the native registry first.
 */
export function hasGoogleMobileAdsNativeModule(nativeModules: unknown): boolean {
  return typeof nativeModules === "object" && nativeModules !== null && "RNGoogleMobileAdsModule" in nativeModules;
}

/**
 * The JavaScript bundle can be newer than the installed native binary. Only a
 * binary built with the matching app-config marker may load the Ads package.
 */
export function canLoadGoogleMobileAds(input: {
  appOwnership?: string | null;
  adsNativeBuildEnabled?: unknown;
  nativeModuleIncluded: boolean;
}): boolean {
  return input.appOwnership !== "expo" && input.adsNativeBuildEnabled === true && input.nativeModuleIncluded;
}
