export const CHRYSALIS_THRESHOLD = 5;
export const MAX_GARDEN_BUTTERFLIES = 72;
export const MAX_HIVE_CLUSTERS = 120;
/** A complete live focus-world story spans 26 completed study rounds. */
export const GROWTH_JOURNEY_ROUNDS = 26;
/** The completed butterfly or hive remains visible for two additional study rounds. */
export const GROWTH_JOURNEY_HOLD_ROUNDS = 2;
export const GROWTH_JOURNEY_CYCLE_ROUNDS = GROWTH_JOURNEY_ROUNDS + GROWTH_JOURNEY_HOLD_ROUNDS;

export const GROWTH_SUBJECT_COLORS = ["#087A50", "#1268A6", "#8B4EC8", "#E08A00", "#D63B25", "#008D9A"] as const;
export const BUTTERFLY_VARIANTS = [
  { id: "verdant", primary: "#4EAE72", secondary: "#D5E68D" },
  { id: "sky", primary: "#598ED7", secondary: "#BBDCF4" },
  { id: "amber", primary: "#DC9B32", secondary: "#FFE07A" },
  { id: "violet", primary: "#9B76C9", secondary: "#EDC5E2" },
  { id: "coral", primary: "#DF8277", secondary: "#FFC58C" },
] as const;

export type GrowthTheme = "butterfly" | "hive" | "river";
export type ButterflyVariant = (typeof BUTTERFLY_VARIANTS)[number];

export type GardenProgress = {
  subjectTag: string;
  completedSessionsTowardChrysalis: number;
  contributionIds: string[];
  lastCompletedAtMs: number;
};

export type GardenButterfly = {
  id: string;
  subjectTag: string;
  emergedAtMs: number;
  contributionIds: string[];
  fromMs: number;
  toMs: number;
};

export type HiveCell = {
  fillPercent: 0 | 40 | 100;
};

export type HiveCluster = {
  id: string;
  sessionId: string;
  completedAtMs: number;
  subjectTag: string;
  roundsCompleted: number;
  roundsPlanned: number;
  status: "complete" | "incomplete";
  cells: HiveCell[];
};

export type FocusGrowthState = {
  garden: GardenProgress[];
  butterflies: GardenButterfly[];
  hive: HiveCluster[];
};

export const EMPTY_FOCUS_GROWTH: FocusGrowthState = { garden: [], butterflies: [], hive: [] };

function whole(value: unknown, fallback: number, min: number, max: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

function cleanSubject(value: unknown) {
  if (typeof value !== "string") return "General study";
  const subject = value.trim().replace(/\s+/g, " ").slice(0, 32);
  return subject || "General study";
}

function cleanId(value: unknown) {
  return typeof value === "string" ? value.trim().slice(0, 160) : "";
}

function uniqueIds(value: unknown, limit = CHRYSALIS_THRESHOLD) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map(cleanId).filter(Boolean))].slice(-limit);
}

export function normalizeGrowthTheme(value: unknown): GrowthTheme {
  return value === "hive" ? "hive" : value === "river" ? "river" : "butterfly";
}

/** Draw once at session creation. An optional source makes the rule deterministic in tests. */
export function drawGrowthTheme(random: () => number = Math.random): GrowthTheme {
  const roll = Math.min(2, Math.floor(Math.max(0, random()) * 3));
  return (["butterfly", "hive", "river"] as const)[roll] ?? "butterfly";
}

/** Keeps an unfinished balanced pair small, migration-safe, and safe to persist locally. */
export function normalizeGrowthThemeDeck(value: unknown): GrowthTheme[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((entry): entry is GrowthTheme => entry === "butterfly" || entry === "hive" || entry === "river"))].slice(0, 2);
}

/**
 * Randomly chooses the first world in each three-session set, then queues the
 * other two worlds. This retains random ordering while guaranteeing every world
 * is reachable without a long repeat streak.
 */
export function drawBalancedGrowthTheme(deck: GrowthTheme[], random: () => number = Math.random) {
  const queued = normalizeGrowthThemeDeck(deck);
  if (queued.length) return { theme: queued[0]!, remainingDeck: queued.slice(1) };
  const theme = drawGrowthTheme(random);
  const remainingDeck = (["butterfly", "hive", "river"] as const).filter((entry) => entry !== theme);
  return { theme, remainingDeck };
}

export function getGrowthStageThreshold(stageIndex: number, roundsPlanned: number) {
  const stage = whole(stageIndex, 1, 1, 4);
  const rounds = whole(roundsPlanned, 4, 1, 12);
  return Math.ceil((stage / 4) * rounds);
}

/** Maps a completed-round count in the current cycle to the four visual growth stages. */
export function getGrowthStage(roundsCompleted: number, roundsPlanned: number) {
  const rounds = whole(roundsPlanned, 4, 1, 12);
  const completed = whole(roundsCompleted, 0, 0, rounds);
  let stage = 0;
  for (let candidate = 1; candidate <= 4; candidate += 1) {
    if (completed >= getGrowthStageThreshold(candidate, rounds)) stage = candidate;
  }
  return stage as 0 | 1 | 2 | 3 | 4;
}

/** Maps the current 28-round visual cycle onto its 26-round growth path, holding the final state for rounds 27–28. */
export function getGrowthJourneyRound(roundsCompleted: number) {
  return whole(roundsCompleted, 0, 0, GROWTH_JOURNEY_ROUNDS);
}

/**
 * Five visual chapters: resting, four gradually advancing caterpillar/chrysalis chapters,
 * then the one-time butterfly completion at round 26. Rounds 1–25 are distributed as
 * evenly as possible across the four growing chapters.
 */
export function getGrowthJourneyChapter(roundsCompleted: number) {
  const round = getGrowthJourneyRound(roundsCompleted);
  if (!round) return 0 as const;
  if (round >= GROWTH_JOURNEY_ROUNDS) return 5 as const;
  return (Math.floor(((round - 1) * 4) / (GROWTH_JOURNEY_ROUNDS - 1)) + 1) as 1 | 2 | 3 | 4;
}

export function getGrowthJourneyProgress(roundsCompleted: number) {
  return getGrowthJourneyRound(roundsCompleted) / GROWTH_JOURNEY_ROUNDS;
}

/** One bee is present at the start; one new bee joins after every two completed rounds. */
export function getHiveBeeCount(roundsCompleted: number) {
  return Math.min(14, 1 + Math.floor(getGrowthJourneyRound(roundsCompleted) / 2));
}

export function didCompleteGrowthJourney(previousRoundsCompleted: number, nextRoundsCompleted: number) {
  return getGrowthJourneyRound(previousRoundsCompleted) < GROWTH_JOURNEY_ROUNDS && getGrowthJourneyRound(nextRoundsCompleted) === GROWTH_JOURNEY_ROUNDS;
}

/** Reset only after the 28th completed study round has gone through its rest and a new first round is active. */
export function shouldResetGrowthJourney(phase: "focus" | "reset" | "paused", roundNumber: number, journeyRounds: number) {
  return phase === "focus" && roundNumber === 1 && journeyRounds >= GROWTH_JOURNEY_CYCLE_ROUNDS;
}

/** The random session id chooses a varied colour, while the hash keeps the emergence stable after a render or resume. */
export function getButterflyVariant(sessionId: string): ButterflyVariant {
  const hash = [...sessionId].reduce((value, character) => ((value * 31) + character.charCodeAt(0)) >>> 0, 7);
  return BUTTERFLY_VARIANTS[hash % BUTTERFLY_VARIANTS.length] ?? BUTTERFLY_VARIANTS[0]!;
}

export function getGrowthSubjectTint(subjectTag?: string) {
  const normalized = cleanSubject(subjectTag);
  if (normalized === "General study") return "#6E8874";
  const hash = [...normalized.toLocaleLowerCase()].reduce((total, character) => total + character.charCodeAt(0), 0);
  return GROWTH_SUBJECT_COLORS[hash % GROWTH_SUBJECT_COLORS.length];
}

export function getHiveCellsForStage(stage: number, capstone = false): HiveCell[] {
  const normalizedStage = whole(stage, 0, 0, 4);
  return Array.from({ length: normalizedStage }, (_, index) => {
    const relativeStage = normalizedStage - index;
    const fillPercent: HiveCell["fillPercent"] = capstone ? 100 : relativeStage >= 3 ? 100 : relativeStage >= 2 ? 40 : 0;
    return { fillPercent };
  });
}

export function normalizeFocusGrowth(value: unknown): FocusGrowthState {
  if (!value || typeof value !== "object") return EMPTY_FOCUS_GROWTH;
  const source = value as Partial<FocusGrowthState>;
  const garden = Array.isArray(source.garden)
    ? source.garden.map((entry) => {
      if (!entry || typeof entry !== "object") return null;
      const item = entry as Partial<GardenProgress>;
      const contributionIds = uniqueIds(item.contributionIds);
      return {
        subjectTag: cleanSubject(item.subjectTag),
        completedSessionsTowardChrysalis: Math.min(CHRYSALIS_THRESHOLD - 1, contributionIds.length || whole(item.completedSessionsTowardChrysalis, 0, 0, CHRYSALIS_THRESHOLD - 1)),
        contributionIds,
        lastCompletedAtMs: whole(item.lastCompletedAtMs, 0, 0, Number.MAX_SAFE_INTEGER),
      };
    }).filter((entry): entry is GardenProgress => Boolean(entry)).slice(0, 36)
    : [];
  const butterflies = Array.isArray(source.butterflies)
    ? source.butterflies.map((entry) => {
      if (!entry || typeof entry !== "object") return null;
      const item = entry as Partial<GardenButterfly>;
      const id = cleanId(item.id);
      const contributionIds = uniqueIds(item.contributionIds);
      if (!id || contributionIds.length !== CHRYSALIS_THRESHOLD) return null;
      const emergedAtMs = whole(item.emergedAtMs, 0, 0, Number.MAX_SAFE_INTEGER);
      return { id, subjectTag: cleanSubject(item.subjectTag), emergedAtMs, contributionIds, fromMs: whole(item.fromMs, emergedAtMs, 0, Number.MAX_SAFE_INTEGER), toMs: whole(item.toMs, emergedAtMs, 0, Number.MAX_SAFE_INTEGER) };
    }).filter((entry): entry is GardenButterfly => Boolean(entry)).slice(0, MAX_GARDEN_BUTTERFLIES)
    : [];
  const hive = Array.isArray(source.hive)
    ? source.hive.map((entry) => {
      if (!entry || typeof entry !== "object") return null;
      const item = entry as Partial<HiveCluster>;
      const id = cleanId(item.id);
      const sessionId = cleanId(item.sessionId);
      const roundsPlanned = whole(item.roundsPlanned, 4, 1, 12);
      const roundsCompleted = whole(item.roundsCompleted, 0, 0, roundsPlanned);
      if (!id || !sessionId) return null;
      const stage = getGrowthStage(roundsCompleted, roundsPlanned);
      const cells = Array.isArray(item.cells) ? item.cells.slice(0, 4).map((cell) => ({ fillPercent: cell?.fillPercent === 100 ? 100 : cell?.fillPercent === 40 ? 40 : 0 as const })) : getHiveCellsForStage(stage, item.status === "complete");
      return { id, sessionId, completedAtMs: whole(item.completedAtMs, 0, 0, Number.MAX_SAFE_INTEGER), subjectTag: cleanSubject(item.subjectTag), roundsCompleted, roundsPlanned, status: item.status === "complete" ? "complete" : "incomplete", cells };
    }).filter((entry): entry is HiveCluster => Boolean(entry)).slice(0, MAX_HIVE_CLUSTERS)
    : [];
  return { garden, butterflies, hive };
}

export function addGardenCompletion(state: FocusGrowthState, input: { sessionId: string; cycleIndex: number; subjectTag?: string; completedAtMs: number }) {
  const contributionId = `${input.sessionId}-garden-cycle-${input.cycleIndex}`;
  if (state.garden.some((entry) => entry.contributionIds.includes(contributionId)) || state.butterflies.some((entry) => entry.contributionIds.includes(contributionId))) return state;
  const subjectTag = cleanSubject(input.subjectTag);
  const existing = state.garden.find((entry) => entry.subjectTag.toLocaleLowerCase() === subjectTag.toLocaleLowerCase());
  const contributionIds = [...(existing?.contributionIds ?? []), contributionId].slice(-CHRYSALIS_THRESHOLD);
  const remainingGarden = state.garden.filter((entry) => entry !== existing);
  if (contributionIds.length < CHRYSALIS_THRESHOLD) {
    return { ...state, garden: [{ subjectTag, completedSessionsTowardChrysalis: contributionIds.length, contributionIds, lastCompletedAtMs: input.completedAtMs }, ...remainingGarden].slice(0, 36) };
  }
  const butterfly: GardenButterfly = {
    id: `${input.sessionId}-butterfly-${input.cycleIndex}`,
    subjectTag,
    emergedAtMs: input.completedAtMs,
    contributionIds,
    fromMs: existing?.lastCompletedAtMs || input.completedAtMs,
    toMs: input.completedAtMs,
  };
  return { garden: remainingGarden, butterflies: [butterfly, ...state.butterflies].slice(0, MAX_GARDEN_BUTTERFLIES), hive: state.hive };
}

export function createHiveCluster(input: { sessionId: string; cycleIndex?: number; completedAtMs: number; subjectTag?: string; roundsCompleted: number; roundsPlanned: number; status: "complete" | "incomplete" }): HiveCluster | null {
  const roundsPlanned = whole(input.roundsPlanned, 4, 1, 12);
  const roundsCompleted = whole(input.roundsCompleted, 0, 0, roundsPlanned);
  const stage = getGrowthStage(roundsCompleted, roundsPlanned);
  if (!stage) return null;
  const complete = input.status === "complete";
  return {
    id: complete ? `${input.sessionId}-hive-cycle-${input.cycleIndex ?? 0}` : `${input.sessionId}-hive-incomplete-${input.completedAtMs}`,
    sessionId: input.sessionId,
    completedAtMs: whole(input.completedAtMs, 0, 0, Number.MAX_SAFE_INTEGER),
    subjectTag: cleanSubject(input.subjectTag),
    roundsCompleted,
    roundsPlanned,
    status: complete ? "complete" : "incomplete",
    cells: getHiveCellsForStage(stage, complete),
  };
}

export function addHiveCluster(state: FocusGrowthState, cluster: HiveCluster | null) {
  if (!cluster || state.hive.some((entry) => entry.id === cluster.id)) return state;
  return { ...state, hive: [cluster, ...state.hive].sort((a, b) => b.completedAtMs - a.completedAtMs).slice(0, MAX_HIVE_CLUSTERS) };
}
