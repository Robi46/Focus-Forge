import { describe, expect, it } from "vitest";

import { createSessionBubblePayload } from "../lib/session-bubble-core";
import type { ActiveSession } from "../lib/focusforge-core";

const session: ActiveSession = {
  id: "bubble-session",
  startedAtMs: 123_000,
  accumulatedPausedMs: 4_000,
  notificationIds: [],
  plan: { roundMinutes: 5, roundsPerCycle: 4, restSeconds: 120 },
};

describe("session bubble payload", () => {
  it("passes the active session rhythm and pause offset to the Android overlay", () => {
    expect(createSessionBubblePayload(session)).toEqual({
      startedAtMs: 123_000,
      accumulatedPausedMs: 4_000,
      roundMinutes: 5,
      roundsPerCycle: 4,
      restSeconds: 120,
    });
  });
});
