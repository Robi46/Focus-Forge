import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import { useState } from "react";
import { Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { FocusRing } from "@/components/focus-ring";
import { FocusAdSpace } from "@/components/focus-ad-space";
import { FocusGrowthScene } from "@/components/growth-theme/focus-growth-scene";
import { IconCircle, SectionLabel, Stepper } from "@/components/focusforge-ui";
import { ScreenContainer } from "@/components/screen-container";
import { elapsedSessionMs, formatClock, SUBJECT_TAG_SUGGESTIONS } from "@/lib/focusforge-core";
import { useFocusForge } from "@/lib/focusforge-provider";

function tap(enabled = true) {
  if (enabled && Platform.OS !== "web") void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

export default function FocusScreen() {
  const { settings, session, snapshot, permission, updateSettings, grantAdFreeTime, startSession, pauseSession, resumeSession, endSession, updateSessionGoalOutcome, requestCueAccess, studySummary, now } = useFocusForge();
  const [endConfirmOpen, setEndConfirmOpen] = useState(false);
  const [subjectPickerOpen, setSubjectPickerOpen] = useState(false);
  const [customSubject, setCustomSubject] = useState("");
  const [inlineSubjectInput, setInlineSubjectInput] = useState("");
  const [sessionGoalInput, setSessionGoalInput] = useState("");
  const [goalOutcomeOpen, setGoalOutcomeOpen] = useState(false);
  const [endedGoalSessionId, setEndedGoalSessionId] = useState<string | null>(null);
  const [endedGoalText, setEndedGoalText] = useState("");
  const [abandonSignal, setAbandonSignal] = useState(0);
  const isPaused = Boolean(session?.pausedAtMs);
  const phase = snapshot?.phase ?? "ready";
  const restLabel = settings.restSeconds % 60 === 0 ? `${settings.restSeconds / 60} min` : `${settings.restSeconds} sec`;
  const primaryText = !session ? "Start study session" : isPaused ? "Resume session" : "Pause session";
  const roundText = snapshot?.phase === "reset"
    ? `REST • ${restLabel.toUpperCase()}`
    : snapshot
      ? `ROUND ${snapshot.roundNumber} OF ${snapshot.roundsPerCycle}`
      : `${settings.roundsPerCycle} ROUNDS • ${settings.roundMinutes} MINUTES EACH`;
  const subjectLabel = session?.subjectTag ?? settings.subjectTag;
  const localTime = new Date(now).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const localDate = new Date(now).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
  const sessionTotalSeconds = session ? Math.floor(elapsedSessionMs(session, now) / 1000) : 0;
  const growthScene = session && snapshot ? {
    sessionId: session.id,
    growthTheme: session.growthTheme,
    subjectTag: session.subjectTag,
    phase: snapshot.phase,
    roundsCompleted: snapshot.roundsCompleted,
    roundsPerCycle: snapshot.roundsPerCycle,
    growthJourneyStartedAtRounds: session.growthJourneyStartedAtRounds,
    growthJourneyIndex: session.growthJourneyIndex,
    paused: isPaused,
  } : null;
  const availableSubjects = [...settings.customSubjects, ...SUBJECT_TAG_SUGGESTIONS.filter((subject) => !settings.customSubjects.some((custom) => custom.toLocaleLowerCase() === subject.toLocaleLowerCase()))];
  const saveSubject = (subject: string) => {
    const cleaned = subject.trim();
    if (!cleaned) return;
    const alreadySaved = settings.customSubjects.some((custom) => custom.toLocaleLowerCase() === cleaned.toLocaleLowerCase());
    const isSuggestion = SUBJECT_TAG_SUGGESTIONS.some((suggestion) => suggestion.toLocaleLowerCase() === cleaned.toLocaleLowerCase());
    void updateSettings({ subjectTag: cleaned, customSubjects: alreadySaved || isSuggestion ? settings.customSubjects : [...settings.customSubjects, cleaned] });
    setCustomSubject("");
    setInlineSubjectInput(cleaned);
    setSubjectPickerOpen(false);
  };

  const handlePrimary = async () => {
    tap(settings.hapticsEnabled);
    if (!session) {
      if (permission !== "granted" && settings.soundEnabled) await requestCueAccess();
      await startSession(sessionGoalInput);
      setSessionGoalInput("");
      return;
    }
    if (isPaused) await resumeSession(); else await pauseSession();
  };

  const handleEnd = () => setEndConfirmOpen(true);
  const confirmEnd = async () => {
    setEndConfirmOpen(false);
    setAbandonSignal((value) => value + 1);
    const record = await endSession();
    if (record?.goal && record.focusedSeconds > 0) {
      setEndedGoalSessionId(record.id);
      setEndedGoalText(record.goal);
      setGoalOutcomeOpen(true);
    }
  };
  const markGoalOutcome = async (outcome: "completed" | "partial") => {
    if (endedGoalSessionId) await updateSessionGoalOutcome(endedGoalSessionId, outcome);
    setGoalOutcomeOpen(false);
    setEndedGoalSessionId(null);
    setEndedGoalText("");
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View><Text style={styles.eyebrow}>FOCUSFORGE · LOCAL TIME</Text><Text style={styles.localClock}>{localTime}</Text><Text style={styles.localDate}>{localDate}</Text></View>
          <IconCircle icon="tune" onPress={() => router.push("/rhythm-designer" as never)} />
        </View>

        <View style={styles.statusLine}>
          <View style={[styles.statusDot, { backgroundColor: session ? (isPaused ? "#668070" : "#0BA66A") : "#087A50" }]} />
          <Text style={styles.statusText}>{session ? (isPaused ? "Session paused — your time is held." : "Session active — your rhythm is protected.") : "Ready when you are."}</Text>
        </View>

        <FocusRing progress={snapshot?.progress ?? 0} time={snapshot ? formatClock(snapshot.remainingSeconds) : formatClock(settings.roundMinutes * 60)} phase={phase} />
        <Text style={[styles.roundText, snapshot?.phase === "reset" && styles.restText]}>{roundText}</Text>

        <View style={styles.metrics}>
          <View style={styles.metric}><Text style={styles.metricValue}>{snapshot?.completedBlocks ?? 0}</Text><Text style={styles.metricLabel}>CYCLES</Text></View>
          <View style={styles.metricDivider} />
          <View style={styles.metric}><Text style={[styles.metricValue, styles.sessionTimeValue]}>{formatClock(sessionTotalSeconds)}</Text><Text style={styles.metricLabel}>SESSION TIME</Text></View>
          <View style={styles.metricDivider} />
          <View style={styles.metric}><Text style={styles.metricValue}>{studySummary.today}</Text><Text style={styles.metricLabel}>TODAY</Text></View>
        </View>

        {!session ? <View style={styles.inlineSubjectCard}><View style={styles.inlineSubjectHeader}><View><Text style={styles.inlineSubjectLabel}>SESSION GOAL · OPTIONAL</Text><Text style={styles.inlineSubjectCurrent}>What do you want to finish in this session?</Text></View><MaterialIcons name="flag" size={20} color="#1268A6" /></View><View style={styles.inlineSubjectEntry}><TextInput value={sessionGoalInput} onChangeText={setSessionGoalInput} placeholder="Type a short goal, e.g. Solve 15 calculus problems" placeholderTextColor="#78907F" maxLength={140} returnKeyType="done" style={styles.inlineSubjectInput} /></View></View> : null}

        <Pressable onPress={() => void handlePrimary()} style={({ pressed }) => [styles.primaryButton, pressed && styles.buttonPressed]}>
          <MaterialIcons name={session && !isPaused ? "pause" : "play-arrow"} size={25} color="#FFFFFF" />
          <Text style={styles.primaryText}>{primaryText}</Text>
        </Pressable>
        {session ? <Pressable onPress={handleEnd} style={({ pressed }) => [styles.endButton, pressed && { opacity: 0.68 }]}><Text style={styles.endText}>End session</Text></Pressable> : null}
        <FocusGrowthScene scene={growthScene} abandonSignal={abandonSignal} onStageSettled={() => tap(settings.hapticsEnabled)} />
        {session?.goal ? <View style={styles.planningStrip}><View style={styles.planningItem}><View style={styles.planningIcon}><MaterialIcons name="flag" size={17} color="#1268A6" /></View><View style={styles.planningCopy}><Text style={styles.planningLabel}>SESSION GOAL</Text><Text style={styles.planningValue} numberOfLines={2}>{session.goal}</Text></View></View></View> : null}

        {!session ? <View style={styles.inlineSubjectCard}><View style={styles.inlineSubjectHeader}><View><Text style={styles.inlineSubjectLabel}>WHAT ARE YOU STUDYING NOW?</Text><Text style={styles.inlineSubjectCurrent}>Current subject: {settings.subjectTag}</Text></View><MaterialIcons name="sell" size={20} color="#1268A6" /></View><View style={styles.inlineSubjectEntry}><TextInput value={inlineSubjectInput} onChangeText={setInlineSubjectInput} placeholder="Type a subject, e.g. Physics" placeholderTextColor="#78907F" maxLength={32} returnKeyType="done" onSubmitEditing={() => saveSubject(inlineSubjectInput)} style={styles.inlineSubjectInput} /><Pressable disabled={!inlineSubjectInput.trim()} onPress={() => saveSubject(inlineSubjectInput)} style={({ pressed }) => [styles.inlineSubjectSet, !inlineSubjectInput.trim() && styles.inlineSubjectSetDisabled, pressed && { opacity: 0.75 }]}><Text style={styles.inlineSubjectSetText}>Set</Text></Pressable></View><Pressable onPress={() => setSubjectPickerOpen(true)} style={({ pressed }) => [styles.inlineSubjectBrowse, pressed && { opacity: 0.7 }]}><Text style={styles.inlineSubjectBrowseText}>Browse saved and starter subjects</Text><MaterialIcons name="chevron-right" size={17} color="#1268A6" /></Pressable></View> : null}

        <View style={styles.planningStrip}><Pressable disabled={Boolean(session)} onPress={() => setSubjectPickerOpen(true)} style={({ pressed }) => [styles.planningItem, pressed && !session && { backgroundColor: "#EAF7EC" }]}><View style={styles.planningIcon}><MaterialIcons name="sell" size={17} color="#1268A6" /></View><View style={styles.planningCopy}><Text style={styles.planningLabel}>{session ? "CURRENT SUBJECT" : "TAP TO TAG NEXT SESSION"}</Text><Text style={styles.planningValue} numberOfLines={1}>{subjectLabel}</Text></View><MaterialIcons name={session ? "lock-outline" : "chevron-right"} size={18} color="#1268A6" /></Pressable><View style={styles.planningDivider} /><Pressable onPress={() => router.push("/(tabs)/history" as never)} style={({ pressed }) => [styles.planningItem, pressed && { backgroundColor: "#EAF7EC" }]}><View style={[styles.planningIcon, { backgroundColor: "#E7F5EA" }]}><MaterialIcons name="track-changes" size={17} color="#087A50" /></View><View style={styles.planningCopy}><Text style={styles.planningLabel}>WEEKLY FOCUS GOAL</Text><Text style={styles.planningValue}>View & edit progress</Text></View><MaterialIcons name="chevron-right" size={18} color="#087A50" /></Pressable></View>

        {permission !== "granted" && settings.soundEnabled ? <Pressable onPress={() => void requestCueAccess()} style={({ pressed }) => [styles.permissionCard, pressed && { opacity: 0.72 }]}><MaterialIcons name="notifications-none" size={21} color="#FFB55F" /><View style={styles.permissionCopy}><Text style={styles.permissionTitle}>Allow study cues</Text><Text style={styles.permissionDetail}>Enable notifications so chimes work while your display is off.</Text></View><MaterialIcons name="chevron-right" size={22} color="#FFB55F" /></Pressable> : null}
        {!session ? <FocusAdSpace adFreeUntilMs={settings.adFreeUntilMs} nowMs={now} onRewardEarned={() => void grantAdFreeTime()} /> : <View style={styles.sessionProtectionNote}><MaterialIcons name="verified-user" size={16} color="#087A50" /><Text style={styles.sessionProtectionText}>No ads during an active focus session. Protect your attention first.</Text></View>}
      </ScrollView>

      <Modal visible={endConfirmOpen} transparent animationType="fade" onRequestClose={() => setEndConfirmOpen(false)}>
        <View style={styles.confirmOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setEndConfirmOpen(false)} />
          <View style={styles.confirmCard}>
            <View style={styles.confirmIcon}><MaterialIcons name="stop-circle" size={25} color="#FFB55F" /></View>
            <Text style={styles.confirmTitle}>End study session?</Text>
            <Text style={styles.confirmDetail}>Your focused time and completed blocks will be saved on this device.</Text>
            <View style={styles.confirmActions}>
              <Pressable onPress={() => setEndConfirmOpen(false)} style={({ pressed }) => [styles.confirmSecondary, pressed && { opacity: 0.68 }]}><Text style={styles.confirmSecondaryText}>Keep studying</Text></Pressable>
              <Pressable onPress={() => void confirmEnd()} style={({ pressed }) => [styles.confirmPrimary, pressed && { opacity: 0.78, transform: [{ scale: 0.98 }] }]}><Text style={styles.confirmPrimaryText}>End session</Text></Pressable>
            </View>
          </View>
        </View>
      </Modal>
      <Modal visible={goalOutcomeOpen} transparent animationType="fade" onRequestClose={() => setGoalOutcomeOpen(false)}>
        <View style={styles.confirmOverlay}>
          <View style={styles.confirmCard}>
            <View style={styles.confirmIcon}><MaterialIcons name="flag" size={25} color="#1268A6" /></View>
            <Text style={styles.confirmTitle}>How did your goal go?</Text>
            <Text style={styles.confirmDetail} numberOfLines={3}>{endedGoalText}</Text>
            <View style={styles.confirmActions}>
              <Pressable onPress={() => void markGoalOutcome("partial")} style={({ pressed }) => [styles.confirmSecondary, pressed && { opacity: 0.68 }]}><Text style={styles.confirmSecondaryText}>Partial</Text></Pressable>
              <Pressable onPress={() => void markGoalOutcome("completed")} style={({ pressed }) => [styles.confirmPrimary, pressed && { opacity: 0.78, transform: [{ scale: 0.98 }] }]}><Text style={styles.confirmPrimaryText}>Completed</Text></Pressable>
            </View>
          </View>
        </View>
      </Modal>
      <Modal visible={subjectPickerOpen} transparent animationType="slide" onRequestClose={() => setSubjectPickerOpen(false)}>
        <View style={styles.subjectOverlay}><Pressable style={StyleSheet.absoluteFill} onPress={() => setSubjectPickerOpen(false)} /><View style={styles.subjectSheet}><View style={styles.subjectHandle} /><Text style={styles.subjectTitle}>What are you studying now?</Text><Text style={styles.subjectSubtitle}>Choose a subject before starting. Custom subjects are saved here for future sessions.</Text>{settings.customSubjects.length ? <><Text style={styles.subjectGroupLabel}>YOUR SUBJECTS</Text><View style={styles.subjectChips}>{settings.customSubjects.map((subject) => <Pressable key={subject} onPress={() => saveSubject(subject)} style={({ pressed }) => [styles.subjectChip, settings.subjectTag === subject && styles.subjectChipSelected, pressed && { opacity: 0.72 }]}><Text style={[styles.subjectChipText, settings.subjectTag === subject && styles.subjectChipTextSelected]}>{subject}</Text></Pressable>)}</View></> : null}<Text style={styles.subjectGroupLabel}>STARTER SUBJECTS</Text><View style={styles.subjectChips}>{availableSubjects.filter((subject) => !settings.customSubjects.includes(subject)).map((subject) => <Pressable key={subject} onPress={() => saveSubject(subject)} style={({ pressed }) => [styles.subjectChip, settings.subjectTag === subject && styles.subjectChipSelected, pressed && { opacity: 0.72 }]}><Text style={[styles.subjectChipText, settings.subjectTag === subject && styles.subjectChipTextSelected]}>{subject}</Text></Pressable>)}</View><TextInput value={customSubject} onChangeText={setCustomSubject} placeholder="Type a subject, for example Physics" placeholderTextColor="#78907F" maxLength={32} returnKeyType="done" onSubmitEditing={() => saveSubject(customSubject)} style={styles.subjectInput} /><Pressable onPress={() => saveSubject(customSubject)} style={({ pressed }) => [styles.subjectSave, !customSubject.trim() && styles.subjectSaveDisabled, pressed && { opacity: 0.75 }]}><Text style={styles.subjectSaveText}>Save & use this subject</Text></Pressable></View></View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 32 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, eyebrow: { color: "#087A50", fontSize: 10, fontWeight: "900", letterSpacing: 1.7 }, localClock: { color: "#E17817", fontSize: 32, lineHeight: 37, fontWeight: "900", letterSpacing: 0.8, marginTop: 3, fontVariant: ["tabular-nums"] }, localDate: { color: "#6A816F", fontSize: 11, fontWeight: "800", marginTop: 1 },
  statusLine: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 20, alignSelf: "center", paddingHorizontal: 12, paddingVertical: 7, backgroundColor: "#EDF8EF", borderRadius: 20, borderWidth: 1, borderColor: "#D7EADB" }, statusDot: { width: 7, height: 7, borderRadius: 4 }, statusText: { color: "#51715D", fontSize: 12, lineHeight: 17, fontWeight: "700" },
  roundText: { color: "#087A50", fontSize: 11, lineHeight: 15, fontWeight: "900", letterSpacing: 1.6, textAlign: "center", marginTop: -4 }, restText: { color: "#AE7418" },
  metrics: { flexDirection: "row", alignItems: "center", justifyContent: "space-around", marginTop: 20, marginBottom: 24 }, metric: { flex: 1, alignItems: "center" }, metricValue: { color: "#173423", fontSize: 15, fontWeight: "900", fontVariant: ["tabular-nums"] }, sessionTimeValue: { color: "#E17817" }, metricLabel: { color: "#5E7D68", fontSize: 9, fontWeight: "900", letterSpacing: 1.1, marginTop: 4 }, metricDivider: { width: 1, height: 28, backgroundColor: "#CFE3D3" },
  primaryButton: { minHeight: 58, borderRadius: 18, backgroundColor: "#087A50", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, shadowColor: "#087A50", shadowOpacity: 0.2, shadowOffset: { width: 0, height: 8 }, shadowRadius: 13, elevation: 4 }, buttonPressed: { opacity: 0.86, transform: [{ scale: 0.98 }] }, primaryText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" }, endButton: { minHeight: 44, alignItems: "center", justifyContent: "center", marginTop: 3 }, endText: { color: "#55735F", fontSize: 13, fontWeight: "800" }, inlineSubjectCard: { marginTop: 12, borderRadius: 17, padding: 14, backgroundColor: "#F5FBF6", borderWidth: 1, borderColor: "#C7E5CE" }, inlineSubjectHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, inlineSubjectLabel: { color: "#1268A6", fontSize: 9, fontWeight: "900", letterSpacing: 0.85 }, inlineSubjectCurrent: { color: "#173423", fontSize: 12, fontWeight: "900", marginTop: 4 }, inlineSubjectEntry: { flexDirection: "row", gap: 8, marginTop: 12 }, inlineSubjectInput: { flex: 1, minHeight: 45, borderRadius: 12, paddingHorizontal: 12, color: "#173423", fontSize: 13, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#C7DDCC" }, inlineSubjectSet: { minWidth: 58, minHeight: 45, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#1268A6" }, inlineSubjectSetDisabled: { backgroundColor: "#B8D1BD" }, inlineSubjectSetText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, inlineSubjectBrowse: { minHeight: 34, marginTop: 7, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, inlineSubjectBrowseText: { color: "#1268A6", fontSize: 11, fontWeight: "900" }, planningStrip: { marginTop: 12, borderRadius: 17, borderWidth: 1, borderColor: "#D3E7D7", overflow: "hidden", backgroundColor: "#FCFFFC" }, planningItem: { minHeight: 61, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 9 }, planningIcon: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#EAF1FF" }, planningCopy: { flex: 1 }, planningLabel: { color: "#668070", fontSize: 8, fontWeight: "900", letterSpacing: 0.65 }, planningValue: { color: "#173423", fontSize: 12, fontWeight: "900", marginTop: 3 }, planningDivider: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0", marginLeft: 54 },
  sectionSpacing: { marginTop: 18 }, rhythmRow: { padding: 16, minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12 }, rhythmIcon: { width: 39, height: 39, borderRadius: 13, justifyContent: "center", alignItems: "center" }, rhythmCopy: { flex: 1 }, rhythmTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, rhythmDetail: { color: "#63796B", fontSize: 12, lineHeight: 17, marginTop: 2 }, rhythmValue: { color: "#087A50", fontSize: 13, fontWeight: "900" }, rowDivider: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0", marginLeft: 67 }, designRhythmRow: { minHeight: 48, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, designRhythmText: { color: "#087A50", fontSize: 12, fontWeight: "900" },
  permissionCard: { marginTop: 18, borderRadius: 18, padding: 14, flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: "#FFB55F55", backgroundColor: "#FFB55F13" }, permissionCopy: { flex: 1 }, permissionTitle: { color: "#FFE6BF", fontSize: 14, fontWeight: "800" }, permissionDetail: { color: "#C9B28C", fontSize: 12, lineHeight: 17, marginTop: 2 }, sessionProtectionNote: { marginTop: 14, minHeight: 34, borderRadius: 11, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#EDF8EF", borderWidth: 1, borderColor: "#D7EADB" }, sessionProtectionText: { flex: 1, color: "#51715D", fontSize: 10, lineHeight: 15, fontWeight: "800" },
  subjectOverlay: { flex: 1, backgroundColor: "#17342388", justifyContent: "flex-end" }, subjectSheet: { backgroundColor: "#FCFFFC", borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingBottom: 31, borderWidth: 1, borderColor: "#CDE5D2" }, subjectHandle: { width: 42, height: 4, borderRadius: 2, backgroundColor: "#B8D1BD", alignSelf: "center", marginVertical: 11 }, subjectTitle: { color: "#173423", fontSize: 21, fontWeight: "900" }, subjectSubtitle: { color: "#63796B", fontSize: 12, lineHeight: 18, marginTop: 4 }, subjectGroupLabel: { color: "#5D7D66", fontSize: 9, fontWeight: "900", letterSpacing: 1, marginTop: 17 }, subjectChips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 9 }, subjectChip: { minHeight: 34, borderRadius: 11, paddingHorizontal: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#EDF7EF", borderWidth: 1, borderColor: "#CEE4D3" }, subjectChipSelected: { backgroundColor: "#1268A6", borderColor: "#1268A6" }, subjectChipText: { color: "#38624A", fontSize: 11, fontWeight: "900" }, subjectChipTextSelected: { color: "#FFFFFF" }, subjectInput: { minHeight: 48, borderRadius: 14, paddingHorizontal: 13, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#C7DDCC", color: "#173423", fontSize: 13, marginTop: 17 }, subjectSave: { minHeight: 50, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#087A50", marginTop: 10 }, subjectSaveDisabled: { backgroundColor: "#B8D1BD" }, subjectSaveText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
  modalBackdrop: { flex: 1, backgroundColor: "#020711B8", justifyContent: "flex-end" }, sheet: { backgroundColor: "#111E31", borderTopLeftRadius: 30, borderTopRightRadius: 30, paddingHorizontal: 20, paddingBottom: 30, borderWidth: 1, borderColor: "#263A56" }, sheetHandle: { width: 42, height: 4, borderRadius: 2, backgroundColor: "#506888", alignSelf: "center", marginVertical: 10 }, sheetHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }, sheetTitle: { color: "#EAF2FF", fontSize: 22, fontWeight: "800" }, sheetSubtitle: { color: "#91A7C6", fontSize: 13, marginTop: 3 }, setupRow: { minHeight: 82, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#263A56" }, setupTitle: { color: "#EAF2FF", fontSize: 15, fontWeight: "800" }, setupDetail: { color: "#91A7C6", fontSize: 12, lineHeight: 17, marginTop: 3, maxWidth: 225 }, setupValue: { color: "#CFE2FF", fontSize: 13, fontWeight: "900", textAlign: "right" }, sheetButton: { minHeight: 54, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "#4DA3FF", marginTop: 18 }, sheetButtonText: { color: "#07101E", fontWeight: "900", fontSize: 15 },
  confirmOverlay: { flex: 1, backgroundColor: "#020711BF", paddingHorizontal: 24, justifyContent: "center" }, confirmCard: { backgroundColor: "#111E31", borderRadius: 26, borderWidth: 1, borderColor: "#304866", padding: 22, alignItems: "center" }, confirmIcon: { width: 50, height: 50, borderRadius: 17, backgroundColor: "#FFB55F18", alignItems: "center", justifyContent: "center" }, confirmTitle: { color: "#EAF2FF", fontSize: 20, lineHeight: 26, fontWeight: "900", marginTop: 15 }, confirmDetail: { color: "#91A7C6", fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 6 }, confirmActions: { flexDirection: "row", gap: 10, width: "100%", marginTop: 22 }, confirmSecondary: { flex: 1, minHeight: 50, borderRadius: 16, borderWidth: 1, borderColor: "#38506E", alignItems: "center", justifyContent: "center" }, confirmSecondaryText: { color: "#C7D6EA", fontSize: 13, fontWeight: "800" }, confirmPrimary: { flex: 1, minHeight: 50, borderRadius: 16, backgroundColor: "#FFB55F", alignItems: "center", justifyContent: "center" }, confirmPrimaryText: { color: "#2A1802", fontSize: 13, fontWeight: "900" },
});
