import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, AppState, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { IconCircle, SectionLabel, Surface } from "@/components/focusforge-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useFocusForgeStatic } from "@/lib/focusforge-provider";
import { canDrawOverlays, isSessionBubbleSupported, openOverlayPermissionSettings } from "@/lib/session-bubble";

export default function ShieldScreen() {
  const { permission, session, settings, requestCueAccess, refreshCueSchedule } = useFocusForgeStatic();
  const notificationsOn = permission === "granted";
  const [overlayEnabled, setOverlayEnabled] = useState(false);
  useEffect(() => {
    setOverlayEnabled(canDrawOverlays());
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active") setOverlayEnabled(canDrawOverlays());
    });
    return () => subscription.remove();
  }, []);
  const openAppSettings = () => void Linking.openSettings();
  const requestOverlay = async () => {
    await openOverlayPermissionSettings();
    setOverlayEnabled(canDrawOverlays());
  };
  const showDndGuide = () => Alert.alert("Use Android Focus / Do Not Disturb", "In Android Settings, create a Focus or Do Not Disturb mode that silences non-essential apps. Keep calls and the people or apps you consider emergency exceptions enabled there. FocusForge cannot choose WhatsApp, Messenger, or call exceptions for you.");
  const showPinGuide = () => Alert.alert("Use Screen Pinning", "Android Screen Pinning is the supported way to hold one app on screen. Turn it on in Android Settings, begin a FocusForge session, then open Recents and pin FocusForge. Your phone’s own steps vary by manufacturer.");

  return <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.header}><View><Text style={styles.eyebrow}>FOCUS SHIELD</Text><Text style={styles.title}>Reduce the pull away.</Text></View><IconCircle icon="shield" color="#087A50" /></View>
    <Text style={styles.description}>FocusForge protects your session state and scheduled cues. Your phone’s system controls decide which calls and messages are allowed through.</Text>

    <Surface style={styles.statusCard}><View style={styles.statusHeader}><View style={styles.statusBadge}><MaterialIcons name={session ? "check-circle" : "radio-button-unchecked"} size={18} color={session ? "#5FE0B6" : "#9BAEC9"} /><Text style={[styles.statusBadgeText, { color: session ? "#5FE0B6" : "#9BAEC9" }]}>{session ? "SESSION ACTIVE" : "READY TO PROTECT"}</Text></View><MaterialIcons name="verified-user" size={27} color="#4DA3FF" /></View><Text style={styles.statusTitle}>{session ? "Your timer state survives screen lock and app return." : "Start a session to prepare local cue scheduling."}</Text><Text style={styles.statusDetail}>A fresh installed APK prepares a rolling 24-hour cue schedule. Audible locked-screen delivery still depends on Android notification-channel, DND, and battery settings.</Text>{session && notificationsOn ? <Pressable onPress={() => void refreshCueSchedule()} style={({ pressed }) => [styles.inlineAction, pressed && { opacity: 0.72 }]}><Text style={styles.inlineActionText}>Refresh cue schedule</Text><MaterialIcons name="refresh" size={17} color="#4DA3FF" /></Pressable> : null}</Surface>

    <View style={styles.section}><SectionLabel>DEVICE CONTROLS</SectionLabel><Surface>
      <GuideRow icon="notifications-active" tone="#4DA3FF" title="Study cues" detail={notificationsOn ? "Check the installed APK’s v3 beep channels, sound, DND bypass, and battery setting before relying on display-off cues." : "Allow notifications for installed-APK screen-off chimes."} action={notificationsOn ? "Open settings" : "Allow"} onPress={notificationsOn ? openAppSettings : () => void requestCueAccess()} />
      <Divider /><GuideRow icon="do-not-disturb-on" tone="#FFB55F" title="Allowed interruptions" detail="Choose emergency apps, then match them in Android Do Not Disturb." action="Choose apps" onPress={() => router.push("/allowed-interruptions" as never)} />
      {isSessionBubbleSupported() ? <><Divider /><GuideRow icon="picture-in-picture" tone="#087A50" title="Floating session bubble" detail={overlayEnabled ? "Shows a compact live round/rest counter after FocusForge is backgrounded. The × hides it without ending your session." : "Allow “Display over other apps” to show a compact counter and return-to-dashboard control while a study session is active."} action={overlayEnabled ? "Enabled" : "Enable"} onPress={() => void requestOverlay()} /></> : null}
      <Divider /><GuideRow icon="push-pin" tone="#5FE0B6" title="Keep FocusForge on screen" detail="Use Android Screen Pinning when you need stronger app-exit resistance." action="How to set" onPress={showPinGuide} />
    </Surface></View>

    <View style={styles.section}><SectionLabel>WHAT FOCUSFORGE CAN DO</SectionLabel><Surface style={styles.capabilityCard}><Capability icon="lock-clock" text="Restore the correct timer phase after you lock your display or return later." /><Capability icon="notifications" text="Schedule the single and triple study cues locally, without an account or internet." /><Capability icon="tune" text={`Respect your preference to ${settings.keepScreenAwake ? "keep the display on" : "let the display sleep"} during a session.`} /></Surface></View>
    <View style={styles.note}><MaterialIcons name="info-outline" size={18} color="#91A7C6" /><Text style={styles.noteText}>A normal Android app cannot universally disable Home, Recents, notifications, or selectively filter other apps’ calls. Android’s own Focus, Do Not Disturb, and Screen Pinning controls are the secure place to set those boundaries.</Text></View>
  </ScrollView></ScreenContainer>;
}

function Divider() { return <View style={styles.divider} />; }
function GuideRow({ icon, tone, title, detail, action, onPress }: { icon: keyof typeof MaterialIcons.glyphMap; tone: string; title: string; detail: string; action: string; onPress: () => void }) { return <View style={styles.guideRow}><View style={[styles.guideIcon, { backgroundColor: `${tone}22` }]}><MaterialIcons name={icon} size={20} color={tone} /></View><View style={styles.guideCopy}><Text style={styles.guideTitle}>{title}</Text><Text style={styles.guideDetail}>{detail}</Text><Pressable onPress={onPress} style={({ pressed }) => [styles.textAction, pressed && { opacity: 0.62 }]}><Text style={[styles.textActionLabel, { color: tone }]}>{action}</Text><MaterialIcons name="arrow-forward" size={14} color={tone} /></Pressable></View></View>; }
function Capability({ icon, text }: { icon: keyof typeof MaterialIcons.glyphMap; text: string }) { return <View style={styles.capabilityRow}><MaterialIcons name={icon} size={20} color="#5FE0B6" /><Text style={styles.capabilityText}>{text}</Text></View>; }

const styles = StyleSheet.create({
  content: { padding: 20, paddingTop: 16, paddingBottom: 32 }, header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }, eyebrow: { color: "#087A50", fontSize: 11, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#173423", fontSize: 29, lineHeight: 36, fontWeight: "900", marginTop: 5 }, description: { color: "#63796B", fontSize: 14, lineHeight: 20, marginTop: 8 },
  statusCard: { marginTop: 22, padding: 18, borderColor: "#BDE2C6", backgroundColor: "#FCFFFC" }, statusHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, statusBadge: { flexDirection: "row", gap: 7, alignItems: "center", borderRadius: 20, backgroundColor: "#EAF7EC", paddingHorizontal: 10, paddingVertical: 6 }, statusBadgeText: { fontSize: 10, fontWeight: "900", letterSpacing: 1.1 }, statusTitle: { color: "#173423", fontSize: 16, lineHeight: 22, fontWeight: "800", marginTop: 16 }, statusDetail: { color: "#63796B", fontSize: 12, lineHeight: 18, marginTop: 5 }, inlineAction: { flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start", marginTop: 13 }, inlineActionText: { color: "#087A50", fontSize: 12, fontWeight: "900" },
  section: { marginTop: 23 }, guideRow: { padding: 16, flexDirection: "row", gap: 12 }, guideIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" }, guideCopy: { flex: 1 }, guideTitle: { color: "#173423", fontSize: 14, fontWeight: "900" }, guideDetail: { color: "#63796B", fontSize: 12, lineHeight: 17, marginTop: 3 }, textAction: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 8, alignSelf: "flex-start" }, textActionLabel: { fontSize: 12, fontWeight: "900" }, divider: { height: StyleSheet.hairlineWidth, backgroundColor: "#DDECE0", marginLeft: 67 },
  capabilityCard: { paddingVertical: 5 }, capabilityRow: { paddingHorizontal: 16, paddingVertical: 12, flexDirection: "row", alignItems: "flex-start", gap: 11 }, capabilityText: { color: "#45634F", fontSize: 12, lineHeight: 18, flex: 1 }, note: { flexDirection: "row", gap: 9, padding: 15, backgroundColor: "#EEF8EF", borderRadius: 17, marginTop: 19, borderWidth: 1, borderColor: "#D6EBD9" }, noteText: { flex: 1, color: "#55735F", fontSize: 11, lineHeight: 17 },
});
