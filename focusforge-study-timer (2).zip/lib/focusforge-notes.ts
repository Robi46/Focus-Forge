export type NoteChecklistItem = {
  id: string;
  text: string;
  checked: boolean;
};

export type NoteFolder = {
  id: string;
  name: string;
  color: string;
  createdAtMs: number;
};

export type NoteFolderInput = Omit<NoteFolder, "id" | "createdAtMs"> & { id?: string };

export type PersonalNote = {
  id: string;
  title: string;
  body: string;
  checklist: NoteChecklistItem[];
  isPinned: boolean;
  folderId?: string;
  tags: string[];
  createdAtMs: number;
  updatedAtMs: number;
};

export type PersonalNoteInput = {
  id?: string;
  title: string;
  body: string;
  checklist: NoteChecklistItem[];
  isPinned: boolean;
  folderId?: string;
  tags: string[];
};

export type RoutineEntry = {
  id: string;
  dayIndex: number;
  startHour: number;
  durationHours: number;
  title: string;
  detail: string;
  color: string;
  updatedAtMs: number;
};

export type RoutineEntryInput = Omit<RoutineEntry, "id" | "updatedAtMs"> & { id?: string };

export const ROUTINE_COLORS = ["#087A50", "#1268A6", "#8B4EC8", "#E08A00", "#D63B25", "#008D9A"] as const;

function cleanText(value: unknown, maxLength: number) {
  if (typeof value !== "string") return "";
  return value.replace(/\r\n/g, "\n").trim().slice(0, maxLength);
}

function cleanId(value: unknown, prefix: string) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 80) : `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function numberInRange(value: unknown, fallback: number, min: number, max: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export function normalizeChecklist(value: unknown): NoteChecklistItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((entry): entry is Partial<NoteChecklistItem> => Boolean(entry && typeof entry === "object"))
    .map((entry, index) => ({ id: cleanId(entry.id, `check-${index}`), text: cleanText(entry.text, 140), checked: entry.checked === true }))
    .filter((entry) => Boolean(entry.text))
    .slice(0, 40);
}

export function normalizeNoteTags(value: unknown) {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const entry of value) {
    const tag = cleanText(entry, 24).replace(/^#/, "");
    const key = tag.toLocaleLowerCase();
    if (tag && !seen.has(key)) {
      seen.add(key);
      tags.push(tag);
    }
    if (tags.length === 12) break;
  }
  return tags;
}

export function normalizeNoteFolder(value: unknown): NoteFolder | null {
  if (!value || typeof value !== "object") return null;
  const source = value as Partial<NoteFolder>;
  const name = cleanText(source.name, 32);
  if (!name) return null;
  const color = typeof source.color === "string" && ROUTINE_COLORS.includes(source.color as (typeof ROUTINE_COLORS)[number]) ? source.color : ROUTINE_COLORS[0];
  return { id: cleanId(source.id, "folder"), name, color, createdAtMs: numberInRange(source.createdAtMs, Date.now(), 0, Number.MAX_SAFE_INTEGER) };
}

export function normalizePersonalNote(value: unknown): PersonalNote | null {
  if (!value || typeof value !== "object") return null;
  const source = value as Partial<PersonalNote>;
  const title = cleanText(source.title, 80);
  const body = cleanText(source.body, 6_000);
  const checklist = normalizeChecklist(source.checklist);
  if (!title && !body && !checklist.length) return null;
  const now = Date.now();
  return {
    id: cleanId(source.id, "note"),
    title: title || "Untitled note",
    body,
    checklist,
    isPinned: source.isPinned === true,
    folderId: typeof source.folderId === "string" && source.folderId.trim() ? source.folderId.trim().slice(0, 80) : undefined,
    tags: normalizeNoteTags(source.tags),
    createdAtMs: numberInRange(source.createdAtMs, now, 0, Number.MAX_SAFE_INTEGER),
    updatedAtMs: numberInRange(source.updatedAtMs, now, 0, Number.MAX_SAFE_INTEGER),
  };
}

export function normalizeRoutineEntry(value: unknown): RoutineEntry | null {
  if (!value || typeof value !== "object") return null;
  const source = value as Partial<RoutineEntry>;
  const title = cleanText(source.title, 80);
  if (!title) return null;
  const color = typeof source.color === "string" && ROUTINE_COLORS.includes(source.color as (typeof ROUTINE_COLORS)[number]) ? source.color : ROUTINE_COLORS[0];
  return {
    id: cleanId(source.id, "routine"),
    dayIndex: numberInRange(source.dayIndex, 0, 0, 6),
    startHour: numberInRange(source.startHour, 8, 0, 23),
    durationHours: numberInRange(source.durationHours, 1, 1, 12),
    title,
    detail: cleanText(source.detail, 240),
    color,
    updatedAtMs: numberInRange(source.updatedAtMs, Date.now(), 0, Number.MAX_SAFE_INTEGER),
  };
}

export function sortNotes(notes: PersonalNote[]) {
  return [...notes].sort((a, b) => Number(b.isPinned) - Number(a.isPinned) || b.updatedAtMs - a.updatedAtMs);
}

export function sortFolders(folders: NoteFolder[]) {
  return [...folders].sort((a, b) => a.name.localeCompare(b.name));
}

export function sortRoutine(entries: RoutineEntry[]) {
  return [...entries].sort((a, b) => a.dayIndex - b.dayIndex || a.startHour - b.startHour || a.title.localeCompare(b.title));
}

/** Returns the concise local text used when a note starts a Focus session. */
export function getNoteSessionGoal(note: Pick<PersonalNote, "title" | "body">) {
  return cleanText(note.title, 80) || cleanText(note.body, 140);
}

/** Returns the concise local text used when a checklist item starts a Focus session. */
export function getChecklistSessionGoal(item: Pick<NoteChecklistItem, "text">) {
  return cleanText(item.text, 140);
}
